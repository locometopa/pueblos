"""PUEBLOS — programa para crear y publicar la web de los pueblos que has visitado."""
import io
import queue
import threading
import traceback
import webbrowser
import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageOps, ImageTk

from nucleo import fotos as F
from nucleo import importar as I
from nucleo import mapa
from nucleo import tema
from nucleo import web
from nucleo import diseno as D
from nucleo import actualizar
from nucleo.github import GitHubAPI
from nucleo.tema import boton, color, fuente, fuente_titulo
from nucleo.commons import Commons
from nucleo.config import Config, COMUNIDADES, VERSION, NOMBRE_PROGRAMA, BASE
from nucleo.datos import Almacen, normalizar, pueblo_vacio
from nucleo.geo import Geocodificador
from nucleo.ia import generar_texto, ErrorIA
from nucleo.publicar import url_web, ErrorPublicar, git_disponible, configurar_token
from nucleo.sincronizar import Sincronizador
from nucleo.wiki import Wikipedia

TIPOS_FOTO = [("Fotos", " ".join(f"*{x}" for x in sorted(F.EXTENSIONES))), ("Todos", "*.*")]
TEMAS = {"Sistema": "System", "Claro": "Light", "Oscuro": "Dark"}


def fecha_ok(t: str) -> bool:
    """'2024-05-12', '2024-05' o '2024', con mes y día reales."""
    from datetime import datetime
    for fmt in ("%Y-%m-%d", "%Y-%m", "%Y"):
        try:
            datetime.strptime(t, fmt)
            return len(t) in (4, 7, 10)
        except ValueError:
            continue
    return False


def recorte(img: Image.Image, ancho: int, alto: int) -> Image.Image:
    """Recorta la imagen para llenar exactamente ancho x alto (como object-fit: cover)."""
    return ImageOps.fit(img.convert("RGB"), (ancho, alto), Image.LANCZOS)


# ============================================================================ vista: mapa
class VistaMapa(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.contenedor, fg_color="transparent")
        self.app = app
        self.pueblos = []
        self.visitadas = {}
        self._foto_mapa = None
        self._trabajo = None
        self._geometria = None
        self._prov_resaltada = None

        cab = ctk.CTkFrame(self, fg_color="transparent")
        cab.pack(fill="x", padx=28, pady=(22, 6))
        ctk.CTkLabel(cab, text="Mi mapa de España", font=fuente_titulo(28)).pack(anchor="w")
        self.lbl_sub = ctk.CTkLabel(cab, text="", text_color=tema.TINTA_2, font=fuente(14))
        self.lbl_sub.pack(anchor="w")

        self.cifras = ctk.CTkFrame(self, fg_color="transparent")
        self.cifras.pack(fill="x", padx=22, pady=(8, 10))
        self.tarjetas = {}
        for i, (clave, texto) in enumerate((("pueblos", "pueblos visitados"), ("provincias", "provincias destapadas"),
                                            ("comunidades", "comunidades"), ("pendientes", "por visitar"))):
            t = ctk.CTkFrame(self.cifras, corner_radius=12)
            t.grid(row=0, column=i, sticky="ew", padx=6)
            self.cifras.columnconfigure(i, weight=1)
            n = ctk.CTkLabel(t, text="0", font=fuente_titulo(30),
                             text_color=tema.PENDIENTE if clave == "pendientes" else tema.TINTA)
            n.pack(anchor="w", padx=16, pady=(12, 0))
            ctk.CTkLabel(t, text=texto, text_color=tema.TINTA_2, font=fuente(12)).pack(anchor="w", padx=16, pady=(0, 12))
            self.tarjetas[clave] = n
        self.barra = ctk.CTkProgressBar(self, height=8)
        self.barra.pack(fill="x", padx=28, pady=(0, 12))
        self.barra.set(0)

        cuerpo = ctk.CTkFrame(self, fg_color="transparent")
        cuerpo.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        cuerpo.columnconfigure(0, weight=1)
        cuerpo.rowconfigure(0, weight=1)
        self.marco = ctk.CTkFrame(cuerpo, corner_radius=14)
        self.marco.grid(row=0, column=0, sticky="nsew", padx=6)
        self.lienzo = tk.Canvas(self.marco, highlightthickness=0, borderwidth=0, cursor="hand2")
        self.lienzo.pack(fill="both", expand=True, padx=8, pady=8)
        self.lienzo.bind("<Configure>", lambda e: self.programar())
        self.lienzo.bind("<Motion>", self._mover)
        self.lienzo.bind("<Leave>", lambda e: self._ocultar_globo())
        self.lienzo.bind("<Button-1>", self._clic)

        self.panel = ctk.CTkScrollableFrame(cuerpo, width=270, corner_radius=14)
        self.panel.grid(row=0, column=1, sticky="ns", padx=6)
        self._panel_inicio()

    # ------------------------------------------------------------------ datos
    def refrescar(self):
        self.pueblos = [p for p in self.app.almacen.listar() if p.get("nombre")]
        self.visitadas = {}
        for p in self.pueblos:
            p["_prov"] = mapa.provincia_de(p)
        vis = [p for p in self.pueblos if p.get("estado") != "pendiente"]
        pen = [p for p in self.pueblos if p.get("estado") == "pendiente"]
        for p in sorted(vis, key=lambda x: (x.get("fechas_visita") or [""])[-1]):
            if p["_prov"]:
                info = self.visitadas.setdefault(p["_prov"], {"n": 0, "foto": None})
                info["n"] += 1
                if p.get("portada"):
                    info["foto"] = self.app.almacen.carpeta_pueblo(p["slug"]) / "mini" / p["portada"]
        total = len(mapa.provincias())
        self.tarjetas["pueblos"].configure(text=str(len(vis)))
        self.tarjetas["provincias"].configure(text=f"{len(self.visitadas)} / {total}")
        self.tarjetas["comunidades"].configure(text=str(len({p['comunidad'] for p in vis if p['comunidad']})))
        self.tarjetas["pendientes"].configure(text=str(len(pen)))
        porc = len(self.visitadas) / total if total else 0
        self.barra.set(porc)
        self.lbl_sub.configure(text=f"Has destapado el {round(porc * 100)}% de las provincias. "
                                    "Haz clic en una provincia o en una chincheta.")
        self.programar()

    def programar(self):
        if self._trabajo:
            self.after_cancel(self._trabajo)
        self._trabajo = self.after(120, self.dibujar)

    # ------------------------------------------------------------------ dibujo
    def dibujar(self):
        self._trabajo = None
        c = self.lienzo
        W, H = c.winfo_width(), c.winfo_height()
        if W < 60 or H < 60:
            return
        c.configure(background=color(tema.MAPA_FONDO))
        x0, y0, x1, y1 = mapa.limites()
        m = 14
        esc = min((W - 2 * m) / (x1 - x0), (H - 2 * m) / (y1 - y0))
        ox = (W - (x1 - x0) * esc) / 2 - x0 * esc
        oy = (H - (y1 - y0) * esc) / 2 - y0 * esc
        self._geometria = (esc, ox, oy)
        S = 2  # se dibuja al doble y se reduce: bordes suaves

        def px(pt, k=S):
            return (pt[0] * esc + ox) * k, (pt[1] * esc + oy) * k

        img = Image.new("RGB", (W * S, H * S), color(tema.MAPA_FONDO))
        d = ImageDraw.Draw(img)
        tapada, raya = color(tema.MAPA_TAPADA), color(tema.MAPA_TAPADA_RAYA)
        borde, acento = color(tema.MAPA_BORDE), color(tema.ACENTO)
        # rayado de fondo para las tapadas (se recorta con una máscara)
        rayado = Image.new("RGB", img.size, tapada)
        dr = ImageDraw.Draw(rayado)
        for k in range(-img.size[1], img.size[0], 14):
            dr.line([(k, img.size[1]), (k + img.size[1], 0)], fill=raya, width=2)
        mascara_tapadas = Image.new("L", img.size, 0)
        dm = ImageDraw.Draw(mascara_tapadas)

        for pid, anillos in mapa.proyectadas():
            puntos = [[px(p) for p in a] for a in anillos]
            info = self.visitadas.get(pid)
            if info and info["foto"] and Path(info["foto"]).exists():
                xs = [x for a in puntos for x, _ in a]
                ys = [y for a in puntos for _, y in a]
                bx0, by0, bx1, by1 = int(min(xs)), int(min(ys)), int(max(xs)) + 1, int(max(ys)) + 1
                try:
                    with Image.open(info["foto"]) as f:
                        foto = recorte(f, max(1, bx1 - bx0), max(1, by1 - by0))
                    masc = Image.new("L", foto.size, 0)
                    md = ImageDraw.Draw(masc)
                    for a in puntos:
                        if len(a) > 2:
                            md.polygon([(x - bx0, y - by0) for x, y in a], fill=255)
                    img.paste(foto, (bx0, by0), masc)
                except Exception:  # noqa: BLE001
                    for a in puntos:
                        if len(a) > 2:
                            d.polygon(a, fill=acento)
            elif info:
                for a in puntos:
                    if len(a) > 2:
                        d.polygon(a, fill=acento)
            else:
                for a in puntos:
                    if len(a) > 2:
                        dm.polygon(a, fill=255)
        img.paste(rayado, (0, 0), mascara_tapadas)
        for pid, anillos in mapa.proyectadas():
            for a in anillos:
                if len(a) > 2:
                    d.line([px(p) for p in a] + [px(a[0])], fill=borde, width=2 if pid in self.visitadas else 1)
        cx0, cy0, cx1, cy1 = mapa.caja_canarias()
        d.rectangle([px((cx0, cy0)), px((cx1, cy1))], outline=color(tema.LINEA), width=2)

        # chinchetas (dibujadas en la imagen para que salgan redondas y suaves)
        self._pins = []
        pend_col, fondo_pin = color(tema.PENDIENTE), color(tema.TARJETA)
        orden = sorted((p for p in self.pueblos if p.get("lat") is not None),
                       key=lambda p: p.get("estado") != "pendiente")  # las visitadas encima
        for p in orden:
            x, y = px(mapa.proyectar(p["lon"], p["lat"]))
            if p.get("estado") == "pendiente":
                r = 6.5 * S
                d.ellipse([x - r, y - r, x + r, y + r], fill=fondo_pin, outline=pend_col, width=int(2.5 * S))
                d.ellipse([x - 2 * S, y - 2 * S, x + 2 * S, y + 2 * S], fill=pend_col)
            else:
                r = 6 * S
                d.ellipse([x - r, y - r, x + r, y + r], fill=acento, outline="#ffffff", width=int(2 * S))
            self._pins.append((x / S, y / S, p["slug"]))

        self._foto_mapa = ImageTk.PhotoImage(img.resize((W, H), Image.LANCZOS))
        c.delete("all")
        c.create_image(0, 0, image=self._foto_mapa, anchor="nw")
        self._prov_resaltada = None

    # ------------------------------------------------------------------ interacción
    def _a_lonlat(self, x, y):
        if not self._geometria:
            return None
        esc, ox, oy = self._geometria
        return mapa.desproyectar((x - ox) / esc, (y - oy) / esc)

    def _pin_en(self, x, y):
        mejor, dist = None, 9 ** 2
        for px_, py_, slug in getattr(self, "_pins", []):
            d = (px_ - x) ** 2 + (py_ - y) ** 2
            if d <= dist:
                mejor, dist = slug, d
        return mejor

    def _mover(self, ev):
        slug = self._pin_en(ev.x, ev.y)
        if slug:
            p = next((q for q in self.pueblos if q["slug"] == slug), None)
            if p:
                extra = "Por visitar" if p.get("estado") == "pendiente" else (
                    ", ".join(p.get("fechas_visita") or []) or "Visitado")
                self._globo(ev.x, ev.y, p["nombre"], extra)
            self._resaltar(None)
            return
        ll = self._a_lonlat(ev.x, ev.y)
        pid = mapa.provincia_de_punto(ll[1], ll[0]) if ll else None
        if not pid:
            self._ocultar_globo()
            self._resaltar(None)
            return
        prov = mapa.por_id(pid)
        info = self.visitadas.get(pid)
        n_pen = sum(1 for p in self.pueblos if p.get("_prov") == pid and p.get("estado") == "pendiente")
        texto = (f"{info['n']} {'pueblo visitado' if info['n'] == 1 else 'pueblos visitados'}" if info
                 else "Sin destapar")
        if n_pen:
            texto += f" · {n_pen} por visitar"
        self._globo(ev.x, ev.y, prov["nombre"], texto)
        self._resaltar(pid)

    def _resaltar(self, pid):
        if pid == self._prov_resaltada:
            return
        self.lienzo.delete("resalte")
        self._prov_resaltada = pid
        if not pid or not self._geometria:
            return
        esc, ox, oy = self._geometria
        for p_id, anillos in mapa.proyectadas():
            if p_id == pid:
                for a in anillos:
                    if len(a) > 2:
                        pts = [v for x, y in a for v in (x * esc + ox, y * esc + oy)]
                        self.lienzo.create_polygon(pts, outline=color(tema.TINTA), fill="", width=2, tags="resalte")
        self.lienzo.tag_raise("globo")

    def _globo(self, x, y, titulo, texto):
        c = self.lienzo
        c.delete("globo")
        fondo, letra = color(tema.TINTA), color(tema.PAPEL)
        t1 = c.create_text(x, y - 34, text=titulo, fill=letra, font=(tema.FUENTE_TITULO, 12, "bold"),
                           anchor="s", tags="globo")
        t2 = c.create_text(x, y - 18, text=texto, fill=letra, font=(tema.FUENTE, 10), anchor="s", tags="globo")
        bx = c.bbox(t1)
        bx2 = c.bbox(t2)
        caja = (min(bx[0], bx2[0]) - 10, bx[1] - 6, max(bx[2], bx2[2]) + 10, bx2[3] + 6)
        desp = 0
        if caja[0] < 4:
            desp = 4 - caja[0]
        elif caja[2] > c.winfo_width() - 4:
            desp = c.winfo_width() - 4 - caja[2]
        r = c.create_rectangle(caja[0] + desp, caja[1], caja[2] + desp, caja[3], fill=fondo, outline=fondo, tags="globo")
        c.move(t1, desp, 0)
        c.move(t2, desp, 0)
        c.tag_lower(r, t1)

    def _ocultar_globo(self):
        self.lienzo.delete("globo")

    def _clic(self, ev):
        slug = self._pin_en(ev.x, ev.y)
        if slug:
            self.app.abrir(slug)
            return
        ll = self._a_lonlat(ev.x, ev.y)
        pid = mapa.provincia_de_punto(ll[1], ll[0]) if ll else None
        if pid:
            self._panel_provincia(pid)

    # ------------------------------------------------------------------ panel lateral
    def _limpiar_panel(self):
        for w in self.panel.winfo_children():
            w.destroy()

    def _panel_inicio(self):
        self._limpiar_panel()
        ctk.CTkLabel(self.panel, text="Provincias", font=fuente_titulo(20)).pack(anchor="w", padx=10, pady=(10, 2))
        ctk.CTkLabel(self.panel, text="Haz clic en una provincia del mapa\npara ver sus pueblos.",
                     text_color=tema.TINTA_2, justify="left").pack(anchor="w", padx=10)
        leyenda = ctk.CTkFrame(self.panel, fg_color="transparent")
        leyenda.pack(fill="x", padx=10, pady=16)
        for texto, col in (("Visitado", tema.ACENTO), ("Por visitar", tema.PENDIENTE), ("Sin destapar", tema.MAPA_TAPADA)):
            fila = ctk.CTkFrame(leyenda, fg_color="transparent")
            fila.pack(anchor="w", pady=2)
            ctk.CTkFrame(fila, width=14, height=14, corner_radius=7, fg_color=col).pack(side="left", padx=(0, 8))
            ctk.CTkLabel(fila, text=texto).pack(side="left")

    def _panel_provincia(self, pid):
        self._limpiar_panel()
        prov = mapa.por_id(pid)
        ctk.CTkLabel(self.panel, text=prov["nombre"], font=fuente_titulo(22), wraplength=240,
                     justify="left").pack(anchor="w", padx=10, pady=(10, 0))
        ctk.CTkLabel(self.panel, text=prov["comunidad"], text_color=tema.TINTA_2).pack(anchor="w", padx=10)
        vis = [p for p in self.pueblos if p.get("_prov") == pid and p.get("estado") != "pendiente"]
        pen = [p for p in self.pueblos if p.get("_prov") == pid and p.get("estado") == "pendiente"]
        for titulo, lista in (("Visitados", vis), ("Por visitar", pen)):
            if not lista:
                continue
            ctk.CTkLabel(self.panel, text=titulo.upper(), font=fuente(11, "bold"),
                         text_color=tema.ACENTO if titulo == "Visitados" else tema.PENDIENTE).pack(
                anchor="w", padx=10, pady=(16, 4))
            for p in sorted(lista, key=lambda x: normalizar(x["nombre"])):
                boton(self.panel, p["nombre"], lambda s=p["slug"]: self.app.abrir(s), "secundario", anchor="w").pack(
                    fill="x", padx=8, pady=2)
        if not vis and not pen:
            ctk.CTkLabel(self.panel, text="Todavía no has estado aquí.", text_color=tema.TINTA_2).pack(
                anchor="w", padx=10, pady=(16, 6))
        boton(self.panel, "＋ Añadir un pueblo por visitar", lambda: self.app.nuevo("pendiente", prov["nombre"]),
              "fantasma", text_color=tema.PENDIENTE).pack(fill="x", padx=8, pady=(18, 4))


# ============================================================================ vista: lista de pueblos
class VistaLista(ctk.CTkFrame):
    ANCHO_FICHA = 230

    def __init__(self, app, estado):
        super().__init__(app.contenedor, fg_color="transparent")
        self.app = app
        self.estado = estado
        self._columnas = 0
        self._imagenes = []

        cab = ctk.CTkFrame(self, fg_color="transparent")
        cab.pack(fill="x", padx=28, pady=(22, 10))
        izq = ctk.CTkFrame(cab, fg_color="transparent")
        izq.pack(side="left")
        ctk.CTkLabel(izq, text="Pueblos visitados" if estado == "visitado" else "Por visitar",
                     font=fuente_titulo(28)).pack(anchor="w")
        self.lbl_n = ctk.CTkLabel(izq, text="", text_color=tema.TINTA_2, font=fuente(14))
        self.lbl_n.pack(anchor="w")
        if estado == "visitado":
            boton(cab, "📷  Importar fotos…", app.importar).pack(side="right", padx=(8, 0))
            boton(cab, "＋  Nuevo pueblo", lambda: app.nuevo("visitado"), "secundario").pack(side="right", padx=(8, 0))
        else:
            boton(cab, "＋  Añadir a la lista", lambda: app.nuevo("pendiente"), "pendiente").pack(side="right", padx=(8, 0))
        self.buscador = ctk.CTkEntry(cab, placeholder_text="🔎  Buscar pueblo o provincia…", width=240, height=34)
        self.buscador.pack(side="right", padx=(8, 0))
        self.buscador.bind("<KeyRelease>", lambda e: self.refrescar())

        self.rejilla = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.rejilla.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.bind("<Configure>", self._al_redimensionar)

    def _al_redimensionar(self, ev):
        if ev.widget is not self:
            return
        cols = max(1, (ev.width - 70) // (self.ANCHO_FICHA + 16))
        if cols != self._columnas:
            self._columnas = cols
            self.refrescar()

    def refrescar(self):
        for w in self.rejilla.winfo_children():
            w.destroy()
        self._imagenes = []
        texto_buscar = self.buscador.get()
        filtro = normalizar(texto_buscar)
        todos = [p for p in self.app.almacen.listar()
                 if (p.get("estado") == "pendiente") == (self.estado == "pendiente")]
        pueblos = [p for p in todos if not filtro
                   or filtro in normalizar(f"{p['nombre']} {p['provincia']} {p['comunidad']}")]
        self.lbl_n.configure(text=f"{len(todos)} {'pueblo' if len(todos) == 1 else 'pueblos'}"
                                  + (f" · {len(pueblos)} con «{texto_buscar}»" if filtro else ""))
        cols = max(1, self._columnas or 4)
        for c in range(cols):
            self.rejilla.columnconfigure(c, weight=1, uniform="col")
        if not pueblos:
            texto = ("Todavía no hay pueblos. Importa las fotos de un viaje o crea uno nuevo." if self.estado == "visitado"
                     else "Tu lista de pendientes está vacía. Añade los pueblos que quieres conocer.")
            ctk.CTkLabel(self.rejilla, text=texto if not filtro else "No hay pueblos que coincidan.",
                         text_color=tema.TINTA_2, font=fuente(14)).grid(row=0, column=0, columnspan=cols, pady=60)
            return
        orden = sorted(pueblos, key=lambda x: (normalizar(x["comunidad"] or "zzz"), normalizar(x["nombre"])))
        for i, p in enumerate(orden):
            self._ficha(p).grid(row=i // cols, column=i % cols, padx=8, pady=8, sticky="n")

    def _ficha(self, p):
        pend = p.get("estado") == "pendiente"
        f = ctk.CTkFrame(self.rejilla, corner_radius=12, border_width=2 if pend else 0,
                         border_color=tema.PENDIENTE if pend else tema.LINEA)
        img = self.app.miniatura(p["slug"], p.get("portada"), self.ANCHO_FICHA, 150)
        if img:
            foto = ctk.CTkLabel(f, text="", image=img, corner_radius=10)
            self._imagenes.append(img)
        else:
            foto = ctk.CTkLabel(f, text=p["nombre"][:1], width=self.ANCHO_FICHA, height=150, corner_radius=10,
                                fg_color=tema.TARJETA_2, text_color=tema.LINEA, font=fuente_titulo(48))
        foto.pack(padx=6, pady=(6, 0))
        nombre = ctk.CTkLabel(f, text=p["nombre"], font=fuente(15, "bold"), anchor="w")
        nombre.pack(fill="x", padx=12, pady=(8, 0))
        if pend:
            sub = p["provincia"] or "Por visitar"
        else:
            visita = (p.get("fechas_visita") or [""])[-1]
            propias = sum(1 for x in p["fotos"] if not x.get("credito"))
            fotos = f"{propias} 📷" if propias else "🌐 sin fotos tuyas"
            sub = " · ".join(x for x in (p["provincia"] or p["comunidad"], visita, fotos) if x)
        detalle = ctk.CTkLabel(f, text=sub, text_color=tema.TINTA_2, font=fuente(12), anchor="w")
        detalle.pack(fill="x", padx=12, pady=(0, 10))
        for w in (f, foto, nombre, detalle):
            w.bind("<Button-1>", lambda ev, s=p["slug"]: self.app.abrir(s))
            w.configure(cursor="hand2")
        return f


# ============================================================================ vista: editor
class VistaEditor(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.contenedor, fg_color="transparent")
        self.app = app
        self.sel = set()
        self._imagenes = []
        self._columnas = 0

        barra = ctk.CTkFrame(self, fg_color="transparent")
        barra.pack(fill="x", padx=22, pady=(18, 6))
        boton(barra, "←  Volver", app.volver, "fantasma", width=90).pack(side="left")
        self.lbl_titulo = ctk.CTkLabel(barra, text="", font=fuente_titulo(26))
        self.lbl_titulo.pack(side="left", padx=(12, 0))
        boton(barra, "Eliminar", self.eliminar, "peligro", width=90).pack(side="right")
        boton(barra, "💾  Guardar", self.guardar, width=110).pack(side="right", padx=8)
        self.seg_estado = ctk.CTkSegmentedButton(barra, values=["Visitado", "Por visitar"], command=self._cambiar_estado,
                                                 height=32, font=fuente(13))
        self.seg_estado.pack(side="right", padx=8)

        # ---- datos
        form = ctk.CTkFrame(self, corner_radius=14)
        form.pack(fill="x", padx=28, pady=(6, 10))
        for c in (1, 3, 5):
            form.columnconfigure(c, weight=1)
        self.v = {k: tk.StringVar() for k in ("nombre", "provincia", "comunidad", "fechas", "lat", "lon")}
        self.v_publicar = tk.BooleanVar(value=True)

        def campo(fila, col, etiqueta, var, **kw):
            ctk.CTkLabel(form, text=etiqueta, text_color=tema.TINTA_2).grid(row=fila, column=col, sticky="w",
                                                                            padx=(16, 8), pady=8)
            e = ctk.CTkEntry(form, textvariable=var, height=32, **kw)
            e.grid(row=fila, column=col + 1, sticky="ew", padx=(0, 10), pady=8)
            return e
        campo(0, 0, "Nombre", self.v["nombre"])
        campo(0, 2, "Provincia", self.v["provincia"])
        ctk.CTkLabel(form, text="Comunidad", text_color=tema.TINTA_2).grid(row=0, column=4, sticky="w", padx=(16, 8))
        ctk.CTkComboBox(form, variable=self.v["comunidad"], values=COMUNIDADES, height=32).grid(
            row=0, column=5, sticky="ew", padx=(0, 16))
        campo(1, 0, "Visitas", self.v["fechas"])
        campo(1, 2, "Latitud", self.v["lat"])
        campo(1, 4, "Longitud", self.v["lon"])
        pie = ctk.CTkFrame(form, fg_color="transparent")
        pie.grid(row=2, column=0, columnspan=6, sticky="ew", padx=10, pady=(0, 10))
        boton(pie, "🔎  Buscar ubicación", self.buscar_ubicacion, "secundario").pack(side="left", padx=6)
        boton(pie, "📅  Hoy", self._anadir_hoy, "fantasma", width=70).pack(side="left")
        ctk.CTkLabel(pie, text="Fechas como AAAA-MM-DD, separadas por comas", text_color=tema.TINTA_2,
                     font=fuente(11)).pack(side="left", padx=8)
        ctk.CTkSwitch(pie, text="Publicar en la web", variable=self.v_publicar).pack(side="right", padx=8)

        # ---- pestañas
        self.tabs = ctk.CTkTabview(self, corner_radius=14)
        self.tabs.pack(fill="both", expand=True, padx=28, pady=(0, 14))
        for nombre in ("Fotos", "Wikipedia", "Texto IA", "Mis notas"):
            self.tabs.add(nombre)

        tf = self.tabs.tab("Fotos")
        bf = ctk.CTkFrame(tf, fg_color="transparent")
        bf.pack(fill="x")
        boton(bf, "＋ Mis fotos…", self.anadir_fotos).pack(side="left", padx=(0, 6))
        boton(bf, "🌐 Fotos de internet…", self.app.fotos_internet, "secundario").pack(side="left", padx=6)
        boton(bf, "★ Portada", self.hacer_portada, "fantasma", width=90).pack(side="left", padx=(16, 0))
        boton(bf, "Pie de foto…", self.pie_foto, "fantasma", width=100).pack(side="left")
        boton(bf, "Quitar", self.quitar_fotos, "fantasma", width=70, text_color=tema.PELIGRO).pack(side="left")
        ctk.CTkLabel(bf, text="Clic para elegir · Ctrl+clic para varias · doble clic para verla",
                     text_color=tema.TINTA_2, font=fuente(12)).pack(side="right")
        self.galeria = ctk.CTkScrollableFrame(tf, fg_color="transparent")
        self.galeria.pack(fill="both", expand=True, pady=(8, 0))
        self._tab_fotos = tf
        tf.bind("<Configure>", self._al_redimensionar)

        tw = self.tabs.tab("Wikipedia")
        bw = ctk.CTkFrame(tw, fg_color="transparent")
        bw.pack(fill="x")
        boton(bw, "⬇  Traer datos de Wikipedia", self.traer_wiki).pack(side="left")
        self.lbl_wiki = ctk.CTkLabel(tw, text="", text_color=tema.TINTA_2, wraplength=900, justify="left", anchor="w")
        self.lbl_wiki.pack(fill="x", pady=(6, 0))
        self.txt_wiki = ctk.CTkTextbox(tw, wrap="word", font=fuente(14))
        self.txt_wiki.pack(fill="both", expand=True, pady=(8, 0))

        ti = self.tabs.tab("Texto IA")
        bi = ctk.CTkFrame(ti, fg_color="transparent")
        bi.pack(fill="x")
        boton(bi, "✨  Generar texto con IA", self.generar_ia).pack(side="left")
        ctk.CTkLabel(bi, text="Se basa en Wikipedia y tus notas. Puedes corregirlo a mano.",
                     text_color=tema.TINTA_2).pack(side="left", padx=12)
        self.txt_ia = ctk.CTkTextbox(ti, wrap="word", font=fuente(14))
        self.txt_ia.pack(fill="both", expand=True, pady=(8, 0))

        tn = self.tabs.tab("Mis notas")
        ctk.CTkLabel(tn, text="Tus impresiones: con quién fuiste, qué viste, dónde comiste… "
                              "(deja una línea en blanco entre párrafos)", text_color=tema.TINTA_2).pack(anchor="w")
        self.txt_notas = ctk.CTkTextbox(tn, wrap="word", font=fuente(14))
        self.txt_notas.pack(fill="both", expand=True, pady=(8, 0))

    @property
    def p(self):
        return self.app.actual

    def refrescar(self):
        pass

    # ------------------------------------------------------------------ cargar / leer
    def cargar(self):
        p = self.p
        self.sel.clear()
        self.lbl_titulo.configure(text=p["nombre"] or "Pueblo nuevo")
        self.v["nombre"].set(p["nombre"])
        self.v["provincia"].set(p["provincia"])
        self.v["comunidad"].set(p["comunidad"])
        self.v["fechas"].set(", ".join(p["fechas_visita"]))
        self.v["lat"].set("" if p["lat"] is None else str(p["lat"]))
        self.v["lon"].set("" if p["lon"] is None else str(p["lon"]))
        self.v_publicar.set(p.get("publicar", True))
        self.seg_estado.set("Por visitar" if p.get("estado") == "pendiente" else "Visitado")
        for t, valor in ((self.txt_wiki, p["wiki"].get("extracto", "")), (self.txt_ia, p["texto_ia"]),
                         (self.txt_notas, p["notas"])):
            t.delete("1.0", "end")
            t.insert("1.0", valor or "")
        self._etiqueta_wiki()
        self.pintar_fotos()

    def leer(self):
        p = self.p
        p["nombre"] = self.v["nombre"].get().strip()
        p["provincia"] = self.v["provincia"].get().strip()
        p["comunidad"] = self.v["comunidad"].get().strip()
        p["fechas_visita"] = [x.strip() for x in self.v["fechas"].get().replace(";", ",").split(",") if x.strip()]
        for k in ("lat", "lon"):
            try:
                p[k] = float(self.v[k].get().replace(",", ".")) if self.v[k].get().strip() else None
            except ValueError:
                pass
        p["publicar"] = self.v_publicar.get()
        p["estado"] = "pendiente" if self.seg_estado.get() == "Por visitar" else "visitado"
        p["wiki"]["extracto"] = self.txt_wiki.get("1.0", "end").strip()
        p["texto_ia"] = self.txt_ia.get("1.0", "end").strip()
        p["notas"] = self.txt_notas.get("1.0", "end").strip()

    def _etiqueta_wiki(self):
        w = self.p["wiki"]
        partes = []
        if w.get("titulo"):
            partes.append(f"Artículo: {w['titulo']}")
        if w.get("poblacion"):
            partes.append(f"{w['poblacion']:,} hab.".replace(",", "."))
        if w.get("altitud") not in (None, ""):
            partes.append(f"{w['altitud']} m")
        if w.get("secciones"):
            partes.append(f"Apartados: {', '.join(x['titulo'] for x in w['secciones'])}")
        if w.get("que_ver"):
            partes.append(f"{len(w['que_ver'])} lugares que ver")
        self.lbl_wiki.configure(text="  ·  ".join(partes) or "Sin datos todavía")

    def _cambiar_estado(self, valor):
        if valor == "Visitado" and not self.v["fechas"].get().strip():
            f = self.app.pedir_fecha("¡Enhorabuena! ¿Cuándo lo visitaste?", date.today().isoformat())
            if f:
                self.v["fechas"].set(f)

    def _anadir_hoy(self):
        hoy = date.today().isoformat()
        fechas = [x.strip() for x in self.v["fechas"].get().split(",") if x.strip()]
        if hoy not in fechas:
            fechas.append(hoy)
        self.v["fechas"].set(", ".join(sorted(fechas)))

    def guardar(self, silencioso=False):
        if not self.p:
            return False
        self.leer()
        if not self.p["nombre"]:
            if not silencioso:
                messagebox.showwarning(NOMBRE_PROGRAMA, "El pueblo necesita un nombre.")
            return False
        malas = [f for f in self.p["fechas_visita"] if not fecha_ok(f)]
        if malas and not silencioso:
            messagebox.showwarning(NOMBRE_PROGRAMA, f"La fecha «{malas[0]}» no es válida. Usa 2024-05-12, 2024-05 o 2024.")
            return False
        self.p["fechas_visita"] = [f for f in self.p["fechas_visita"] if fecha_ok(f)]
        self.app.almacen.guardar(self.p)
        self.lbl_titulo.configure(text=self.p["nombre"])
        if not silencioso:
            self.app.estado(f"Guardado «{self.p['nombre']}».")
        return True

    def eliminar(self):
        if not self.p:
            return
        if not messagebox.askyesno(NOMBRE_PROGRAMA, f"¿Quitar «{self.p['nombre']}» del programa?\n\n"
                                   "No se borra del todo: se guarda en datos\\_papelera.\n"
                                   "Desaparecerá de la web la próxima vez que publiques."):
            return
        self.app.almacen.eliminar(self.p["slug"])
        self.app.actual = None
        self.app.volver(guardar=False)

    # ------------------------------------------------------------------ fotos
    def _al_redimensionar(self, ev):
        if ev.widget is not self._tab_fotos:
            return
        cols = max(1, (ev.width - 30) // 172)
        if cols != self._columnas:
            self._columnas = cols
            self.pintar_fotos()

    def pintar_fotos(self):
        for w in self.galeria.winfo_children():
            w.destroy()
        self._imagenes = []
        if not self.p:
            return
        p = self.p
        if not p["fotos"]:
            ctk.CTkLabel(self.galeria, text="Sin fotos todavía. Añade las tuyas o busca fotos libres en internet.",
                         text_color=tema.TINTA_2, font=fuente(14)).grid(row=0, column=0, pady=40, padx=20)
            return
        cols = max(1, self._columnas or 5)
        for i, f in enumerate(p["fotos"]):
            elegida = f["archivo"] in self.sel
            caja = ctk.CTkFrame(self.galeria, corner_radius=10, border_width=3,
                                border_color=tema.ACENTO if elegida else tema.TARJETA,
                                fg_color=tema.TARJETA_2 if elegida else tema.TARJETA)
            caja.grid(row=i // cols, column=i % cols, padx=5, pady=5)
            img = self.app.miniatura(p["slug"], f["archivo"], 150, 150)
            lbl = ctk.CTkLabel(caja, text="" if img else "?", image=img, width=150, height=150)
            if img:
                self._imagenes.append(img)
            lbl.pack(padx=4, pady=(4, 0))
            marca = ("★ " if f["archivo"] == p["portada"] else "") + ("🌐 " if f.get("credito") else "")
            texto = marca + (f.get("pie") or f.get("fecha") or (f["credito"]["autor"] if f.get("credito") else ""))
            pie = ctk.CTkLabel(caja, text=texto[:22], font=fuente(11), text_color=tema.TINTA_2, height=20)
            pie.pack(fill="x", padx=4, pady=(0, 4))
            for w in (caja, lbl, pie):
                w.bind("<Button-1>", lambda ev, a=f["archivo"]: self._clic_foto(a, ev))
                w.bind("<Double-Button-1>", lambda ev, a=f["archivo"]: self._ver_foto(a))

    def _clic_foto(self, archivo, ev):
        if ev.state & 0x0004:
            self.sel.symmetric_difference_update({archivo})
        else:
            self.sel = {archivo}
        self.pintar_fotos()

    def _ver_foto(self, archivo):
        ruta = self.app.almacen.carpeta_pueblo(self.p["slug"]) / "fotos" / archivo
        if ruta.exists():
            webbrowser.open(ruta.as_uri())

    def anadir_fotos(self):
        if not self.p:
            return
        rutas = filedialog.askopenfilenames(parent=self, title="Elige las fotos del pueblo", filetypes=TIPOS_FOTO)
        if not rutas:
            return
        self.guardar(silencioso=True)
        p = self.p

        def fin(n):
            self.app.abrir(p["slug"], recargar=True)
            self.app.estado(f"Añadidas {n} fotos.")
        self.app.en_segundo_plano("Preparando fotos…", lambda: I.anadir_fotos(
            self.app.almacen, p, rutas, int(self.app.cfg["lado_foto"]), self.app._progreso), fin)

    def hacer_portada(self):
        if self.p and len(self.sel) == 1:
            self.p["portada"] = next(iter(self.sel))
            self.guardar(silencioso=True)
            self.pintar_fotos()
        else:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Elige una sola foto.")

    def pie_foto(self):
        if not self.p or len(self.sel) != 1:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Elige una sola foto.")
            return
        a = next(iter(self.sel))
        f = next(x for x in self.p["fotos"] if x["archivo"] == a)
        texto = self.app.pedir_texto("Pie de foto", "Escribe el pie de foto:", f.get("pie", ""))
        if texto is not None:
            f["pie"] = texto.strip()
            self.guardar(silencioso=True)
            self.pintar_fotos()

    def quitar_fotos(self):
        if not self.p or not self.sel:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Elige las fotos que quieras quitar.")
            return
        if not messagebox.askyesno(NOMBRE_PROGRAMA, f"¿Quitar {len(self.sel)} foto(s) de este pueblo?\n"
                                                  "Tus fotos originales no se tocan."):
            return
        self.p["fotos"] = [f for f in self.p["fotos"] if f["archivo"] not in self.sel]
        for a in self.sel:
            for sub in ("fotos", "mini"):
                ruta = self.app.almacen.carpeta_pueblo(self.p["slug"]) / sub / a
                if ruta.exists():
                    ruta.unlink()
        self.sel.clear()
        self.guardar(silencioso=True)
        self.pintar_fotos()

    # ------------------------------------------------------------------ ubicación / wiki / IA
    def buscar_ubicacion(self, despues=None):
        if not self.p:
            return
        self.leer()
        texto = ", ".join(x for x in (self.p["nombre"], self.p["provincia"]) if x)
        if not texto:
            return
        p = self.p

        def fin(resultados):
            if not resultados:
                messagebox.showinfo(NOMBRE_PROGRAMA, f"No encuentro «{texto}» en el mapa.")
                return
            elegido = self.app.elegir_lugar(resultados) if len(resultados) > 1 else resultados[0]
            if not elegido:
                return
            p["provincia"] = elegido["provincia"] or p["provincia"]
            p["comunidad"] = elegido["comunidad"] or p["comunidad"]
            p["lat"], p["lon"] = round(elegido["lat"], 6), round(elegido["lon"], 6)
            self.app.almacen.guardar(p)
            self.cargar()
            self.app.estado(f"Ubicado en {p['provincia']} ({p['comunidad']}).")
            if despues:
                despues()
        self.app.en_segundo_plano("Buscando en el mapa…", lambda: self.app.geo.buscar(texto), fin)

    def traer_wiki(self, despues=None):
        if not self.p:
            return
        self.leer()
        p = self.p
        if p["wiki"].get("extracto") and not despues and not messagebox.askyesno(
                NOMBRE_PROGRAMA, "Ya hay texto de Wikipedia. ¿Lo sustituyo por el actual de Wikipedia?"):
            return

        def fin(d):
            if not self.app.aplicar_wiki(p, d):
                messagebox.showinfo(NOMBRE_PROGRAMA, "No he encontrado el artículo en Wikipedia.\n"
                                    "Revisa el nombre y la provincia, o pega tú el texto.")
            else:
                self.app.almacen.guardar(p)
                self.cargar()
                self.tabs.set("Wikipedia")
                self.app.estado(f"Datos de Wikipedia: «{d.get('titulo')}».")
            if despues:
                despues()
        self.app.en_segundo_plano("Consultando Wikipedia…",
                                  lambda: self.app.wiki.todo(p["nombre"], p["provincia"], p["lat"], p["lon"]), fin)

    def generar_ia(self):
        if not self.p:
            return
        if not self.app.cfg["api_key"]:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Para escribir con IA necesitas una clave de la API de Anthropic.\n"
                                "Consíguela en console.anthropic.com y ponla en Ajustes.")
            return
        self.leer()
        p = self.p
        if p["texto_ia"] and not messagebox.askyesno(NOMBRE_PROGRAMA, "¿Sustituyo el texto actual por uno nuevo?"):
            return

        def fin(texto):
            p["texto_ia"] = texto
            self.app.almacen.guardar(p)
            self.cargar()
            self.tabs.set("Texto IA")
            self.app.estado("Texto generado. Revísalo antes de publicar.")
        self.app.en_segundo_plano("Escribiendo con IA…",
                                  lambda: generar_texto(self.app.cfg["api_key"], self.app.cfg["modelo_ia"], p), fin)



# ============================================================================ vista: diseño de la web
class VistaDiseno(ctk.CTkFrame):
    MINIATURAS = Path(__file__).resolve().parent / "nucleo" / "previas"

    def __init__(self, app):
        super().__init__(app.contenedor, fg_color="transparent")
        self.app = app
        self._imgs = {}
        self._tarjetas = {}
        self._programado = None

        cab = ctk.CTkFrame(self, fg_color="transparent")
        cab.pack(fill="x", padx=28, pady=(22, 6))
        izq = ctk.CTkFrame(cab, fg_color="transparent")
        izq.pack(side="left")
        ctk.CTkLabel(izq, text="Diseño de la web", font=fuente_titulo(28)).pack(anchor="w")
        ctk.CTkLabel(izq, text="Los cambios se ven al momento en la vista previa; «Publicar» los sube a tu web.",
                     text_color=tema.TINTA_2, font=fuente(14)).pack(anchor="w")
        boton(cab, "🚀  Publicar", app.publicar).pack(side="right", padx=(8, 0))
        boton(cab, "👁  Vista previa en vivo", app.vista_previa, "secundario").pack(side="right", padx=(8, 0))

        self.cuerpo = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.cuerpo.pack(fill="both", expand=True, padx=18, pady=(4, 12))
        self._construir()

    # ------------------------------------------------------------------ util
    @property
    def d(self):
        return D.normalizar(self.app.cfg.get("diseno"))

    def poner(self, clave, valor):
        d = dict(self.app.cfg.get("diseno") or {})
        d[clave] = valor
        self.app.cfg["diseno"] = d
        self.app.cfg.guardar()
        self._marcar()
        self.app.previa_cambiada()

    def _seccion(self, titulo, ayuda=""):
        t = ctk.CTkFrame(self.cuerpo, corner_radius=14)
        t.pack(fill="x", padx=8, pady=8)
        ctk.CTkLabel(t, text=titulo, font=fuente_titulo(19)).pack(anchor="w", padx=18, pady=(14, 0))
        if ayuda:
            ctk.CTkLabel(t, text=ayuda, text_color=tema.TINTA_2).pack(anchor="w", padx=18)
        dentro = ctk.CTkFrame(t, fg_color="transparent")
        dentro.pack(fill="x", padx=12, pady=(8, 14))
        return dentro

    def _opcion(self, padre, grupo, valor, col, crear):
        """Tarjeta seleccionable; 'crear' rellena su interior."""
        f = ctk.CTkFrame(padre, corner_radius=12, border_width=3, fg_color=tema.TARJETA_2, cursor="hand2")
        f.grid(row=0, column=col, padx=6, pady=4, sticky="nsew")
        padre.columnconfigure(col, weight=1)
        crear(f)
        for w in [f] + list(f.winfo_children()) + [x for c in f.winfo_children() for x in c.winfo_children()]:
            w.bind("<Button-1>", lambda ev, g=grupo, v=valor: self.poner(g, v))
        self._tarjetas.setdefault(grupo, {})[valor] = f

    def _marcar(self):
        d = self.d
        for grupo, opciones in self._tarjetas.items():
            for valor, f in opciones.items():
                f.configure(border_color=tema.ACENTO if d.get(grupo) == valor else tema.TARJETA_2)
        for clave, var in getattr(self, "_vars", {}).items():
            var.set(bool(d.get(clave)))
        if hasattr(self, "seg_modo"):
            self.seg_modo.set({"auto": "Automático", "claro": "Siempre claro", "oscuro": "Siempre oscuro"}[d["modo"]])
            self.seg_orden.set("Mapa arriba" if d["mapa_primero"] else "Pueblos arriba")

    # ------------------------------------------------------------------ construcción
    def _construir(self):
        cfg = self.app.cfg
        # --- textos
        t = self._seccion("Textos", "Título, subtítulo y autor que aparecen en la web.")
        t.columnconfigure(1, weight=1)
        self._textos = {}
        for i, (clave, etiqueta) in enumerate((("titulo_web", "Título"), ("subtitulo_web", "Subtítulo"), ("autor", "Autor (pie de página)"))):
            ctk.CTkLabel(t, text=etiqueta, text_color=tema.TINTA_2).grid(row=i, column=0, sticky="w", padx=8, pady=5)
            e = ctk.CTkEntry(t, height=32)
            e.insert(0, cfg.get(clave, "") or "")
            e.grid(row=i, column=1, sticky="ew", padx=8, pady=5)
            e.bind("<KeyRelease>", lambda ev, c=clave, w=e: self._texto_cambiado(c, w))
            self._textos[clave] = e

        # --- cabecera
        t = self._seccion("Cabecera", "Cómo empieza tu página principal.")
        for col, (valor, (nombre, desc)) in enumerate(D.CABECERAS.items()):
            def crear(f, valor=valor, nombre=nombre, desc=desc):
                ruta = self.MINIATURAS / f"cabecera_{valor}.png"
                if ruta.exists():
                    with Image.open(ruta) as im:
                        pil = im.convert("RGB")
                    self._imgs[valor] = ctk.CTkImage(light_image=pil, dark_image=pil, size=(220, int(220 * pil.height / pil.width)))
                    ctk.CTkLabel(f, text="", image=self._imgs[valor]).pack(padx=6, pady=(6, 0))
                ctk.CTkLabel(f, text=nombre, font=fuente(14, "bold")).pack(anchor="w", padx=10, pady=(6, 0))
                ctk.CTkLabel(f, text=desc, text_color=tema.TINTA_2, font=fuente(11), wraplength=210,
                             justify="left").pack(anchor="w", padx=10, pady=(0, 8))
            self._opcion(t, "cabecera", valor, col, crear)

        # --- colores
        t = self._seccion("Colores", "La paleta de toda la web (y del mapa).")
        for col, (valor, (nombre, claro, oscuro)) in enumerate(D.PALETAS.items()):
            def crear(f, nombre=nombre, claro=claro, oscuro=oscuro):
                fila = ctk.CTkFrame(f, fg_color="transparent")
                fila.pack(padx=10, pady=(10, 2))
                for k in ("papel", "acento", "acento-2", "pendiente", "tinta"):
                    ctk.CTkFrame(fila, width=26, height=26, corner_radius=13, fg_color=claro[k],
                                 border_width=1, border_color="#bbbbbb").pack(side="left", padx=2)
                fila2 = ctk.CTkFrame(f, fg_color="transparent")
                fila2.pack(padx=10, pady=(2, 4))
                for k in ("papel", "acento", "acento-2", "pendiente", "tinta"):
                    ctk.CTkFrame(fila2, width=14, height=14, corner_radius=7, fg_color=oscuro[k]).pack(side="left", padx=3)
                ctk.CTkLabel(f, text=nombre, font=fuente(13, "bold")).pack(pady=(2, 10))
            self._opcion(t, "paleta", valor, col, crear)
        ctk.CTkLabel(t, text="Arriba los colores de día; abajo, los de modo oscuro.", text_color=tema.TINTA_2,
                     font=fuente(11)).grid(row=1, column=0, columnspan=5, sticky="w", padx=8)

        # --- modo
        t = self._seccion("Modo claro / oscuro", "«Automático» sigue la configuración del móvil u ordenador de quien visita la web.")
        self.seg_modo = ctk.CTkSegmentedButton(t, values=["Automático", "Siempre claro", "Siempre oscuro"], height=34,
                                               command=lambda v: self.poner("modo", {"Automático": "auto", "Siempre claro": "claro", "Siempre oscuro": "oscuro"}[v]))
        self.seg_modo.pack(anchor="w", padx=8)

        # --- tipografía
        t = self._seccion("Tipografía", "Letra de los títulos y del texto.")
        for col, (valor, (nombre, f_tit, f_txt, _)) in enumerate(D.TIPOGRAFIAS.items()):
            def crear(f, nombre=nombre, f_tit=f_tit, f_txt=f_txt):
                ctk.CTkLabel(f, text="Aa", font=ctk.CTkFont(family=f_tit.split(",")[0].strip('"'), size=30, weight="bold")).pack(pady=(8, 0))
                ctk.CTkLabel(f, text=nombre, font=fuente(13, "bold")).pack()
                ctk.CTkLabel(f, text=f"{f_tit.split(',')[0].strip(chr(34))} + {f_txt.split(',')[0].strip(chr(34))}",
                             text_color=tema.TINTA_2, font=fuente(11), wraplength=150).pack(padx=8, pady=(0, 10))
            self._opcion(t, "tipografia", valor, col, crear)

        # --- fondo y secciones
        t = self._seccion("Fondo y secciones")
        self._vars = {}
        opciones = (("azulejos", "Fondo de azulejos"), ("bandas", "Bandas de color"), ("mostrar_mapa", "Mostrar el mapa"),
                    ("mostrar_extra", "«Qué ver» y «Para saber más» en cada pueblo"))
        for i, (clave, texto) in enumerate(opciones):
            var = tk.BooleanVar(value=bool(self.d.get(clave)))
            ctk.CTkSwitch(t, text=texto, variable=var, command=lambda c=clave, v=var: self.poner(c, v.get())).grid(
                row=i // 2, column=i % 2, sticky="w", padx=10, pady=6)
            self._vars[clave] = var
        self.var_pend = tk.BooleanVar(value=self.app.cfg.get("mostrar_pendientes", True))
        ctk.CTkSwitch(t, text="Mostrar mis pueblos «por visitar»", variable=self.var_pend,
                      command=self._pendientes).grid(row=2, column=0, sticky="w", padx=10, pady=6)
        fila = ctk.CTkFrame(t, fg_color="transparent")
        fila.grid(row=3, column=0, columnspan=2, sticky="w", padx=6, pady=(8, 0))
        ctk.CTkLabel(fila, text="Orden:").pack(side="left", padx=(4, 10))
        self.seg_orden = ctk.CTkSegmentedButton(fila, values=["Mapa arriba", "Pueblos arriba"], height=32,
                                                command=lambda v: self.poner("mapa_primero", v == "Mapa arriba"))
        self.seg_orden.pack(side="left")

        # --- logo
        t = self._seccion("Logo / icono", "Se ve junto al título y en la pestaña del navegador. Mejor una imagen cuadrada.")
        fila = ctk.CTkFrame(t, fg_color="transparent")
        fila.pack(anchor="w", padx=6)
        self.lbl_logo = ctk.CTkLabel(fila, text="", width=72, height=72, fg_color=tema.TARJETA_2, corner_radius=14)
        self.lbl_logo.pack(side="left", padx=(4, 14))
        boton(fila, "Elegir imagen…", self._elegir_logo, "secundario").pack(side="left", padx=4)
        boton(fila, "Quitar", self._quitar_logo, "fantasma", width=80).pack(side="left", padx=4)
        self._pintar_logo()
        self._marcar()

    # ------------------------------------------------------------------ acciones
    def refrescar(self):
        self._marcar()

    def _texto_cambiado(self, clave, entrada):
        self.app.cfg[clave] = entrada.get().strip()
        self.app.cfg.guardar()
        self.app.previa_cambiada()

    def _pendientes(self):
        self.app.cfg["mostrar_pendientes"] = self.var_pend.get()
        self.app.cfg.guardar()
        self.app.previa_cambiada()

    def _pintar_logo(self):
        ruta = self.app.cfg.get("logo_ruta")
        if ruta and Path(ruta).exists():
            with Image.open(ruta) as im:
                pil = im.convert("RGBA")
            self._imgs["logo"] = ctk.CTkImage(light_image=pil, dark_image=pil, size=(72, 72))
            self.lbl_logo.configure(image=self._imgs["logo"], text="")
        else:
            self.lbl_logo.configure(image=None, text="Sin logo", text_color=tema.TINTA_2)

    def _elegir_logo(self):
        ruta = filedialog.askopenfilename(parent=self, title="Elige tu logo o icono",
                                          filetypes=[("Imágenes", "*.png *.jpg *.jpeg *.webp"), ("Todos", "*.*")])
        if not ruta:
            return
        try:
            with Image.open(ruta) as im:
                im = ImageOps.exif_transpose(im).convert("RGBA")
                lado = min(im.size)
                im = im.crop(((im.width - lado) // 2, (im.height - lado) // 2,
                              (im.width + lado) // 2, (im.height + lado) // 2)).resize((256, 256), Image.LANCZOS)
            destino = BASE / "diseno" / "logo.png"
            destino.parent.mkdir(parents=True, exist_ok=True)
            im.save(destino, "PNG", optimize=True)
        except Exception as ex:  # noqa: BLE001
            messagebox.showerror(NOMBRE_PROGRAMA, f"No he podido abrir esa imagen:\n{ex}")
            return
        self.app.cfg["logo_ruta"] = str(destino)
        self.app.cfg.guardar()
        self._pintar_logo()
        self.app.previa_cambiada()

    def _quitar_logo(self):
        self.app.cfg["logo_ruta"] = ""
        self.app.cfg.guardar()
        self._pintar_logo()
        self.app.previa_cambiada()

# ============================================================================ aplicación
class App(ctk.CTk):
    def __init__(self):
        self.cfg = Config()
        tema.aplicar(self.cfg.get("tema", "System"))
        super().__init__()
        self.title(f"{NOMBRE_PROGRAMA} {VERSION} — Mis pueblos")
        self.geometry("1320x860")
        self.minsize(1080, 700)
        self.almacen = Almacen(self.cfg.datos)
        self.geo = Geocodificador(self.cfg.user_agent, self.cfg.datos / "_cache_geo.json")
        self.wiki = Wikipedia(self.cfg.user_agent)
        self.commons = Commons(self.cfg.user_agent)
        self.actual = None
        self.vista = None
        self.vista_anterior = "mapa"
        self._cache_img = {}
        self.cola = queue.Queue()
        self.ocupado = False

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._barra_lateral()
        derecha = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        derecha.grid(row=0, column=1, sticky="nsew")
        derecha.rowconfigure(0, weight=1)
        derecha.columnconfigure(0, weight=1)
        self.contenedor = ctk.CTkFrame(derecha, fg_color="transparent", corner_radius=0)
        self.contenedor.grid(row=0, column=0, sticky="nsew")
        estado = ctk.CTkFrame(derecha, fg_color=tema.TARJETA_2, corner_radius=0, height=34)
        estado.grid(row=1, column=0, sticky="ew")
        self.lbl_estado = ctk.CTkLabel(estado, text="Listo.", text_color=tema.TINTA_2, font=fuente(12))
        self.lbl_estado.pack(side="left", padx=16, pady=4)
        self.progreso = ctk.CTkProgressBar(estado, width=220, height=6)
        self.progreso.set(0)

        self.vistas = {"mapa": VistaMapa(self), "visitados": VistaLista(self, "visitado"),
                       "pendientes": VistaLista(self, "pendiente"), "diseno": VistaDiseno(self), "editor": VistaEditor(self)}
        self._previa_abierta = False
        self._previa_trabajo = None
        self._previa_hilo = None
        self._actualizacion_preguntada = False
        configurar_token(self.cfg.get("github_token"))
        self.mostrar("mapa")
        self.after(100, self._atender_cola)
        self.protocol("WM_DELETE_WINDOW", self.salir)
        self.after(600, lambda: self.sincronizar(silencioso=True))

    # ------------------------------------------------------------------ barra lateral
    def _barra_lateral(self):
        lat = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color=tema.LATERAL)
        lat.grid(row=0, column=0, sticky="nsw")
        lat.grid_propagate(False)
        lat.pack_propagate(False)
        ctk.CTkLabel(lat, text="PUEBLOS", font=fuente_titulo(24), text_color=tema.LATERAL_TEXTO).pack(
            anchor="w", padx=22, pady=(24, 0))
        ctk.CTkLabel(lat, text=f"cuaderno de viaje · {VERSION}", font=fuente(11),
                     text_color=tema.LATERAL_TEXTO_2).pack(anchor="w", padx=22, pady=(0, 22))
        self.nav = {}
        for clave, texto in (("mapa", "🗺   Mapa"), ("visitados", "🏘   Visitados"), ("pendientes", "📌   Por visitar"),
                             ("diseno", "🎨   Diseño")):
            b = ctk.CTkButton(lat, text=texto, anchor="w", height=40, corner_radius=8, font=fuente(14),
                              fg_color="transparent", hover_color=tema.LATERAL_HOVER, text_color=tema.LATERAL_TEXTO,
                              command=lambda c=clave: self.mostrar(c))
            b.pack(fill="x", padx=12, pady=2)
            self.nav[clave] = b
        ctk.CTkFrame(lat, height=1, fg_color=tema.LATERAL_HOVER).pack(fill="x", padx=20, pady=16)
        for texto, cmd in (("📷   Importar fotos", self.importar), ("＋   Nuevo pueblo", lambda: self.nuevo("visitado"))):
            ctk.CTkButton(lat, text=texto, anchor="w", height=36, corner_radius=8, font=fuente(13),
                          fg_color="transparent", hover_color=tema.LATERAL_HOVER, text_color=tema.LATERAL_TEXTO_2,
                          command=cmd).pack(fill="x", padx=12, pady=1)

        abajo = ctk.CTkFrame(lat, fg_color="transparent")
        abajo.pack(side="bottom", fill="x", padx=12, pady=16)
        ctk.CTkButton(abajo, text="🚀   Publicar", height=42, corner_radius=10, font=fuente(14, "bold"),
                      command=self.publicar).pack(fill="x", pady=(0, 6))
        self.btn_sinc = ctk.CTkButton(abajo, text="⟳   Sincronizar", height=36, corner_radius=8, font=fuente(13),
                                      fg_color="transparent", hover_color=tema.LATERAL_HOVER,
                                      text_color=tema.LATERAL_TEXTO_2, anchor="w", command=self.sincronizar)
        self.btn_sinc.pack(fill="x", pady=1)
        ctk.CTkButton(abajo, text="👁   Vista previa", height=36, corner_radius=8, font=fuente(13),
                      fg_color=tema.LATERAL_HOVER, hover_color=tema.ACENTO_HOVER, text_color=tema.LATERAL_TEXTO,
                      command=self.vista_previa).pack(fill="x", pady=3)
        ctk.CTkButton(abajo, text="🌐   Abrir mi web", height=36, corner_radius=8, font=fuente(13),
                      fg_color="transparent", hover_color=tema.LATERAL_HOVER, text_color=tema.LATERAL_TEXTO_2,
                      anchor="w", command=self.abrir_web).pack(fill="x", pady=1)
        ctk.CTkButton(abajo, text="📱   Panel del móvil", height=36, corner_radius=8, font=fuente(13),
                      fg_color="transparent", hover_color=tema.LATERAL_HOVER, text_color=tema.LATERAL_TEXTO_2,
                      anchor="w", command=self.abrir_panel).pack(fill="x", pady=1)
        ctk.CTkButton(abajo, text="⚙   Ajustes", height=36, corner_radius=8, font=fuente(13), anchor="w",
                      fg_color="transparent", hover_color=tema.LATERAL_HOVER, text_color=tema.LATERAL_TEXTO_2,
                      command=self.ajustes).pack(fill="x", pady=1)
        actual = next((k for k, v in TEMAS.items() if v == self.cfg.get("tema", "System")), "Sistema")
        menu = ctk.CTkOptionMenu(abajo, values=list(TEMAS), command=self._cambiar_tema, height=30, font=fuente(12))
        menu.set(actual)
        menu.pack(fill="x", pady=(10, 0))

    def _cambiar_tema(self, nombre):
        self.cfg["tema"] = TEMAS[nombre]
        self.cfg.guardar()
        ctk.set_appearance_mode(TEMAS[nombre])
        self.after(150, self.vistas["mapa"].programar)

    # ------------------------------------------------------------------ navegación
    def mostrar(self, clave, recargar=True):
        if self.vista == "editor" and clave != "editor":
            self.vistas["editor"].guardar(silencioso=True)
        for v in self.vistas.values():
            v.pack_forget()
        self.vistas[clave].pack(fill="both", expand=True)
        if clave != "editor":
            self.vista_anterior = clave
            if recargar:
                self.vistas[clave].refrescar()
        self.vista = clave
        if clave == "editor" and self.actual:
            seccion = "pendientes" if self.actual.get("estado") == "pendiente" else "visitados"
        else:
            seccion = clave
        for k, b in self.nav.items():
            activo = k == seccion
            b.configure(fg_color=tema.ACENTO if activo else "transparent")

    def volver(self, guardar=True):
        if guardar and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        self.actual = None
        self.vista = None
        self.mostrar(self.vista_anterior)

    def abrir(self, slug, recargar=False):
        if self.vista == "editor" and self.actual and self.actual.get("slug") != slug:
            self.vistas["editor"].guardar(silencioso=True)
        try:
            self.actual = self.almacen.cargar(slug)
        except OSError:
            return
        if recargar:
            self._cache_img = {k: v for k, v in self._cache_img.items() if k[0] != slug}
        self.mostrar("editor")
        self.vistas["editor"].cargar()

    # ------------------------------------------------------------------ imágenes
    def miniatura(self, slug, archivo, ancho, alto):
        if not archivo:
            return None
        clave = (slug, archivo, ancho, alto)
        if clave not in self._cache_img:
            ruta = self.almacen.carpeta_pueblo(slug) / "mini" / archivo
            if not ruta.exists():
                ruta = self.almacen.carpeta_pueblo(slug) / "fotos" / archivo
            try:
                with Image.open(ruta) as im:
                    pil = recorte(im, ancho * 2, alto * 2)
                self._cache_img[clave] = ctk.CTkImage(light_image=pil, dark_image=pil, size=(ancho, alto))
            except Exception:  # noqa: BLE001
                return None
        return self._cache_img[clave]

    # ------------------------------------------------------------------ diálogos genéricos
    def dialogo(self, titulo, ancho, alto):
        v = ctk.CTkToplevel(self)
        v.title(titulo)
        v.geometry(f"{ancho}x{alto}+{self.winfo_rootx() + 120}+{self.winfo_rooty() + 60}")
        v.transient(self)

        def enfocar():
            try:
                v.lift()
                v.focus_force()
                v.grab_set()
            except tk.TclError:
                pass
        v.after(150, enfocar)
        return v

    def pedir_texto(self, titulo, texto, inicial=""):
        v = self.dialogo(titulo, 480, 210 if "\n" in texto else 190)
        ctk.CTkLabel(v, text=texto, font=fuente(14), justify="left").pack(anchor="w", padx=20, pady=(20, 6))
        var = tk.StringVar(value=inicial)
        e = ctk.CTkEntry(v, textvariable=var, height=36)
        e.pack(fill="x", padx=20)
        e.after(250, e.focus_set)
        res = {}

        def ok(_=None):
            res["t"] = var.get()
            v.destroy()
        e.bind("<Return>", ok)
        b = ctk.CTkFrame(v, fg_color="transparent")
        b.pack(fill="x", padx=20, pady=18)
        boton(b, "Aceptar", ok, width=100).pack(side="right")
        boton(b, "Cancelar", v.destroy, "secundario", width=100).pack(side="right", padx=8)
        self.wait_window(v)
        return res.get("t")

    def elegir_lugar(self, resultados):
        v = self.dialogo("¿Cuál es?", 680, 420)
        ctk.CTkLabel(v, text="Hay varios lugares con ese nombre. Elige el tuyo:", font=fuente(14)).pack(
            anchor="w", padx=20, pady=(18, 8))
        lista = ctk.CTkScrollableFrame(v)
        lista.pack(fill="both", expand=True, padx=20)
        res = {}

        def elegir(r):
            res["r"] = r
            v.destroy()
        for r in resultados:
            boton(lista, r["descripcion"][:95], lambda r=r: elegir(r), "fantasma", anchor="w").pack(fill="x", pady=1)
        boton(v, "Cancelar", v.destroy, "secundario", width=100).pack(anchor="e", padx=20, pady=14)
        self.wait_window(v)
        return res.get("r")

    # ------------------------------------------------------------------ pueblos nuevos
    def nuevo(self, estado="visitado", provincia=""):
        titulo = "Nuevo pueblo visitado" if estado == "visitado" else "Pueblo por visitar"
        nombre = self.pedir_texto(titulo, "Nombre del pueblo:")
        if not nombre or not nombre.strip():
            return
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        fecha = ""
        if estado == "visitado":
            fecha = self.pedir_fecha("¿Cuándo lo visitaste? (opcional)")
            if fecha is None:
                return
        p = pueblo_vacio(nombre.strip())
        p["estado"] = estado
        p["provincia"] = provincia
        if fecha:
            p["fechas_visita"] = [fecha]
        self.almacen.guardar(p)
        if estado == "pendiente":
            self.vista_anterior = "pendientes"
        elif self.vista_anterior == "pendientes":
            self.vista_anterior = "visitados"
        self.abrir(p["slug"])
        ed = self.vistas["editor"]
        # Ubicación -> Wikipedia -> fotos de internet (si no tiene)
        ed.buscar_ubicacion(despues=lambda: ed.traer_wiki(despues=self._ofrecer_fotos_internet))

    def _ofrecer_fotos_internet(self):
        if self.actual and not self.actual["fotos"] and messagebox.askyesno(
                NOMBRE_PROGRAMA, "Este pueblo aún no tiene fotos. Si no tienes fotos tuyas, puedes poner fotos libres "
                                 "de internet (Wikimedia Commons).\n\n¿Las busco ahora?"):
            self.fotos_internet()

    def pedir_fecha(self, texto, inicial=""):
        """Devuelve 'AAAA-MM-DD', 'AAAA-MM', 'AAAA', '' (no lo recuerda) o None (cancelado)."""
        import re
        while True:
            t = self.pedir_texto("Fecha de la visita", texto + "\nAAAA-MM-DD, AAAA-MM o solo el año. "
                                 "Déjalo vacío si no lo recuerdas.", inicial)
            if t is None:
                return None
            t = t.strip()
            if not t or fecha_ok(t):
                return t
            messagebox.showwarning(NOMBRE_PROGRAMA, "Escribe la fecha como 2024-05-12, 2024-05 o 2024.")
            inicial = t

    def aplicar_wiki(self, p, d):
        if not d:
            return False
        d = dict(d)
        lat, lon = d.pop("lat", None), d.pop("lon", None)
        if p.get("lat") is None and lat is not None:
            p["lat"], p["lon"] = round(lat, 6), round(lon, 6)
        p["wiki"] = d
        return True

    # ------------------------------------------------------------------ fotos de internet
    def fotos_internet(self):
        if not self.actual:
            return
        self.vistas["editor"].leer()
        p = self.actual
        if not p["nombre"]:
            return

        def fin(items):
            ya = {f.get("original") for f in p["fotos"]}
            items = [it for it in items if it["pagina"] not in ya]
            if not items:
                messagebox.showinfo(NOMBRE_PROGRAMA, "No he encontrado fotos libres nuevas de este pueblo.\n"
                                    "Comprueba el nombre, la provincia y la ubicación.")
                return
            self._dialogo_commons(p, items)
        self.en_segundo_plano("Buscando fotos libres en Wikimedia Commons…",
                              lambda: self.commons.buscar(p["nombre"], p["provincia"], p["lat"], p["lon"]), fin)

    def _dialogo_commons(self, p, items):
        v = self.dialogo(f"Fotos de internet — {p['nombre']}", 1040, 720)
        ctk.CTkLabel(v, text="Fotos de uso libre de Wikimedia Commons", font=fuente_titulo(20)).pack(
            anchor="w", padx=20, pady=(16, 0))
        ctk.CTkLabel(v, text="Marca las que quieras. En la web se mostrará su autor y licencia, como exigen. "
                             "Algunas pueden no ser del pueblo exacto: revísalas.", text_color=tema.TINTA_2).pack(
            anchor="w", padx=20, pady=(0, 8))
        rejilla = ctk.CTkScrollableFrame(v)
        rejilla.pack(fill="both", expand=True, padx=20)
        columnas = 5
        for c in range(columnas):
            rejilla.columnconfigure(c, weight=1)
        imagenes, marcas, etiquetas = {}, [], []
        v._imagenes = imagenes  # que no se borren de memoria mientras la ventana esté abierta
        for i, it in enumerate(items):
            caja = ctk.CTkFrame(rejilla, corner_radius=10, fg_color=tema.TARJETA_2)
            caja.grid(row=i // columnas, column=i % columnas, padx=5, pady=5, sticky="n")
            lbl = ctk.CTkLabel(caja, text="cargando…", width=170, height=170, text_color=tema.TINTA_2)
            lbl.pack(padx=4, pady=(4, 0))
            var = tk.BooleanVar(value=False)
            ctk.CTkCheckBox(caja, variable=var, text=it["autor"][:22], font=fuente(12)).pack(anchor="w", padx=8, pady=(6, 0))
            ctk.CTkLabel(caja, text=it["licencia"][:30], text_color=tema.TINTA_2, font=fuente(11)).pack(
                anchor="w", padx=8, pady=(0, 6))
            lbl.bind("<Button-1>", lambda ev, x=var: x.set(not x.get()))
            lbl.bind("<Double-Button-1>", lambda ev, u=it["pagina"]: webbrowser.open(u))
            marcas.append((var, it))
            etiquetas.append(lbl)

        def poner(n, datos):
            try:
                if not v.winfo_exists():
                    return
                with Image.open(io.BytesIO(datos)) as im:
                    pil = recorte(im, 340, 340)
                imagenes[n] = ctk.CTkImage(light_image=pil, dark_image=pil, size=(170, 170))
                etiquetas[n].configure(image=imagenes[n], text="")
            except Exception:  # noqa: BLE001
                try:
                    etiquetas[n].configure(text="(sin vista previa)")
                except tk.TclError:
                    pass

        cerrado = threading.Event()
        v.bind("<Destroy>", lambda ev: cerrado.set() if ev.widget is v else None)

        def cargar():
            for n, it in enumerate(items):
                if cerrado.is_set():
                    return
                try:
                    datos = self.commons.miniatura(it["miniatura"])
                except Exception:  # noqa: BLE001
                    continue
                self.cola.put(("llamar", lambda n=n, d=datos: poner(n, d)))
        threading.Thread(target=cargar, daemon=True).start()

        abajo = ctk.CTkFrame(v, fg_color="transparent")
        abajo.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(abajo, text=f"{len(items)} fotos encontradas · doble clic para verla en Commons",
                     text_color=tema.TINTA_2).pack(side="left")

        def aceptar():
            elegidas = [it for var, it in marcas if var.get()]
            if not elegidas:
                messagebox.showinfo(NOMBRE_PROGRAMA, "No has marcado ninguna foto.", parent=v)
                return
            v.destroy()
            if self.vista == "editor":
                self.vistas["editor"].guardar(silencioso=True)
            pueblo = self.actual or p

            def tarea():
                return I.anadir_fotos_internet(self.almacen, pueblo, elegidas, self.commons,
                                               int(self.cfg["lado_foto"]), self._progreso)

            def fin(res):
                n, fallos = res
                self.abrir(pueblo["slug"], recargar=True)
                self.estado(f"Añadidas {n} fotos de internet" + (f" ({fallos} no se pudieron bajar)." if fallos else "."))
            self.en_segundo_plano("Descargando fotos…", tarea, fin)
        boton(abajo, "Añadir las marcadas", aceptar).pack(side="right")
        boton(abajo, "Cancelar", v.destroy, "secundario", width=100).pack(side="right", padx=8)

    # ------------------------------------------------------------------ importar
    def importar(self):
        carpeta = filedialog.askdirectory(parent=self, title="Elige la carpeta con las fotos del viaje")
        if not carpeta:
            return
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        rutas = F.buscar_fotos(Path(carpeta))
        if not rutas:
            messagebox.showinfo(NOMBRE_PROGRAMA, "No he encontrado fotos en esa carpeta.")
            return
        self._carpeta_import = Path(carpeta).name
        self.en_segundo_plano(f"Leyendo la ubicación de {len(rutas)} fotos…",
                              lambda: I.analizar(rutas, self.geo, self._progreso), self._confirmar_importacion)

    def _confirmar_importacion(self, resultado):
        grupos, sin_asignar, por_hora = resultado
        v = self.dialogo("Pueblos encontrados en las fotos", 760, 620)
        ctk.CTkLabel(v, text="Pueblos encontrados", font=fuente_titulo(22)).pack(anchor="w", padx=20, pady=(18, 0))
        marcas = []
        cuerpo = ctk.CTkScrollableFrame(v, fg_color="transparent")
        cuerpo.pack(fill="both", expand=True, padx=12, pady=(6, 0))
        if grupos:
            ctk.CTkLabel(cuerpo, text="Marca los que quieras añadir:", text_color=tema.TINTA_2).pack(anchor="w", padx=8)
            for clave, g in sorted(grupos.items(), key=lambda kv: -len(kv[1]["fotos"])):
                info = g["info"]
                existente = self.almacen.buscar(info["nombre"], info["provincia"])
                var = tk.BooleanVar(value=True)
                fechas = ", ".join(sorted(g["fechas"])) or "sin fecha"
                extra = f" (de ellas {g['por_hora']} sin GPS, por la hora)" if g["por_hora"] else ""
                aviso = ""
                if existente and existente.get("estado") == "pendiente":
                    aviso = "   ✓ ¡estaba en tu lista de pendientes!"
                elif existente:
                    aviso = "   · ya existe: se añaden las fotos"
                tarjeta = ctk.CTkFrame(cuerpo, corner_radius=10)
                tarjeta.pack(fill="x", padx=6, pady=4)
                ctk.CTkCheckBox(tarjeta, variable=var, font=fuente(14, "bold"),
                                text=f"{info['nombre']}  ·  {info['provincia']}").pack(anchor="w", padx=12, pady=(10, 0))
                ctk.CTkLabel(tarjeta, text=f"{len(g['fotos'])} fotos{extra} · {fechas}{aviso}",
                             text_color=tema.TINTA_2).pack(anchor="w", padx=44, pady=(0, 10))
                marcas.append((var, clave, g))
        else:
            ctk.CTkLabel(cuerpo, text="Ninguna foto tiene ubicación GPS (o no hay conexión a Internet).",
                         text_color=tema.TINTA_2).pack(anchor="w", padx=8)
        if por_hora:
            ctk.CTkLabel(cuerpo, text=f"{por_hora} fotos sin GPS se han colocado en su pueblo por la hora en que se hicieron.",
                         text_color=tema.TINTA_2).pack(anchor="w", padx=8, pady=(6, 0))

        opciones_resto = [("nada", None, "No añadirlas")]
        for clave, g in sorted(grupos.items(), key=lambda kv: -len(kv[1]["fotos"])):
            opciones_resto.append(("grupo", clave, f"A {g['info']['nombre']} (encontrado ahora)"))
        for p in sorted(self.almacen.listar(), key=lambda x: normalizar(x["nombre"])):
            opciones_resto.append(("existente", p["slug"], f"A {p['nombre']} ({p['provincia'] or 'sin provincia'})"))
        opciones_resto.append(("nuevo", None, "A un pueblo nuevo…"))
        v_resto = tk.StringVar()
        v_nombre_nuevo = tk.StringVar(value=getattr(self, "_carpeta_import", ""))
        if sin_asignar:
            caja = ctk.CTkFrame(cuerpo, corner_radius=10, border_width=1, border_color=tema.LINEA)
            caja.pack(fill="x", padx=6, pady=(12, 4))
            ctk.CTkLabel(caja, text=f"{len(sin_asignar)} fotos sin ubicación", font=fuente(14, "bold")).grid(
                row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(10, 4))
            ctk.CTkLabel(caja, text="¿A qué pueblo las añado?").grid(row=1, column=0, sticky="w", padx=12, pady=4)
            entrada = ctk.CTkEntry(caja, textvariable=v_nombre_nuevo, width=300)
            etiqueta_nuevo = ctk.CTkLabel(caja, text="Nombre del pueblo nuevo:")

            def al_cambiar(valor=None):
                if v_resto.get() == opciones_resto[-1][2]:
                    etiqueta_nuevo.grid(row=2, column=0, sticky="w", padx=12, pady=(4, 12))
                    entrada.grid(row=2, column=1, sticky="w", padx=8, pady=(4, 12))
                else:
                    etiqueta_nuevo.grid_remove()
                    entrada.grid_remove()
            combo = ctk.CTkComboBox(caja, variable=v_resto, values=[o[2] for o in opciones_resto], width=340,
                                    state="readonly", command=al_cambiar)
            combo.grid(row=1, column=1, sticky="w", padx=8, pady=4)
            v_resto.set(opciones_resto[-1][2] if not grupos else opciones_resto[0][2])
            al_cambiar()

        opc = ctk.CTkFrame(v, fg_color="transparent")
        opc.pack(fill="x", padx=20, pady=(10, 0))
        v_wiki = tk.BooleanVar(value=self.cfg["traer_wiki_al_importar"])
        v_ia = tk.BooleanVar(value=self.cfg["generar_ia_al_importar"] and bool(self.cfg["api_key"]))
        ctk.CTkCheckBox(opc, text="Traer datos de Wikipedia de los pueblos nuevos", variable=v_wiki).pack(anchor="w", pady=2)
        cb_ia = ctk.CTkCheckBox(opc, text="Escribir el texto con IA de los pueblos nuevos", variable=v_ia)
        cb_ia.pack(anchor="w", pady=2)
        if not self.cfg["api_key"]:
            cb_ia.configure(state="disabled")

        def aceptar():
            elegidos = {clave: g for var, clave, g in marcas if var.get()}
            resto = None
            if sin_asignar:
                tipo, ref, _ = next(o for o in opciones_resto if o[2] == v_resto.get())
                if tipo == "grupo":
                    elegidos.setdefault(ref, grupos[ref])
                    resto = ("grupo", ref, sin_asignar)
                elif tipo == "existente":
                    resto = ("existente", ref, sin_asignar)
                elif tipo == "nuevo":
                    nombre = v_nombre_nuevo.get().strip()
                    if not nombre:
                        messagebox.showwarning(NOMBRE_PROGRAMA, "Escribe el nombre del pueblo nuevo.", parent=v)
                        return
                    resto = ("nuevo", nombre, sin_asignar)
            self.cfg["traer_wiki_al_importar"] = v_wiki.get()
            self.cfg["generar_ia_al_importar"] = v_ia.get()
            self.cfg.guardar()
            v.destroy()
            if elegidos or resto:
                self._aplicar_importacion(elegidos, resto, v_wiki.get(), v_ia.get())
        b = ctk.CTkFrame(v, fg_color="transparent")
        b.pack(fill="x", padx=20, pady=16)
        boton(b, "Añadir", aceptar, width=120).pack(side="right")
        boton(b, "Cancelar", v.destroy, "secundario", width=100).pack(side="right", padx=8)

    def _completar_nuevo(self, p, con_wiki, con_ia, avisos):
        if con_wiki and not p["wiki"].get("extracto"):
            self.cola.put(("estado", f"{p['nombre']}: Wikipedia…"))
            try:
                self.aplicar_wiki(p, self.wiki.todo(p["nombre"], p["provincia"], p["lat"], p["lon"]))
            except Exception as ex:  # noqa: BLE001
                avisos.append(f"{p['nombre']}: Wikipedia ({ex})")
        if con_ia and not p["texto_ia"]:
            self.cola.put(("estado", f"{p['nombre']}: texto con IA…"))
            try:
                p["texto_ia"] = generar_texto(self.cfg["api_key"], self.cfg["modelo_ia"], p)
            except ErrorIA as ex:
                avisos.append(f"{p['nombre']}: IA ({ex})")

    def _aplicar_importacion(self, grupos, resto, con_wiki, con_ia):
        lado = int(self.cfg["lado_foto"])
        if resto and resto[0] == "grupo":
            grupos[resto[1]]["fotos"].extend(resto[2])

        def tarea():
            hechos, avisos, cumplidos = [], [], []
            lista = list(grupos.values())
            for i, g in enumerate(lista, 1):
                nombre = g["info"]["nombre"]
                self.cola.put(("estado", f"({i}/{len(lista)}) {nombre}: preparando fotos…"))
                previo = self.almacen.buscar(nombre, g["info"]["provincia"])
                p = I.crear_o_actualizar(self.almacen, g, lado, self._progreso)
                if previo is None:
                    self._completar_nuevo(p, con_wiki, con_ia, avisos)
                elif previo.get("estado") == "pendiente":
                    cumplidos.append(p["nombre"])
                self.almacen.guardar(p)
                hechos.append(p)
            if resto and resto[0] == "existente":
                p = self.almacen.cargar(resto[1])
                I.anadir_fotos(self.almacen, p, resto[2], lado, self._progreso)
                hechos.append(p)
            elif resto and resto[0] == "nuevo":
                nombre = resto[1]
                p = self.almacen.buscar(nombre)
                es_nuevo = p is None
                if es_nuevo:
                    p = pueblo_vacio(nombre)
                    self.cola.put(("estado", f"{nombre}: buscando en el mapa…"))
                    try:
                        lugares = self.geo.buscar(nombre)
                        lugar = next((x for x in lugares if x.get("pais") == "España"), lugares[0] if lugares else None)
                        if lugar:
                            p["provincia"], p["comunidad"] = lugar["provincia"], lugar["comunidad"]
                            p["lat"], p["lon"] = round(lugar["lat"], 6), round(lugar["lon"], 6)
                    except Exception as ex:  # noqa: BLE001
                        avisos.append(f"{nombre}: no lo encuentro en el mapa ({ex})")
                    self.almacen.guardar(p)
                I.anadir_fotos(self.almacen, p, resto[2], lado, self._progreso)
                if es_nuevo:
                    self._completar_nuevo(p, con_wiki, con_ia, avisos)
                    avisos.append(f"{nombre}: revisa que provincia y comunidad sean correctas.")
                self.almacen.guardar(p)
                hechos.append(p)
            return hechos, avisos, cumplidos

        def fin(res):
            hechos, avisos, cumplidos = res
            self._cache_img.clear()
            msg = f"Listo: {len(hechos)} pueblos actualizados."
            if cumplidos:
                msg += "\n\n🎉 Tachados de tu lista de pendientes: " + ", ".join(cumplidos)
            self.estado(msg.split("\n")[0])
            self.vista = None
            self.mostrar("mapa")
            if avisos or cumplidos:
                messagebox.showinfo(NOMBRE_PROGRAMA, msg + ("\n\nAvisos:\n" + "\n".join(avisos[:15]) if avisos else ""))
        self.en_segundo_plano("Añadiendo pueblos…", tarea, fin)

    # ------------------------------------------------------------------ web
    def _cfg_previa(self):
        c = dict(self.cfg)
        c["_previa"] = True
        return c

    def vista_previa(self):
        """Genera la web en local y la abre; se recarga sola cada vez que cambias algo."""
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)

        def fin(n):
            webbrowser.open((self.cfg.sitio / "index.html").as_uri())
            self._previa_abierta = True
            self.estado(f"Vista previa con {n} pueblos (aún no publicada). Se actualiza sola mientras cambias el diseño.")
        self.en_segundo_plano("Generando la web…", lambda: web.generar(
            self.almacen, self._cfg_previa(), self.cfg.sitio, lambda t: self.cola.put(("estado", t))), fin)

    def previa_cambiada(self):
        """Tras un cambio de diseño: rehace la vista previa (si está abierta) al cabo de un momento."""
        if not self._previa_abierta:
            return
        if self._previa_trabajo:
            self.after_cancel(self._previa_trabajo)
        self._previa_trabajo = self.after(700, self._rehacer_previa)

    def _rehacer_previa(self):
        self._previa_trabajo = None
        if self._previa_hilo and self._previa_hilo.is_alive():
            self._previa_trabajo = self.after(500, self._rehacer_previa)
            return

        def hilo():
            try:
                web.generar(self.almacen, self._cfg_previa(), self.cfg.sitio, lambda t: None)
                self.cola.put(("estado", "Vista previa actualizada."))
            except Exception as ex:  # noqa: BLE001
                self.cola.put(("estado", f"No se pudo actualizar la vista previa: {ex}"))
        self._previa_hilo = threading.Thread(target=hilo, daemon=True)
        self._previa_hilo.start()

    def publicar(self):
        if not self.cfg["repo_url"]:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Primero pon la dirección de tu repositorio de GitHub en Ajustes.")
            self.ajustes()
            return
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        avisar = lambda t: self.cola.put(("estado", t))  # noqa: E731

        def tarea():
            s = Sincronizador(self.cfg, avisar)
            return s.subir(), s.ultimo_sha

        def fin(res):
            msg, sha = res
            self._tras_sincronizar()
            if sha:
                self._seguir_publicacion(sha)
            url = url_web(self.cfg["repo_url"])
            self.estado(msg)
            if not self.cfg.get("aviso_actions"):
                self.cfg["aviso_actions"] = True
                self.cfg.guardar()
                messagebox.showinfo(NOMBRE_PROGRAMA, "Un último paso, solo esta vez:\n\n"
                                    "En GitHub, abre tu repositorio → Settings → Pages y en «Source» elige "
                                    "«GitHub Actions».\n\nDesde entonces GitHub rehará la web sola cada vez que "
                                    "publiques desde aquí o guardes desde el panel del móvil:\n"
                                    f"{url}gestion/")
                webbrowser.open(self.cfg["repo_url"].removesuffix(".git") + "/settings/pages")
            elif url and messagebox.askyesno(NOMBRE_PROGRAMA, f"{msg}\n\nTu web: {url}\n\n¿La abro?"):
                webbrowser.open(url)
        self.en_segundo_plano("Publicando…", tarea, fin)

    def _seguir_publicacion(self, sha):
        """Pregunta a GitHub cómo va la publicación de la web y lo cuenta en la barra de abajo."""
        api = GitHubAPI(self.cfg.get("github_token"), self.cfg.get("repo_url"))

        def hilo():
            import time
            for intento in range(48):            # hasta unos 6 minutos
                try:
                    r = api.publicacion(sha)
                except Exception:  # noqa: BLE001
                    r = None
                if r:
                    estado, resultado, url = r
                    if estado == "completed":
                        if resultado == "success":
                            self.cola.put(("llamar", lambda: self._estado_web("✅ Web publicada en internet.", None)))
                        else:
                            self.cola.put(("llamar", lambda u=url: self._estado_web(
                                "❌ GitHub no pudo publicar la web. Haz clic aquí para ver por qué.", u)))
                        return
                    self.cola.put(("estado", "🟡 GitHub está publicando la web…"))
                time.sleep(8)
            self.cola.put(("estado", "GitHub está tardando en publicar; mira la pestaña Actions de tu repositorio."))
        threading.Thread(target=hilo, daemon=True).start()

    def _comprobar_actualizacion(self):
        if self._actualizacion_preguntada:
            return
        repo = Path(self.cfg.get("carpeta_repo") or (Path(self.cfg.sitio).parent / "repo"))
        info = actualizar.disponible(repo, VERSION)
        if not info:
            return
        self._actualizacion_preguntada = True
        base = Path(__file__).resolve().parent
        if getattr(__import__("sys"), "frozen", False):
            messagebox.showinfo(NOMBRE_PROGRAMA, f"Hay una versión nueva de PUEBLOS ({info['version']}).\n\n"
                                "Como usas el .exe, abre PUEBLOS.bat una vez para actualizar y vuelve a crear el .exe.")
            return
        notas = info.get("notas") or ""
        if not messagebox.askyesno(NOMBRE_PROGRAMA, f"Hay una versión nueva de PUEBLOS: {info['version']} "
                                   f"(tienes la {VERSION}).\n\n{notas}\n\n¿Actualizar ahora? El programa se reiniciará. "
                                   "Tus pueblos y tu configuración no se tocan."):
            return
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        try:
            n = actualizar.instalar(info, base)
        except Exception as ex:  # noqa: BLE001
            messagebox.showerror(NOMBRE_PROGRAMA, f"No se pudo actualizar: {ex}")
            return
        self.estado(f"Actualizado ({n} archivos). Reiniciando…")
        if actualizar.reiniciar(base):
            self.after(400, self.destroy)

    def _estado_web(self, texto, url):
        self.estado(texto)
        self.lbl_estado.unbind("<Button-1>")
        if url:
            self.lbl_estado.configure(cursor="hand2")
            self.lbl_estado.bind("<Button-1>", lambda e: webbrowser.open(url))
        else:
            self.lbl_estado.configure(cursor="")

    # ------------------------------------------------------------------ sincronizar con GitHub
    def sincronizar(self, silencioso=False):
        if not self.cfg.get("repo_url") or not git_disponible():
            if not silencioso:
                messagebox.showinfo(NOMBRE_PROGRAMA, "Para sincronizar necesitas git y la dirección del repositorio "
                                    "de GitHub en Ajustes.")
            return
        if self.ocupado:
            return
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        if silencioso:
            def hilo():
                try:
                    nuevo = Sincronizador(self.cfg, lambda t: self.cola.put(("estado", t))).traer()
                    self.cola.put(("llamar", lambda: self._tras_sincronizar(nuevo)))
                except Exception as ex:  # noqa: BLE001  sin conexión, etc.: se sigue trabajando en local
                    self.cola.put(("estado", f"Sin sincronizar con GitHub ({str(ex).splitlines()[0][:80]})"))
            threading.Thread(target=hilo, daemon=True).start()
            return

        def fin(nuevo):
            self._tras_sincronizar(nuevo)
        self.en_segundo_plano("Sincronizando con GitHub…",
                              lambda: Sincronizador(self.cfg, lambda t: self.cola.put(("estado", t))).traer(), fin)

    def _tras_sincronizar(self, nuevo=False):
        """Tras sincronizar, la carpeta de datos puede haber cambiado (la primera vez pasa al repositorio)."""
        if Path(self.almacen.carpeta).resolve() != Path(self.cfg.datos).resolve():
            self.almacen = Almacen(self.cfg.datos)
            self.geo = Geocodificador(self.cfg.user_agent, self.cfg.datos / "_cache_geo.json")
        self._cache_img.clear()
        self.estado("Sincronizado con GitHub." + (" Han llegado cambios del panel web." if nuevo else ""))
        self.after(300, self._comprobar_actualizacion)
        if self.vista == "editor" and self.actual:
            try:
                self.actual = self.almacen.cargar(self.actual["slug"])
                self.vistas["editor"].cargar()
            except OSError:
                self.volver(guardar=False)
        elif self.vista:
            self.vistas[self.vista].refrescar()

    def abrir_panel(self):
        url = url_web(self.cfg["repo_url"])
        if url:
            webbrowser.open(url + "gestion/")
        else:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Aún no has configurado el repositorio de GitHub.")

    def abrir_web(self):
        url = url_web(self.cfg["repo_url"])
        if url:
            webbrowser.open(url)
        else:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Aún no has configurado el repositorio de GitHub.")

    def ajustes(self):
        v = self.dialogo("Ajustes", 660, 560)
        ctk.CTkLabel(v, text="Ajustes", font=fuente_titulo(22)).pack(anchor="w", padx=22, pady=(18, 6))
        f = ctk.CTkFrame(v, corner_radius=12)
        f.pack(fill="both", expand=True, padx=20, pady=6)
        f.columnconfigure(1, weight=1)
        campos = [
            ("repo_url", "Repositorio de GitHub", "https://github.com/locometopa/pueblos.git", False),
            ("github_token", "Token de GitHub", "Opcional: publicar sin iniciar sesión y ver el estado", True),
            ("api_key", "Clave API de Anthropic", "Solo se guarda en este ordenador", True),
            ("modelo_ia", "Modelo de IA", "", False),
            ("lado_foto", "Tamaño de las fotos (px)", "", False),
        ]
        vars_ = {}
        for i, (clave, etiqueta, ayuda, oculto) in enumerate(campos):
            ctk.CTkLabel(f, text=etiqueta, text_color=tema.TINTA_2).grid(row=i, column=0, sticky="w", padx=16, pady=7)
            vars_[clave] = tk.StringVar(value=str(self.cfg.get(clave, "")))
            ctk.CTkEntry(f, textvariable=vars_[clave], show="•" if oculto else "", placeholder_text=ayuda,
                         height=32).grid(row=i, column=1, sticky="ew", padx=(0, 16), pady=7)
        boton(f, "📚  Completar la información de todos los pueblos", lambda: (v.destroy(), self.ampliar_todos()),
              "secundario").grid(row=len(campos) + 3, column=0, columnspan=2, sticky="w", padx=16, pady=(10, 14))
        fila_token = ctk.CTkFrame(f, fg_color="transparent")
        fila_token.grid(row=len(campos), column=1, sticky="w", padx=(0, 16))
        boton(fila_token, "Crear token…", lambda: webbrowser.open("https://github.com/settings/personal-access-tokens/new"),
              "fantasma", width=110).pack(side="left")

        def comprobar_token():
            api = GitHubAPI(vars_["github_token"].get().strip(), vars_["repo_url"].get().strip())
            try:
                messagebox.showinfo(NOMBRE_PROGRAMA, api.comprobar(), parent=v)
            except Exception as ex:  # noqa: BLE001
                messagebox.showerror(NOMBRE_PROGRAMA, str(ex), parent=v)
        boton(fila_token, "Comprobar", comprobar_token, "fantasma", width=100).pack(side="left")
        ctk.CTkLabel(f, text="El token se guarda solo en este ordenador (config.json). Permiso: Contents · Read and write.",
                     text_color=tema.TINTA_2, font=fuente(11)).grid(row=len(campos) + 2, column=0, columnspan=2,
                                                                     sticky="w", padx=16, pady=(4, 0))

        def guardar():
            for clave, var in vars_.items():
                valor = var.get().strip()
                if clave == "lado_foto":
                    try:
                        valor = max(800, min(4000, int(valor)))
                    except ValueError:
                        valor = 1600
                self.cfg[clave] = valor
            self.cfg.guardar()
            configurar_token(self.cfg.get("github_token"))
            v.destroy()
            self.estado("Ajustes guardados.")
        b = ctk.CTkFrame(v, fg_color="transparent")
        b.pack(fill="x", padx=20, pady=14)
        boton(b, "Guardar", guardar, width=110).pack(side="right")
        boton(b, "Cancelar", v.destroy, "secundario", width=100).pack(side="right", padx=8)

    def ampliar_todos(self):
        """Añade historia, fiestas, qué ver, gentilicio… a los pueblos que aún no lo tienen."""
        if self.vista == "editor" and self.actual:
            self.vistas["editor"].guardar(silencioso=True)
        faltan = [p for p in self.almacen.listar() if "secciones" not in (p.get("wiki") or {})]
        if not faltan:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Todos tus pueblos tienen ya la información ampliada.")
            return

        def tarea():
            hechos = 0
            for i, p in enumerate(faltan, 1):
                self._progreso(i, len(faltan), p["nombre"])
                try:
                    w = p.get("wiki") or {}
                    d = self.wiki.datos(w["titulo"]) if w.get("titulo") else self.wiki.todo(
                        p["nombre"], p["provincia"], p["lat"], p["lon"])
                    if not d:
                        continue
                    if w.get("titulo"):
                        d = self.wiki.ampliar(d)
                    for k in ("secciones", "que_ver", "gentilicio", "patron"):
                        if d.get(k):
                            w[k] = d[k]
                    w.setdefault("secciones", [])          # marcado como revisado aunque no haya nada
                    for k, v in d.items():                # lo que faltara (sin pisar tu texto)
                        if k not in w and k not in ("lat", "lon"):
                            w[k] = v
                    p["wiki"] = w
                    self.almacen.guardar(p)
                    hechos += 1
                except Exception:  # noqa: BLE001
                    continue
            return hechos

        def fin(n):
            self.estado(f"Información ampliada en {n} de {len(faltan)} pueblos. Publica para verla en la web.")
            if self.vista:
                self.vistas[self.vista].refrescar()
        self.en_segundo_plano("Recopilando información de internet…", tarea, fin)

    # ------------------------------------------------------------------ segundo plano
    def estado(self, texto):
        self.lbl_estado.configure(text=texto)

    def _progreso(self, i, total, nombre=""):
        self.cola.put(("progreso", (i, total, nombre)))

    def en_segundo_plano(self, texto, tarea, al_terminar=None):
        if self.ocupado:
            messagebox.showinfo(NOMBRE_PROGRAMA, "Espera a que termine lo que está haciendo.")
            return
        self.ocupado = True
        self.configure(cursor="watch")
        self.estado(texto)
        self.progreso.pack(side="right", padx=16)
        self.progreso.configure(mode="indeterminate")
        self.progreso.start()

        def hilo():
            try:
                self.cola.put(("fin", (al_terminar, tarea(), None)))
            except Exception as ex:  # noqa: BLE001
                traceback.print_exc()
                self.cola.put(("fin", (al_terminar, None, ex)))
        threading.Thread(target=hilo, daemon=True).start()

    def _atender_cola(self):
        try:
            while True:
                tipo, dato = self.cola.get_nowait()
                if tipo == "estado":
                    self.estado(dato)
                elif tipo == "llamar":
                    dato()
                elif tipo == "progreso":
                    i, total, nombre = dato
                    self.progreso.stop()
                    self.progreso.configure(mode="determinate")
                    self.progreso.set(i / total if total else 0)
                    if nombre:
                        self.estado(f"{i}/{total}  {nombre}")
                elif tipo == "fin":
                    al_terminar, resultado, error = dato
                    self.ocupado = False
                    self.configure(cursor="")
                    self.progreso.stop()
                    self.progreso.configure(mode="determinate")
                    self.progreso.set(0)
                    self.progreso.pack_forget()
                    if error is not None:
                        self.estado("Algo ha fallado.")
                        msg = str(error)
                        if not isinstance(error, (ErrorIA, ErrorPublicar)):
                            msg = f"{type(error).__name__}: {msg}\n\n¿Hay conexión a Internet?"
                        messagebox.showerror(NOMBRE_PROGRAMA, msg)
                    elif al_terminar:
                        al_terminar(resultado)
        except queue.Empty:
            pass
        self.after(100, self._atender_cola)

    def salir(self):
        if self.vista == "editor" and self.actual:
            try:
                self.vistas["editor"].guardar(silencioso=True)
            except Exception:  # noqa: BLE001
                pass
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
