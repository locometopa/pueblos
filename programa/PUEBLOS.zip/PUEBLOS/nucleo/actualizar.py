"""Actualizaciones del programa desde GitHub.

Las versiones nuevas se dejan en la carpeta programa/ del repositorio (version.json + PUEBLOS.zip).
Como el programa ya sincroniza el repositorio, la versión nueva llega sola: aquí solo se compara,
se instala (sin tocar tus datos ni tu configuración) y se reinicia.
"""
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

PROTEGIDOS = {"config.json", "datos", "repo", "sitio", "copia_datos_antiguos", "diseno"}


def numero(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def disponible(repo: Path, actual: str):
    """Información de la versión nueva si la hay ({'version', 'notas', 'archivo'}), o None."""
    f = Path(repo) / "programa" / "version.json"
    if not f.exists():
        return None
    try:
        info = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    zipf = f.parent / info.get("archivo", "PUEBLOS.zip")
    if numero(info.get("version")) > numero(actual) and zipf.exists():
        info["_zip"] = str(zipf)
        return info
    return None


def instalar(info: dict, base: Path) -> int:
    """Descomprime la versión nueva sobre el programa. Devuelve cuántos archivos se han actualizado."""
    base = Path(base)
    n = 0
    with zipfile.ZipFile(info["_zip"]) as z:
        nombres = [i for i in z.infolist() if not i.is_dir()]
        primeros = {Path(i.filename).parts[0] for i in nombres}
        quitar = len(primeros) == 1 and not any(len(Path(i.filename).parts) == 1 for i in nombres)
        for i in nombres:
            partes = Path(i.filename).parts[1:] if quitar else Path(i.filename).parts
            if not partes or partes[0] in PROTEGIDOS or "__pycache__" in partes:
                continue
            destino = base.joinpath(*partes)
            destino.parent.mkdir(parents=True, exist_ok=True)
            destino.write_bytes(z.read(i))
            n += 1
    return n


def reiniciar(base: Path) -> bool:
    """Vuelve a abrir el programa (si no es un .exe empaquetado)."""
    if getattr(sys, "frozen", False):
        return False
    opciones = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
    subprocess.Popen([sys.executable, str(Path(base) / "pueblos.py")], cwd=str(base), **opciones)
    return True
