"""Actualizaciones del programa desde GitHub.

Las versiones nuevas se dejan en la carpeta programa/ del repositorio (version.json + PUEBLOS.zip).
Como el programa ya sincroniza el repositorio, la versión nueva llega sola: aquí solo se compara,
se instala (sin tocar tus datos ni tu configuración) y se reinicia.
"""
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

PROTEGIDOS = {"config.json", "datos", "repo", "sitio", "copia_datos_antiguos", "diseno", "PUEBLOS.exe"}
# Archivos de versiones antiguas que ya no hacen falta: se quitan al actualizar
SOBRANTES = ["INSTALAR.bat", "requirements.txt", "PUEBLOS.spec"]


def numero(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def disponible(repo: Path, actual: str):
    """Información de la versión nueva si la hay ({'version', 'notas', 'archivo'}), o None."""
    f = Path(repo) / "programa" / "version.json"
    if not f.exists():
        return None
    try:
        info = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    zipf = f.parent / info.get("archivo", "PUEBLOS.zip")
    if numero(info.get("version")) > numero(actual) and zipf.exists():
        info["_zip"] = str(zipf)
        return info
    return None


def instalar(info: dict, base: Path) -> int:
    """Descomprime la versión nueva sobre el programa. Devuelve cuántos archivos se han actualizado."""
    base = Path(base)
    n = 0
    with zipfile.ZipFile(info["_zip"]) as z:
        nombres = [i for i in z.infolist() if not i.is_dir()]
        primeros = {Path(i.filename).parts[0] for i in nombres}
        quitar = len(primeros) == 1 and not any(len(Path(i.filename).parts) == 1 for i in nombres)
        for i in nombres:
            partes = Path(i.filename).parts[1:] if quitar else Path(i.filename).parts
            if not partes or partes[0] in PROTEGIDOS or "__pycache__" in partes:
                continue
            destino = base.joinpath(*partes)
            destino.parent.mkdir(parents=True, exist_ok=True)
            destino.write_bytes(z.read(i))
            n += 1
    for s in SOBRANTES:
        try:
            (base / s).unlink()
        except OSError:
            pass
    return n


def lanzador():
    """Python «sin ventana» del ordenador, para abrir pueblos.py (también desde el .exe)."""
    import shutil
    if not getattr(sys, "frozen", False):
        pyw = Path(sys.executable).with_name("pythonw.exe")
        return str(pyw) if pyw.exists() else sys.executable
    return shutil.which("pyw") or shutil.which("pythonw")


def version_en_carpeta(base: Path) -> str:
    try:
        m = re.search(r'^VERSION = "([^"]+)"', (Path(base) / "nucleo" / "config.py").read_text(encoding="utf-8"), re.M)
        return m.group(1) if m else ""
    except OSError:
        return ""


def reiniciar(base: Path) -> bool:
    """Vuelve a abrir el programa ya actualizado (también si se usaba el .exe)."""
    exe = lanzador()
    script = Path(base) / "pueblos.py"
    if not exe or not script.exists():
        return False
    opciones = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
    subprocess.Popen([exe, str(script)], cwd=str(base), **opciones)
    return True
