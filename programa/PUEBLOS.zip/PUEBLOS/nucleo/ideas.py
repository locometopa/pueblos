"""Ideas de pueblos para la lista «Por visitar», sacadas de Wikidata.

  · Los Pueblos más Bonitos de España (miembros de la asociación en Wikidata).
  · Pueblos con patrimonio protegido (Bien de Interés Cultural, conjunto histórico…) cerca de los que ya visitaste.
"""
import re

import requests

from .datos import normalizar

WIKIDATA_API = "https://www.wikidata.org/w/api.php"
SPARQL = "https://query.wikidata.org/sparql"
MUNICIPIO_ESPANA = "Q2074737"


def _distancia(a, b):
    from .extras import distancia_km
    return distancia_km(a, b)


def _coord(texto: str):
    m = re.match(r"Point\(([-\d.]+) ([-\d.]+)\)", texto or "")
    return (float(m.group(2)), float(m.group(1))) if m else None


def _consulta(sesion, q: str) -> list:
    r = sesion.get(SPARQL, params={"query": q, "format": "json"}, timeout=60,
                   headers={"Accept": "application/sparql-results+json"})
    r.raise_for_status()
    return r.json().get("results", {}).get("bindings", [])


def _qid_asociacion(sesion) -> str:
    js = sesion.get(WIKIDATA_API, params={"action": "wbsearchentities", "search": "Los Pueblos más Bonitos de España",
                                          "language": "es", "type": "item", "limit": 5, "format": "json"}, timeout=25).json()
    for x in js.get("search", []):
        if "bonitos" in normalizar(x.get("label", "")):
            return x["id"]
    return ""


def pueblos_bonitos(sesion) -> list:
    qid = _qid_asociacion(sesion)
    if not qid:
        return []
    filas = _consulta(sesion, f"""SELECT ?item ?itemLabel ?coord ?zonaLabel ?sl WHERE {{
  ?item wdt:P463 wd:{qid} ; wdt:P625 ?coord .
  OPTIONAL {{ ?item wdt:P131 ?zona }}
  OPTIONAL {{ ?item wikibase:sitelinks ?sl }}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "es,en". }}
}}""")
    return _limpiar(filas, "Los Pueblos más Bonitos de España")


def cerca_de(sesion, centros: list, radio_km: int = 45, por_centro: int = 25) -> list:
    """Municipios con patrimonio protegido alrededor de cada pueblo visitado."""
    res = []
    for la, lo in centros[:10]:
        try:
            filas = _consulta(sesion, f"""SELECT ?item ?itemLabel ?coord ?zonaLabel ?sl WHERE {{
  SERVICE wikibase:around {{ ?item wdt:P625 ?coord .
    bd:serviceParam wikibase:center "Point({lo} {la})"^^geo:wktLiteral . bd:serviceParam wikibase:radius "{radio_km}" . }}
  ?item wdt:P31 wd:{MUNICIPIO_ESPANA} ; wdt:P1435 ?patrimonio .
  OPTIONAL {{ ?item wdt:P131 ?zona }}
  OPTIONAL {{ ?item wikibase:sitelinks ?sl }}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "es,en". }}
}} LIMIT 200""")
        except (requests.RequestException, ValueError):
            continue
        lista = _limpiar(filas, "Patrimonio protegido cerca")
        lista.sort(key=lambda x: -x["popularidad"])
        res += lista[:por_centro]
    return res


def _limpiar(filas, motivo) -> list:
    vistos, res = set(), []
    for b in filas:
        nombre = b.get("itemLabel", {}).get("value", "")
        c = _coord(b.get("coord", {}).get("value"))
        qid = b["item"]["value"].rsplit("/", 1)[-1]
        if not nombre or re.fullmatch(r"Q\d+", nombre) or not c or qid in vistos:
            continue
        vistos.add(qid)
        res.append({"nombre": nombre, "lat": round(c[0], 6), "lon": round(c[1], 6), "wikidata": qid,
                    "zona": b.get("zonaLabel", {}).get("value", ""), "motivo": motivo,
                    "popularidad": int(float(b.get("sl", {}).get("value", 0) or 0))})
    return res


def sugerencias(sesion, pueblos: list) -> list:
    """Ideas que aún no están en tu lista, con la distancia al pueblo tuyo más cercano."""
    conocidos = {normalizar(p.get("nombre")) for p in pueblos}
    visitados = [p for p in pueblos if p.get("estado") != "pendiente" and p.get("lat") is not None]
    # centros: un pueblo visitado por zona (no repetir dos a menos de 30 km)
    centros = []
    for p in visitados:
        c = (p["lat"], p["lon"])
        if all(_distancia(c, d) > 30 for d in centros):
            centros.append(c)
    ideas = []
    try:
        ideas += pueblos_bonitos(sesion)
    except (requests.RequestException, ValueError, KeyError):
        pass
    if centros:
        ideas += cerca_de(sesion, centros)
    res, vistos = [], set()
    for x in ideas:
        clave = normalizar(x["nombre"])
        if clave in conocidos or x["wikidata"] in vistos:
            if x["wikidata"] in vistos:          # el mismo pueblo por dos motivos: se juntan
                for r in res:
                    if r["wikidata"] == x["wikidata"] and x["motivo"] not in r["motivo"]:
                        r["motivo"] += " · " + x["motivo"]
            continue
        vistos.add(x["wikidata"])
        if visitados:
            cerca = min(visitados, key=lambda p: _distancia((x["lat"], x["lon"]), (p["lat"], p["lon"])))
            x["km"] = round(_distancia((x["lat"], x["lon"]), (cerca["lat"], cerca["lon"])))
            x["cerca_de"] = cerca["nombre"]
        res.append(x)
    res.sort(key=lambda x: (x.get("km", 9999), -x["popularidad"]))
    return res
