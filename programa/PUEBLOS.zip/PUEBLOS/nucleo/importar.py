"""Importar fotos: detectar a qué pueblo pertenece cada una y crear/actualizar los pueblos."""
import tempfile
from datetime import timedelta
from pathlib import Path

from . import fotos as F
from .datos import Almacen, clave_original, normalizar, pueblo_vacio

# Una foto sin GPS se asigna al pueblo de la foto con GPS más cercana en el tiempo,
# si se hizo como mucho este tiempo antes o después.
MARGEN_HORAS = 2


def anadir_fotos(almacen: Almacen, p: dict, rutas, lado: int = 1600, progreso=None) -> int:
    """Copia (redimensionadas y sin GPS) las fotos al pueblo. No repite las ya añadidas."""
    if not p.get("slug"):
        almacen.guardar(p)
    ya = {f.get("original") for f in p["fotos"]}
    nuevas = 0
    rutas = list(rutas)
    for i, ruta in enumerate(rutas, 1):
        ruta = Path(ruta)
        clave = clave_original(ruta)
        if str(ruta) in ya or clave in ya:
            continue
        if progreso:
            progreso(i, len(rutas), ruta.name)
        meta = F.leer_metadatos(ruta)
        nombre = almacen.siguiente_nombre_foto(p)
        destino = almacen.carpeta_fotos(p["slug"]) / nombre
        try:
            F.preparar_foto(ruta, destino, lado)
            F.miniatura(destino, almacen.carpeta_minis(p["slug"]) / nombre, 600)
        except Exception:  # noqa: BLE001  foto que no se puede abrir: se salta
            continue
        p["fotos"].append({"archivo": nombre, "fecha": meta["fecha"] or "", "pie": "",
                           "original": clave})
        ya.add(clave)
        if meta["fecha"]:
            p["fechas_visita"].append(meta["fecha"])
        if p.get("lat") is None and meta["lat"] is not None:
            p["lat"], p["lon"] = meta["lat"], meta["lon"]
        nuevas += 1
    _ordenar(p)
    almacen.guardar(p)
    return nuevas


def anadir_fotos_internet(almacen: Almacen, p: dict, items, commons, lado: int = 1600, progreso=None) -> tuple:
    """Descarga fotos de Wikimedia Commons al pueblo, guardando autor y licencia.
    No añaden fechas de visita. Devuelve (añadidas, fallos)."""
    if not p.get("slug"):
        almacen.guardar(p)
    ya = {f.get("original") for f in p["fotos"]}
    nuevas, fallos = 0, 0
    items = list(items)
    with tempfile.TemporaryDirectory() as tmp:
        for i, it in enumerate(items, 1):
            if it["pagina"] in ya:
                continue
            if progreso:
                progreso(i, len(items), it["titulo"].split(":", 1)[-1][:40])
            temporal = Path(tmp) / f"{i}.img"
            nombre = almacen.siguiente_nombre_foto(p)
            destino = almacen.carpeta_fotos(p["slug"]) / nombre
            try:
                commons.descargar(it, temporal)
                F.preparar_foto(temporal, destino, lado)
                F.miniatura(destino, almacen.carpeta_minis(p["slug"]) / nombre, 600)
            except Exception:  # noqa: BLE001
                fallos += 1
                continue
            p["fotos"].append({
                "archivo": nombre, "fecha": "", "pie": "", "original": it["pagina"],
                "credito": {"autor": it["autor"], "licencia": it["licencia"],
                            "url_licencia": it.get("url_licencia", ""), "fuente": it["pagina"]},
            })
            ya.add(it["pagina"])
            nuevas += 1
    _ordenar(p)
    almacen.guardar(p)
    return nuevas, fallos


def _ordenar(p):
    # Primero las tuyas por fecha; las de internet al final.
    p["fotos"].sort(key=lambda f: (bool(f.get("credito")), f.get("fecha") or "9999", f["archivo"]))


def analizar(rutas, geo, progreso=None, cancelado=lambda: False) -> tuple:
    """Agrupa las fotos por pueblo según su GPS. Las que no tienen GPS se asignan
    al pueblo de la foto con GPS más próxima en el tiempo (si hay una cerca).
    Devuelve (grupos, sin_asignar, n_por_hora)."""
    grupos, sin_gps, con_hora = {}, [], []
    rutas = list(rutas)
    for i, ruta in enumerate(rutas, 1):
        if cancelado():
            break
        if progreso:
            progreso(i, len(rutas), Path(ruta).name)
        meta = F.leer_metadatos(ruta)
        if meta["lat"] is None:
            sin_gps.append((ruta, meta))
            continue
        try:
            info = geo.inverso(meta["lat"], meta["lon"])
        except Exception:  # noqa: BLE001  sin conexión, etc.
            info = None
        if not info or not info.get("nombre"):
            sin_gps.append((ruta, meta))
            continue
        clave = (normalizar(info["nombre"]), normalizar(info["provincia"]))
        g = grupos.setdefault(clave, {"info": info, "fotos": [], "lats": [], "lons": [],
                                      "fechas": set(), "por_hora": 0})
        g["fotos"].append(ruta)
        g["lats"].append(meta["lat"])
        g["lons"].append(meta["lon"])
        if meta["fecha"]:
            g["fechas"].add(meta["fecha"])
        if meta["momento"]:
            con_hora.append((meta["momento"], clave))

    sin_asignar, por_hora = [], 0
    margen = timedelta(hours=MARGEN_HORAS)
    for ruta, meta in sin_gps:
        destino = None
        if meta["momento"] and con_hora:
            momento, clave = min(con_hora, key=lambda x: abs(x[0] - meta["momento"]))
            if abs(momento - meta["momento"]) <= margen:
                destino = clave
        if destino:
            grupos[destino]["fotos"].append(ruta)
            grupos[destino]["por_hora"] += 1
            if meta["fecha"]:
                grupos[destino]["fechas"].add(meta["fecha"])
            por_hora += 1
        else:
            sin_asignar.append(ruta)
    return grupos, sin_asignar, por_hora


def crear_o_actualizar(almacen: Almacen, grupo: dict, lado: int = 1600, progreso=None) -> dict:
    info = grupo["info"]
    p = almacen.buscar(info["nombre"], info["provincia"])
    if p is None:
        p = pueblo_vacio(info["nombre"])
        p["provincia"] = info["provincia"]
        p["comunidad"] = info["comunidad"]
        p["pais"] = info.get("pais") or "España"
        if grupo.get("lats"):
            p["lat"] = round(sum(grupo["lats"]) / len(grupo["lats"]), 6)
            p["lon"] = round(sum(grupo["lons"]) / len(grupo["lons"]), 6)
        almacen.guardar(p)
    if p.get("estado") == "pendiente":   # ¡por fin lo has visitado!
        p["estado"] = "visitado"
    anadir_fotos(almacen, p, grupo["fotos"], lado, progreso)
    return p
