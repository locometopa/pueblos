"""Saber en qué pueblo está una coordenada (y al revés) con OpenStreetMap / Nominatim."""
import json
import threading
import time
from pathlib import Path

import requests

NOMINATIM = "https://nominatim.openstreetmap.org"


class Geocodificador:
    def __init__(self, user_agent: str, archivo_cache: Path = None):
        self.sesion = requests.Session()
        self.sesion.headers.update({"User-Agent": user_agent, "Accept-Language": "es"})
        self._ultimo = 0.0
        self._lock = threading.Lock()
        self.archivo_cache = archivo_cache
        self.cache = {}
        if archivo_cache and archivo_cache.exists():
            try:
                self.cache = json.loads(archivo_cache.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                self.cache = {}

    def _esperar(self):
        # Norma de uso de Nominatim: como máximo 1 petición por segundo.
        with self._lock:
            pausa = 1.1 - (time.time() - self._ultimo)
            if pausa > 0:
                time.sleep(pausa)
            self._ultimo = time.time()

    def _guardar_cache(self):
        if self.archivo_cache:
            try:
                self.archivo_cache.write_text(json.dumps(self.cache, ensure_ascii=False), encoding="utf-8")
            except OSError:
                pass

    @staticmethod
    def _desde_direccion(addr: dict, lat=None, lon=None) -> dict:
        nombre = (addr.get("village") or addr.get("town") or addr.get("city")
                  or addr.get("municipality") or addr.get("hamlet") or addr.get("suburb") or "")
        comunidad = addr.get("state") or ""
        provincia = addr.get("province") or addr.get("state_district") or addr.get("county") or comunidad
        return {
            "nombre": nombre,
            "municipio": addr.get("municipality") or addr.get("city") or addr.get("town") or nombre,
            "provincia": provincia,
            "comunidad": comunidad,
            "pais": addr.get("country") or "",
            "lat": lat, "lon": lon,
        }

    def inverso(self, lat: float, lon: float):
        clave = f"{lat:.3f},{lon:.3f}"
        if clave in self.cache:
            return self.cache[clave]
        self._esperar()
        r = self.sesion.get(f"{NOMINATIM}/reverse", timeout=20, params={
            "lat": lat, "lon": lon, "format": "jsonv2", "zoom": 14, "addressdetails": 1})
        r.raise_for_status()
        js = r.json()
        if "address" not in js:
            return None
        res = self._desde_direccion(js["address"], lat, lon)
        self.cache[clave] = res
        self._guardar_cache()
        return res

    def buscar(self, texto: str, limite: int = 8) -> list:
        self._esperar()
        r = self.sesion.get(f"{NOMINATIM}/search", timeout=20, params={
            "q": texto, "format": "jsonv2", "addressdetails": 1, "limit": limite})
        r.raise_for_status()
        resultados = []
        for js in r.json():
            res = self._desde_direccion(js.get("address", {}), float(js["lat"]), float(js["lon"]))
            res["descripcion"] = js.get("display_name", "")
            if not res["nombre"]:
                res["nombre"] = js.get("name", "")
            resultados.append(res)
        return resultados
