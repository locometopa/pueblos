"""Saber en qué pueblo está una coordenada (y al revés) con OpenStreetMap / Nominatim."""
import json
import threading
import time
from pathlib import Path

import requests

NOMINATIM = "https://nominatim.openstreetmap.org"


class Geocodificador:
    def __init__(self, user_agent: str, archivo_cache: Path = None):
        self.sesion = requests.Session()
        self.sesion.headers.update({"User-Agent": user_agent, "Accept-Language": "es"})
        self._ultimo = 0.0
        self._lock = threading.Lock()
        self.archivo_cache = archivo_cache
        self.cache = {}
        if archivo_cache and archivo_cache.exists():
            try:
                self.cache = json.loads(archivo_cache.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                self.cache = {}

    def _esperar(self):
        # Norma de uso de Nominatim: como máximo 1 petición por segundo.
        with self._lock:
            pausa = 1.1 - (time.time() - self._ultimo)
            if pausa > 0:
                time.sleep(pausa)
            self._ultimo = time.time()

    def _guardar_cache(self):
        if self.archivo_cache:
            try:
                self.archivo_cache.write_text(json.dumps(self.cache, ensure_ascii=False), encoding="utf-8")
            except OSError:
                pass

    @staticmethod
    def _desde_direccion(addr: dict, lat=None, lon=None) -> dict:
        nombre = (addr.get("village") or addr.get("town") or addr.get("city")
                  or addr.get("municipality") or addr.get("hamlet") or addr.get("suburb") or "")
        comunidad = addr.get("state") or ""
        provincia = addr.get("province") or addr.get("state_district") or addr.get("county") or comunidad
        return {
            "nombre": nombre,
            "municipio": addr.get("municipality") or addr.get("city") or addr.get("town") or nombre,
            "provincia": provincia,
            "comunidad": comunidad,
            "pais": addr.get("country") or "",
            "lat": lat, "lon": lon,
        }

    def inverso(self, lat: float, lon: float):
        clave = f"{lat:.3f},{lon:.3f}"
        if clave in self.cache:
            return self.cache[clave]
        self._esperar()
        r = self.sesion.get(f"{NOMINATIM}/reverse", timeout=20, params={
            "lat": lat, "lon": lon, "format": "jsonv2", "zoom": 14, "addressdetails": 1})
        r.raise_for_status()
        js = r.json()
        if "address" not in js:
            return None
        res = self._desde_direccion(js["address"], lat, lon)
        self.cache[clave] = res
        self._guardar_cache()
        return res

    def _pedir(self, params: dict) -> list:
        self._esperar()
        r = self.sesion.get(f"{NOMINATIM}/search", timeout=20, params=dict(
            {"format": "jsonv2", "addressdetails": 1, "dedupe": 1}, **params))
        r.raise_for_status()
        return r.json() or []

    def buscar(self, texto: str, limite: int = 8, provincia: str = "", espana: bool = True) -> list:
        """Pueblos que se llaman así, los más probables primero (núcleos de población de España antes que
        calles, comercios o lugares de otros países). Cada uno con «tipo» y «seguro» (si no hace falta preguntar)."""
        nombre = texto.split(",")[0].strip()
        consulta = ", ".join(x for x in (nombre, provincia) if x) if provincia and provincia not in texto else texto
        intentos = []
        if espana:
            intentos += [{"q": consulta, "countrycodes": "es", "featureType": "settlement", "limit": 15},
                         {"q": consulta, "countrycodes": "es", "limit": 15}]
        intentos.append({"q": consulta, "limit": 15})
        if consulta != nombre:
            intentos.append({"q": nombre, "countrycodes": "es", "featureType": "settlement", "limit": 15} if espana
                            else {"q": nombre, "limit": 15})
        for params in intentos:
            crudos = self._pedir(params)
            res = ordenar_resultados(crudos, nombre, provincia, self._desde_direccion)
            if res:
                return res[:limite]
        return []


# ---------------------------------------------------------------- elegir bien el pueblo buscado
TIPOS = {"city": ("Ciudad", 3), "town": ("Villa", 3), "village": ("Pueblo", 3), "hamlet": ("Aldea", 2),
         "isolated_dwelling": ("Caserío", 1), "locality": ("Paraje", 0.5), "municipality": ("Municipio", 2.5),
         "suburb": ("Barrio", 1), "neighbourhood": ("Barrio", 0.5), "quarter": ("Barrio", 0.5)}


def _norm(t: str) -> str:
    import unicodedata
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return " ".join(t.replace("-", " ").replace("'", " ").split())


def _km(a, b):
    import math
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 12742 * math.asin(math.sqrt(h))


def ordenar_resultados(crudos: list, nombre: str, provincia: str, desde_direccion) -> list:
    """Puntúa cada resultado de Nominatim: nombre exacto, tipo de lugar (pueblo, villa, aldea…), provincia
    escrita e importancia. Junta los repetidos (el municipio y su núcleo) quedándose con el punto del núcleo."""
    buscado, prov = _norm(nombre), _norm(provincia)
    candidatos = []
    for js in crudos:
        tipo_osm = js.get("addresstype") or js.get("type") or ""
        categoria = js.get("category") or js.get("class") or ""
        if categoria and categoria not in ("place", "boundary") and tipo_osm not in TIPOS:
            continue                                   # calles, bares, iglesias… que se llaman igual
        try:
            lat, lon = float(js["lat"]), float(js["lon"])
        except (KeyError, ValueError):
            continue
        res = desde_direccion(js.get("address", {}), lat, lon)
        propio = js.get("name") or ""
        if propio and (_norm(propio) == buscado or tipo_osm in TIPOS):
            res["nombre"] = propio                     # el nombre del propio lugar (no el de su municipio)
        elif not res["nombre"]:
            res["nombre"] = propio or nombre
        etiqueta, peso = TIPOS.get(tipo_osm, ("Lugar", 0))
        n = _norm(res["nombre"])
        puntos = peso + float(js.get("importance") or 0) * 2
        if n == buscado:
            puntos += 4
        elif n.startswith(buscado) or buscado.startswith(n):
            puntos += 1.5
        elif buscado not in n:
            puntos -= 2
        if prov and prov in (_norm(res["provincia"]), _norm(res["comunidad"])):
            puntos += 3
        if categoria == "place":
            puntos += 0.5                              # el punto del núcleo, no el centro del término
        if etiqueta in ("Aldea", "Barrio", "Caserío", "Paraje") and res.get("municipio") and _norm(res["municipio"]) != n:
            etiqueta_larga = f"{etiqueta} de {res['municipio']}"
        else:
            etiqueta_larga = etiqueta
        res.update(tipo=etiqueta, puntos=round(puntos, 2),
                   descripcion=" · ".join(x for x in (etiqueta_larga, res["provincia"], res["comunidad"] if res["comunidad"] != res["provincia"] else "",
                                                       res["pais"] if res["pais"] and res["pais"] != "España" else "") if x),
                   detalle=js.get("display_name", ""))
        candidatos.append(res)
    candidatos.sort(key=lambda r: -r["puntos"])
    unicos = []
    for r in candidatos:
        igual = next((u for u in unicos if _norm(u["nombre"]) == _norm(r["nombre"])
                      and _norm(u["provincia"]) == _norm(r["provincia"]) and _km((u["lat"], u["lon"]), (r["lat"], r["lon"])) < 8), None)
        if not igual:
            unicos.append(r)
    exactos = [u for u in unicos if _norm(u["nombre"]) == buscado]
    for u in unicos:
        u["seguro"] = False
    if unicos and _norm(unicos[0]["nombre"]) == buscado and (len(exactos) == 1
            or exactos[0]["puntos"] - exactos[1]["puntos"] >= 2.5 or (
            prov and prov in (_norm(unicos[0]["provincia"]), _norm(unicos[0]["comunidad"]))
            and sum(1 for e in exactos if prov in (_norm(e["provincia"]), _norm(e["comunidad"]))) == 1)):
        unicos[0]["seguro"] = True
    return unicos
