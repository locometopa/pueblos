"""Copia de seguridad de tus pueblos (aparte de GitHub): un .zip en la carpeta que elijas (disco USB, NAS…)."""
import time
import zipfile
from pathlib import Path

PREFIJO = "PUEBLOS-copia-"


def hacer_copia(repo: Path, base: Path, destino: Path, conservar: int = 5, avisar=print) -> Path:
    """Guarda pueblos, fotos, ajustes de la web y tu configuración. Devuelve la ruta del .zip."""
    repo, base, destino = Path(repo), Path(base), Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    nombre = destino / f"{PREFIJO}{time.strftime('%Y-%m-%d_%H%M')}.zip"
    temporal = nombre.with_suffix(".zip.tmp")
    archivos = []
    for carpeta in ("datos", "diseno"):
        c = repo / carpeta
        if c.exists():
            archivos += [f for f in c.rglob("*") if f.is_file() and not f.name.endswith(".tmp") and "_papelera" not in f.parts]
    for suelto in (repo / "ajustes_web.json", repo / "acceso_panel.json", base / "config.json"):
        if suelto.exists():
            archivos.append(suelto)
    with zipfile.ZipFile(temporal, "w", zipfile.ZIP_DEFLATED) as z:
        for i, f in enumerate(archivos, 1):
            if i % 50 == 0:
                avisar(f"Copia de seguridad: {i} de {len(archivos)} archivos…")
            raiz = base if f.parent == base else repo
            # las fotos ya están comprimidas: se guardan tal cual (más rápido)
            modo = zipfile.ZIP_STORED if f.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".heic") else zipfile.ZIP_DEFLATED
            z.write(f, f.relative_to(raiz).as_posix(), compress_type=modo)
        z.writestr("LEEME-copia.txt",
                   "Copia de seguridad de PUEBLOS (" + time.strftime("%d/%m/%Y %H:%M") + ").\n\n"
                   "datos/  -> tus pueblos y fotos (van en la carpeta repo/datos del programa)\n"
                   "ajustes_web.json, acceso_panel.json, diseno/ -> van en la carpeta repo\n"
                   "config.json -> va junto a PUEBLOS.bat (incluye tus claves: guárdalo en un sitio seguro)\n")
    temporal.replace(nombre)
    for viejo in sorted(destino.glob(f"{PREFIJO}*.zip"))[:-conservar]:
        try:
            viejo.unlink()
        except OSError:
            pass
    return nombre


def ultima(destino: Path):
    copias = sorted(Path(destino).glob(f"{PREFIJO}*.zip")) if destino and Path(destino).exists() else []
    return copias[-1] if copias else None


def toca(cfg, dias: int = 7) -> bool:
    """¿Hay que hacer la copia automática?"""
    if not cfg.get("copia_carpeta") or not cfg.get("copia_auto", True):
        return False
    hecha = cfg.get("copia_ultima") or ""
    try:
        return (time.time() - time.mktime(time.strptime(hecha, "%Y-%m-%d %H:%M"))) > dias * 86400
    except ValueError:
        return True
