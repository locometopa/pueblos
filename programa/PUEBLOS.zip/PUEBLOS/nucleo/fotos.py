"""Lectura de GPS y fecha de las fotos, y preparación de copias para la web."""
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageOps

try:  # fotos HEIC de iPhone (opcional)
    import pillow_heif
    pillow_heif.register_heif_opener()
except Exception:  # noqa: BLE001
    pass

EXTENSIONES = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".tif", ".tiff"}
GPS_IFD = 0x8825
EXIF_IFD = 0x8769


def buscar_fotos(carpeta: Path, recursivo: bool = True) -> list:
    patron = "**/*" if recursivo else "*"
    return sorted(p for p in Path(carpeta).glob(patron)
                  if p.is_file() and p.suffix.lower() in EXTENSIONES)


def _a_grados(valor, ref) -> float:
    g, m, s = (float(x) for x in valor)
    grados = g + m / 60 + s / 3600
    if isinstance(ref, bytes):
        ref = ref.decode(errors="ignore")
    return -grados if str(ref).upper().startswith(("S", "W")) else grados


def _momento(texto):
    """Fecha y hora EXIF -> datetime (o None)."""
    if not texto:
        return None
    if isinstance(texto, bytes):
        texto = texto.decode(errors="ignore")
    texto = str(texto).strip().replace("\x00", "")
    for fmt in ("%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y:%m:%d"):
        try:
            return datetime.strptime(texto[:19] if "%H" in fmt else texto[:10], fmt)
        except ValueError:
            continue
    return None


def leer_metadatos(ruta: Path) -> dict:
    """Devuelve {'lat', 'lon', 'fecha', 'momento'} (cualquiera puede ser None).
    'fecha' es 'AAAA-MM-DD'; 'momento' es el datetime completo (para emparejar por hora)."""
    datos = {"lat": None, "lon": None, "fecha": None, "momento": None}
    try:
        with Image.open(ruta) as img:
            exif = img.getexif()
            sub = exif.get_ifd(EXIF_IFD)
            m = _momento(sub.get(36867) or sub.get(36868) or exif.get(306))
            if m:
                datos["momento"], datos["fecha"] = m, m.strftime("%Y-%m-%d")
            gps = exif.get_ifd(GPS_IFD)
            if gps and 2 in gps and 4 in gps:
                lat = _a_grados(gps[2], gps.get(1, "N"))
                lon = _a_grados(gps[4], gps.get(3, "E"))
                if abs(lat) > 0.0001 or abs(lon) > 0.0001:
                    datos["lat"], datos["lon"] = round(lat, 6), round(lon, 6)
    except Exception:  # noqa: BLE001  (foto dañada o formato raro: sin datos)
        pass
    return datos


def preparar_foto(origen: Path, destino: Path, lado: int = 1600, calidad: int = 85):
    """Copia redimensionada, girada correctamente y SIN metadatos (no publica el GPS)."""
    with Image.open(origen) as img:
        img = ImageOps.exif_transpose(img)
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        img.thumbnail((lado, lado), Image.LANCZOS)
        destino.parent.mkdir(parents=True, exist_ok=True)
        img.save(destino, "JPEG", quality=calidad, optimize=True, progressive=True)


def miniatura(origen: Path, destino: Path, lado: int = 600, calidad: int = 80):
    if destino.exists() and destino.stat().st_mtime >= origen.stat().st_mtime:
        return
    with Image.open(origen) as img:
        img = img.convert("RGB")
        img.thumbnail((lado, lado), Image.LANCZOS)
        destino.parent.mkdir(parents=True, exist_ok=True)
        img.save(destino, "JPEG", quality=calidad, optimize=True, progressive=True)
