"""Datos del pueblo desde Wikipedia (texto) y Wikidata (población, altitud, escudo...)."""
import requests

from .datos import normalizar

WIKI_API = "https://es.wikipedia.org/w/api.php"
WIKIDATA_API = "https://www.wikidata.org/w/api.php"


class Wikipedia:
    def __init__(self, user_agent: str):
        self.sesion = requests.Session()
        self.sesion.headers.update({"User-Agent": user_agent})

    def _get(self, url, **params):
        params.setdefault("format", "json")
        r = self.sesion.get(url, params=params, timeout=20)
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------------ título
    @staticmethod
    def _base(titulo: str) -> str:
        """'Potes (Cantabria)' -> 'potes'"""
        return normalizar(titulo.split(" (")[0].split(",")[0])

    def buscar_titulo(self, nombre: str, provincia: str = "", lat=None, lon=None):
        objetivo = normalizar(nombre)
        candidatos = []
        if lat is not None and lon is not None:
            js = self._get(WIKI_API, action="query", list="geosearch",
                           gscoord=f"{lat}|{lon}", gsradius=10000, gslimit=50)
            candidatos = [g["title"] for g in js.get("query", {}).get("geosearch", [])]
            for t in candidatos:              # 1º: nombre exacto cerca de la foto
                if self._base(t) == objetivo:
                    return t
        js = self._get(WIKI_API, action="query", list="search",
                       srsearch=f"{nombre} {provincia}".strip(), srlimit=10)
        textuales = [s["title"] for s in js.get("query", {}).get("search", [])]
        for t in textuales:                   # 2º: nombre exacto en la búsqueda
            if self._base(t) == objetivo:
                return t
        for t in candidatos + textuales:      # 3º: algo que lo contenga
            if objetivo and objetivo in normalizar(t):
                return t
        return None

    # ------------------------------------------------------------------ datos
    def datos(self, titulo: str) -> dict:
        js = self._get(WIKI_API, action="query", prop="extracts|pageprops|info", titles=titulo,
                       exintro=1, explaintext=1, redirects=1, inprop="url")
        paginas = js.get("query", {}).get("pages", {})
        pagina = next(iter(paginas.values()), {})
        if "missing" in pagina:
            return {}
        props = pagina.get("pageprops", {})
        res = {
            "titulo": pagina.get("title", titulo),
            "url": pagina.get("fullurl", ""),
            "extracto": (pagina.get("extract") or "").strip(),
            "desambiguacion": "disambiguation" in props,
        }
        qid = props.get("wikibase_item")
        if qid:
            res["wikidata"] = qid
            try:
                res.update(self._wikidata(qid))
            except requests.RequestException:
                pass
        return res

    def _wikidata(self, qid: str) -> dict:
        js = self._get(WIKIDATA_API, action="wbgetentities", ids=qid, props="claims")
        claims = js.get("entities", {}).get(qid, {}).get("claims", {})
        res = {}

        def mejor(prop):
            lista = [c for c in claims.get(prop, []) if c.get("rank") != "deprecated"
                     and c.get("mainsnak", {}).get("datavalue")]
            if not lista:
                return None
            preferidas = [c for c in lista if c.get("rank") == "preferred"]
            if preferidas:
                return preferidas[0]

            def fecha(c):  # la más reciente según el calificador "fecha" (P585)
                q = c.get("qualifiers", {}).get("P585", [])
                try:
                    return q[0]["datavalue"]["value"]["time"]
                except (IndexError, KeyError):
                    return ""
            return max(lista, key=fecha)

        def valor(prop):
            c = mejor(prop)
            return c["mainsnak"]["datavalue"]["value"] if c else None

        pob = mejor("P1082")
        if pob:
            res["poblacion"] = int(float(pob["mainsnak"]["datavalue"]["value"]["amount"]))
            try:
                res["poblacion_anio"] = pob["qualifiers"]["P585"][0]["datavalue"]["value"]["time"][1:5]
            except (KeyError, IndexError):
                pass
        alt = valor("P2044")
        if alt:
            res["altitud"] = round(float(alt["amount"]))
        sup = valor("P2046")
        if sup:
            res["superficie"] = round(float(sup["amount"]), 2)
        escudo = valor("P94")
        if escudo:
            res["escudo"] = ("https://commons.wikimedia.org/wiki/Special:FilePath/"
                             + escudo.replace(" ", "_") + "?width=160")
        web = valor("P856")
        if web:
            res["web"] = web
        coord = valor("P625")
        if coord:
            res["lat"], res["lon"] = coord.get("latitude"), coord.get("longitude")
        return res

    def todo(self, nombre: str, provincia: str = "", lat=None, lon=None) -> dict:
        titulo = self.buscar_titulo(nombre, provincia, lat, lon)
        if not titulo:
            return {}
        d = self.datos(titulo)
        if d.get("desambiguacion") and provincia:
            otro = self.buscar_titulo(f"{nombre} ({provincia})", provincia)
            if otro and otro != titulo:
                d = self.datos(otro)
        return d


# ============================================================================ información ampliada
import re as _re
from urllib.parse import unquote as _unquote

SPARQL = "https://query.wikidata.org/sparql"
from . import fiestas as _F  # noqa: E402
COMMONS_API = "https://commons.wikimedia.org/w/api.php"
MAX_SECCION = 1600

# Apartados del artículo que interesan, en el orden en que se muestran
APARTADOS = [
    ("historia", ("historia",)),
    ("patrimonio", ("patrimonio", "monumento", "lugares de interes", "arquitectura", "que ver", "edificios")),
    ("fiestas", ("fiesta", "festividad", "celebracion")),
    ("gastronomia", ("gastronomia", "cocina", "productos tipicos")),
    ("cultura", ("cultura", "tradicion", "folclore", "costumbres")),
    ("leyendas", ("leyenda", "curiosidad", "mitologia", "anecdota")),
    ("naturaleza", ("naturaleza", "espacios naturales", "medio ambiente", "rutas", "senderismo", "turismo")),
    ("personajes", ("personajes", "personalidades", "hijos ilustres", "vecinos ilustres")),
]


def _tipo_apartado(titulo: str):
    t = normalizar(titulo)
    for clave, palabras in APARTADOS:
        if any(p in t for p in palabras):
            return clave
    return None


def _recortar(texto: str, maximo: int = MAX_SECCION) -> str:
    texto = _re.sub(r"\n{3,}", "\n\n", texto).strip()
    if len(texto) <= maximo:
        return texto
    corte = texto.rfind("\n\n", 0, maximo)
    if corte < maximo * 0.5:
        corte = texto.rfind(". ", 0, maximo) + 1
    return texto[:corte].rstrip() + " …"


def partir_secciones(texto: str) -> list:
    """Texto completo del artículo (con '== Título ==') -> apartados interesantes."""
    res, actual, sub = {}, None, []
    cab = _re.compile(r"^(={2,6})\s*(.*?)\s*\1\s*$")
    for linea in (texto or "").splitlines():
        m = cab.match(linea.strip())
        if m:
            nivel, titulo = len(m.group(1)), m.group(2)
            if nivel == 2:
                actual = _tipo_apartado(titulo)
                sub = [titulo]
                if actual and actual not in res:
                    res[actual] = {"clave": actual, "titulo": titulo, "texto": []}
                elif actual:
                    res[actual]["texto"].append("")
            elif actual:
                res[actual]["texto"].append(f"\n▸ {titulo}")
            continue
        if actual:
            res[actual]["texto"].append(linea)
    salida = []
    for clave, _ in APARTADOS:
        if clave in res:
            t = _recortar("\n".join(res[clave]["texto"]).replace("\n▸", "\n\n▸"))
            if len(t) > 60:
                salida.append({"clave": clave, "titulo": res[clave]["titulo"], "texto": t})
    return salida


def _credito_commons(meta: dict, pagina: str) -> dict:
    from .commons import _limpiar
    val = lambda k: _limpiar(meta.get(k, {}).get("value", ""))  # noqa: E731
    return {"autor": val("Artist")[:120] or "Autor desconocido", "licencia": val("LicenseShortName") or "Licencia libre",
            "url_licencia": meta.get("LicenseUrl", {}).get("value", ""), "fuente": pagina}


def _ampliar(self, d: dict) -> dict:
    """Añade a los datos de Wikipedia: apartados del artículo, qué ver, gentilicio y patrón."""
    try:
        js = self._get(WIKI_API, action="query", prop="extracts", titles=d["titulo"], explaintext=1,
                       exsectionformat="wiki", redirects=1)
        pagina = next(iter(js.get("query", {}).get("pages", {}).values()), {})
        secciones = partir_secciones(pagina.get("extract", ""))
        if secciones:
            d["secciones"] = secciones
        d["fiestas"] = _F.de_wikipedia(pagina.get("extract", ""))
    except (requests.RequestException, ValueError, KeyError):
        pass
    qid = d.get("wikidata")
    if not qid:
        return d
    try:
        d.update(self._wikidata_extra(qid))
    except (requests.RequestException, ValueError, KeyError):
        pass
    try:
        d["fiestas"] = _F.juntar(d.get("fiestas"), _F.de_wikidata(self.sesion, WIKIDATA_API, SPARQL, qid))
    except (requests.RequestException, ValueError, KeyError):
        pass
    try:
        que_ver = self._que_ver(qid)
        if que_ver:
            d["que_ver"] = que_ver
    except (requests.RequestException, ValueError, KeyError):
        pass
    return d


def _wikidata_extra(self, qid: str) -> dict:
    js = self._get(WIKIDATA_API, action="wbgetentities", ids=qid, props="claims")
    claims = js.get("entities", {}).get(qid, {}).get("claims", {})
    res = {}
    gent = [c["mainsnak"]["datavalue"]["value"] for c in claims.get("P1549", [])
            if c.get("mainsnak", {}).get("datavalue")]
    gent_es = [g["text"] for g in gent if g.get("language") == "es"]
    if gent_es:
        res["gentilicio"] = ", ".join(dict.fromkeys(gent_es[:2]))
    patrones = [c["mainsnak"]["datavalue"]["value"]["id"] for c in claims.get("P417", [])
                if c.get("mainsnak", {}).get("datavalue")][:3]
    if patrones:
        et = self._get(WIKIDATA_API, action="wbgetentities", ids="|".join(patrones), props="labels", languages="es")
        nombres = [e.get("labels", {}).get("es", {}).get("value") for e in et.get("entities", {}).values()]
        nombres = [n for n in nombres if n]
        if nombres:
            res["patron"] = ", ".join(nombres)
    return res


def _que_ver(self, qid: str, maximo: int = 12) -> list:
    consulta = f"""SELECT ?item ?itemLabel ?img ?art WHERE {{
  ?item wdt:P131 wd:{qid} .
  {{ ?item wdt:P1435 ?proteccion }} UNION {{ ?item wdt:P31/wdt:P279* wd:Q570116 }}
  UNION {{ ?item wdt:P31/wdt:P279* wd:Q16970 }} UNION {{ ?item wdt:P31/wdt:P279* wd:Q23413 }}
  UNION {{ ?item wdt:P31/wdt:P279* wd:Q33506 }} UNION {{ ?item wdt:P31/wdt:P279* wd:Q12280 }}
  OPTIONAL {{ ?item wdt:P18 ?img }}
  OPTIONAL {{ ?art schema:about ?item ; schema:isPartOf <https://es.wikipedia.org/> }}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "es,en". }}
}} LIMIT 80"""
    r = self.sesion.get(SPARQL, params={"query": consulta, "format": "json"}, timeout=40)
    r.raise_for_status()
    vistos, lugares = set(), []
    for b in r.json().get("results", {}).get("bindings", []):
        item = b["item"]["value"].rsplit("/", 1)[-1]
        nombre = b.get("itemLabel", {}).get("value", "")
        if item in vistos or not nombre or _re.fullmatch(r"Q\d+", nombre):
            continue
        vistos.add(item)
        lugar = {"nombre": nombre, "url": b.get("art", {}).get("value") or f"https://www.wikidata.org/wiki/{item}"}
        if b.get("img"):
            lugar["_archivo"] = _unquote(b["img"]["value"].rsplit("/", 1)[-1]).replace("_", " ")
        lugares.append(lugar)
    lugares.sort(key=lambda x: ("_archivo" not in x, "wikipedia" not in x["url"]))
    lugares = lugares[:maximo]
    archivos = [x["_archivo"] for x in lugares if "_archivo" in x]
    if archivos:
        js = self._get(COMMONS_API, action="query", prop="imageinfo", iiprop="url|extmetadata", iiurlwidth=500,
                       titles="|".join("File:" + a for a in archivos),
                       iiextmetadatafilter="Artist|LicenseShortName|LicenseUrl")
        info = {}
        normal = {n["from"]: n["to"] for n in js.get("query", {}).get("normalized", [])}
        for pg in js.get("query", {}).get("pages", {}).values():
            ii = (pg.get("imageinfo") or [{}])[0]
            if ii.get("thumburl"):
                info[pg.get("title", "")] = ii
        for x in lugares:
            a = x.pop("_archivo", None)
            if not a:
                continue
            t = normal.get("File:" + a, "File:" + a)
            ii = info.get(t)
            if ii:
                x["imagen"] = ii["thumburl"]
                x["credito"] = _credito_commons(ii.get("extmetadata", {}), ii.get("descriptionurl", ""))
    for x in lugares:
        x.pop("_archivo", None)
    return lugares


Wikipedia.ampliar = _ampliar
Wikipedia._wikidata_extra = _wikidata_extra
Wikipedia._que_ver = _que_ver
_todo_basico = Wikipedia.todo


def _todo_ampliado(self, nombre, provincia="", lat=None, lon=None):
    d = _todo_basico(self, nombre, provincia, lat, lon)
    return self.ampliar(d) if d else d


Wikipedia.todo = _todo_ampliado
