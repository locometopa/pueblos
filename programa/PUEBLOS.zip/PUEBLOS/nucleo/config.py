"""Configuración del programa PUEBLOS (se guarda en config.json junto al programa)."""
import json
import sys
from pathlib import Path

VERSION = "1.5.2"
NOMBRE_PROGRAMA = "PUEBLOS"


def carpeta_programa() -> Path:
    """Carpeta donde está el programa (o el .exe si está empaquetado)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE = carpeta_programa()
ARCHIVO_CONFIG = BASE / "config.json"

DEFECTO = {
    "titulo_web": "Mis pueblos",
    "subtitulo_web": "Cuaderno de los pueblos que he visitado",
    "autor": "",
    "repo_url": "",            # p. ej. https://github.com/locometopa/pueblos.git
    "api_key": "",             # clave de la API de Anthropic (opcional, para el texto con IA)
    "modelo_ia": "claude-haiku-5-5",
    "copia_carpeta": "", "copia_auto": True, "copia_ultima": "",
    "ia_proveedor": "claude",      # claude | chatgpt | gemini | compatible
    "clave_chatgpt": "", "modelo_chatgpt": "gpt-5.4-mini",
    "clave_gemini": "", "modelo_gemini": "gemini-3.6-flash",
    "clave_compatible": "", "modelo_compatible": "", "url_compatible": "",
    "carpeta_datos": str(BASE / "datos"),
    "carpeta_sitio": str(BASE / "sitio"),
    "lado_foto": 1600,         # tamaño máximo de las fotos publicadas (píxeles)
    "traer_wiki_al_importar": True,
    "generar_ia_al_importar": False,
    "mostrar_pendientes": True,    # enseñar en la web los pueblos por visitar
    "tema": "System",             # aspecto del programa: System, Light, Dark
    "github_token": "",           # opcional: publicar sin iniciar sesión y ver el estado (solo en este PC)
    "diseno": {},                 # diseño de la web (ver nucleo/diseno.py)
    "logo_ruta": "",              # imagen del logo/icono de la web
}

COMUNIDADES = [
    "Andalucía", "Aragón", "Asturias", "Islas Baleares", "Canarias", "Cantabria",
    "Castilla-La Mancha", "Castilla y León", "Cataluña", "Comunidad Valenciana",
    "Extremadura", "Galicia", "Comunidad de Madrid", "Región de Murcia", "Navarra",
    "País Vasco", "La Rioja", "Ceuta", "Melilla", "Fuera de España",
]


class Config(dict):
    def __init__(self):
        super().__init__(DEFECTO)
        if ARCHIVO_CONFIG.exists():
            try:
                self.update(json.loads(ARCHIVO_CONFIG.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                pass

    def guardar(self):
        ARCHIVO_CONFIG.write_text(json.dumps(self, ensure_ascii=False, indent=2), encoding="utf-8")

    @property
    def datos(self) -> Path:
        return Path(self["carpeta_datos"])

    @property
    def sitio(self) -> Path:
        return Path(self["carpeta_sitio"])

    @property
    def user_agent(self) -> str:
        return f"{NOMBRE_PROGRAMA}/{VERSION} (programa personal de pueblos visitados)"
