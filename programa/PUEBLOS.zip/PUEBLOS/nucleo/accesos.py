"""Accesos directos de Windows (escritorio y menú Inicio) con el icono del programa."""
import subprocess
import sys
from pathlib import Path

ICONO = Path(__file__).with_name("icono.ico")


def _ps(texto: str) -> str:
    return "'" + str(texto).replace("'", "''") + "'"


def crear(base: Path, escritorio=True, menu_inicio=True) -> list:
    """Crea (o renueva) «PUEBLOS.lnk». Abre PUEBLOS.bat minimizado (así instala lo que falte y se actualiza)
    o el .exe si el programa se está usando empaquetado. Devuelve dónde los ha puesto."""
    if sys.platform != "win32":
        return []
    base = Path(base)
    if getattr(sys, "frozen", False):
        destino, argumentos, ventana = Path(sys.executable), "", 1
        icono = f"{sys.executable},0"                                   # el .exe ya lleva el icono dentro
    else:
        destino, argumentos, ventana = base / "PUEBLOS.bat", "", 7      # 7 = minimizado: no se ve la consola
        icono = f"{base / 'nucleo' / 'icono.ico'},0"
    carpetas = []
    if escritorio:
        carpetas.append("[Environment]::GetFolderPath('Desktop')")
    if menu_inicio:
        carpetas.append("[Environment]::GetFolderPath('Programs')")
    script = (
        "$s = New-Object -ComObject WScript.Shell; $hechos = @(); "
        f"foreach ($d in @({', '.join(carpetas)})) {{ "
        "  if (-not $d) { continue }; $r = Join-Path $d 'PUEBLOS.lnk'; $l = $s.CreateShortcut($r); "
        f"  $l.TargetPath = {_ps(destino)}; $l.Arguments = {_ps(argumentos)}; $l.WorkingDirectory = {_ps(base)}; "
        f"  $l.IconLocation = {_ps(icono)}; $l.WindowStyle = {ventana}; "
        "  $l.Description = 'PUEBLOS - la web de tus pueblos visitados'; $l.Save(); $hechos += $r }; "
        "$hechos | ForEach-Object { $_ }"
    )
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                       capture_output=True, text=True, timeout=60, creationflags=0x08000000)
    if r.returncode != 0:
        raise OSError((r.stderr or r.stdout).strip()[:300] or "PowerShell no pudo crear el acceso directo")
    return [x for x in r.stdout.splitlines() if x.strip()]


def poner_icono_ventana(ventana):
    """Icono de la ventana y de la barra de tareas."""
    try:
        if sys.platform == "win32" and ICONO.exists():
            ventana.iconbitmap(str(ICONO))
            # La barra de tareas agrupa por programa: así sale el icono de PUEBLOS y no el de Python
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("locometopa.pueblos")
        else:
            png = ICONO.with_suffix(".png")
            if png.exists():
                import tkinter as tk
                ventana._icono_png = tk.PhotoImage(file=str(png))
                ventana.iconphoto(True, ventana._icono_png)
    except Exception:  # noqa: BLE001  (si falla, se queda el icono de siempre)
        pass
