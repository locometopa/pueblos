"""Consultas a la API de GitHub: comprobar el token y ver si la web se ha publicado bien."""
import re

import requests

API = "https://api.github.com"


def repo_de(url: str):
    m = re.search(r"github\.com[:/]([^/]+)/([^/]+?)(?:\.git)?/?$", (url or "").strip())
    return f"{m.group(1)}/{m.group(2)}" if m else None


class GitHubAPI:
    def __init__(self, token: str, repo_url: str):
        self.repo = repo_de(repo_url)
        self.sesion = requests.Session()
        self.sesion.headers.update({"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
                                    "User-Agent": "PUEBLOS"})
        if token:
            self.sesion.headers["Authorization"] = f"Bearer {token.strip()}"

    def comprobar(self) -> str:
        """Devuelve un texto con el resultado (o lanza un error con la explicación)."""
        if not self.repo:
            raise ValueError("La dirección del repositorio no es de GitHub.")
        r = self.sesion.get(f"{API}/repos/{self.repo}", timeout=20)
        if r.status_code == 401:
            raise ValueError("El token no es válido o ha caducado.")
        if r.status_code == 404:
            raise ValueError(f"El token no tiene acceso a {self.repo}.")
        r.raise_for_status()
        if not r.json().get("permissions", {}).get("push"):
            raise ValueError("El token puede ver el repositorio pero no escribir (Contents: Read and write).")
        return f"Token correcto: puede publicar en {self.repo}."

    def publicacion(self, sha: str):
        """Estado de «Publicar web» para ese commit: (estado, resultado, enlace) o None si aún no ha empezado."""
        r = self.sesion.get(f"{API}/repos/{self.repo}/actions/runs", params={"head_sha": sha, "per_page": 10}, timeout=20)
        r.raise_for_status()
        for run in r.json().get("workflow_runs", []):
            if run.get("name") == "Publicar web":
                return run.get("status"), run.get("conclusion"), run.get("html_url")
        return None
