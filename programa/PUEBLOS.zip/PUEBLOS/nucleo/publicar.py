"""Publicar la carpeta 'sitio' en GitHub (GitHub Pages) con git."""
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path


class ErrorPublicar(Exception):
    pass


_TOKEN = ""


def configurar_token(token: str):
    """Con un token de GitHub, git publica sin pedir iniciar sesión (el token no aparece en ningún mensaje)."""
    global _TOKEN
    _TOKEN = (token or "").strip()


def _entorno():
    import os
    import base64
    env = dict(os.environ)
    if _TOKEN:
        cred = base64.b64encode(f"x-access-token:{_TOKEN}".encode()).decode()
        env.update({"GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "http.https://github.com/.extraheader",
                    "GIT_CONFIG_VALUE_0": f"AUTHORIZATION: basic {cred}", "GIT_TERMINAL_PROMPT": "0"})
    return env


def _git(args, carpeta: Path, comprobar=True):
    opciones = {}
    if sys.platform == "win32":
        opciones["creationflags"] = 0x08000000  # CREATE_NO_WINDOW: sin ventana negra
    r = subprocess.run(["git", *args], cwd=carpeta, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=_entorno(), **opciones)
    if comprobar and r.returncode != 0:
        raise ErrorPublicar(f"git {' '.join(args)}:\n{(r.stderr or r.stdout).strip()}")
    return r


def git_disponible() -> bool:
    return shutil.which("git") is not None


def url_web(repo_url: str) -> str:
    """https://github.com/usuario/repo(.git) -> https://usuario.github.io/repo/"""
    m = re.search(r"github\.com[:/]([^/]+)/([^/]+?)(?:\.git)?/?$", repo_url.strip())
    if not m:
        return ""
    usuario, repo = m.group(1), m.group(2)
    if repo.lower() == f"{usuario.lower()}.github.io":
        return f"https://{usuario}.github.io/"
    return f"https://{usuario}.github.io/{repo}/"


def publicar(carpeta: Path, repo_url: str, avisar=print) -> str:
    """Sube los cambios. Devuelve un texto con el resultado."""
    if not git_disponible():
        raise ErrorPublicar("No encuentro git. Instala «Git for Windows» (git-scm.com) y vuelve a probar.")
    if not repo_url:
        raise ErrorPublicar("Falta la dirección del repositorio de GitHub (Configuración).")
    carpeta = Path(carpeta)

    if not (carpeta / ".git").exists():
        avisar("Preparando la carpeta para GitHub…")
        _git(["init"], carpeta)
        _git(["checkout", "-B", "main"], carpeta)
    remotos = _git(["remote"], carpeta).stdout.split()
    if "origin" in remotos:
        _git(["remote", "set-url", "origin", repo_url], carpeta)
    else:
        _git(["remote", "add", "origin", repo_url], carpeta)
    # Autor de los commits (solo para este repositorio, si no hay uno global)
    if not _git(["config", "user.name"], carpeta, comprobar=False).stdout.strip():
        _git(["config", "user.name", "PUEBLOS"], carpeta)
    if not _git(["config", "user.email"], carpeta, comprobar=False).stdout.strip():
        _git(["config", "user.email", "pueblos@localhost"], carpeta)

    _git(["add", "-A"], carpeta)
    hay_cambios = _git(["diff", "--cached", "--quiet"], carpeta, comprobar=False).returncode != 0
    if hay_cambios:
        _git(["commit", "-m", f"Actualización {time.strftime('%Y-%m-%d %H:%M')}"], carpeta)

    avisar("Subiendo a GitHub… (la primera vez se abrirá el navegador para iniciar sesión)")
    r = _git(["push", "-u", "origin", "main"], carpeta, comprobar=False)
    if r.returncode != 0 and ("rejected" in r.stderr or "fetch first" in r.stderr):
        # El repositorio de GitHub ya tenía algo (p. ej. un README): lo unimos y reintentamos.
        avisar("El repositorio ya tenía archivos; los uno con los tuyos…")
        _git(["fetch", "origin", "main"], carpeta)
        _git(["merge", "origin/main", "--allow-unrelated-histories", "-X", "ours",
              "-m", "Unir con GitHub"], carpeta)
        r = _git(["push", "-u", "origin", "main"], carpeta, comprobar=False)
    if r.returncode != 0:
        raise ErrorPublicar("No se pudo subir a GitHub:\n" + (r.stderr or r.stdout).strip())
    if not hay_cambios:
        return "No había cambios nuevos; la web ya estaba al día."
    return "¡Publicado! GitHub tarda 1 o 2 minutos en actualizar la web."
