"""Sincroniza los datos del programa con el repositorio de GitHub.

El repositorio guarda los pueblos (datos/) y el generador de la web. GitHub Actions
rehace la web cada vez que cambia algo, tanto desde este programa como desde el panel
web de gestión (…github.io/pueblos/gestion/).
"""
import json
import shutil
import time
from pathlib import Path

from .datos import Almacen, clave_original, reparar
from .publicar import ErrorPublicar, _git, git_disponible

RAIZ_NUCLEO = Path(__file__).resolve().parent
ARCHIVOS_GENERADOR = ["__init__.py", "web.py", "mapa.py", "datos.py", "generar.py", "diseno.py", "extras.py", "fiestas.py", "provincias.geojson", "vecinos.geojson"]
CARPETAS_GENERADOR = ["js", "gestion"]
RESTOS_ANTIGUOS = ["index.html", "estilo.css", ".nojekyll", "pueblos", "js"]  # web publicada al estilo 0.1/0.2

WORKFLOW = """name: Publicar web
on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: true

jobs:
  construir:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: Preparar (imágenes para compartir e iconos)
        run: pip install pillow
      - name: Generar la web
        run: cd generador && python -m nucleo.generar --datos ../datos --salida ../_site --ajustes ../ajustes_web.json
      - uses: actions/upload-pages-artifact@v3
        with:
          path: _site
  publicar:
    needs: construir
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.despliegue.outputs.page_url }}
    steps:
      - id: despliegue
        uses: actions/deploy-pages@v4
"""

GITIGNORE = """datos/_papelera/
datos/_cache_geo.json
datos/**/*.tmp
_site/
__pycache__/
"""

README = """# Mis pueblos

Datos y generador de mi web de pueblos visitados.

- `datos/` — un pueblo por carpeta (`pueblo.json`, `fotos/`, `mini/`). Las fotos ya están reducidas y sin GPS.
- `generador/` — código que crea la web (lo ejecuta GitHub Actions en cada cambio).
- Panel de gestión: `/gestion/` dentro de la web.

Se edita con el programa PUEBLOS (Windows) o desde el panel web. No hace falta tocar nada aquí a mano.
"""


def unir_pueblo(base: dict, nuestro: dict, suyo: dict) -> dict:
    """Unión a tres bandas de un pueblo cambiado en dos sitios a la vez.
    Cada campo: si solo cambió en un lado, gana ese lado; si cambió en los dos, gana el más reciente.
    Fotos: se juntan las de los dos lados y se quitan las que cualquiera de los dos quitó."""
    gana_nuestro = (nuestro.get("modificado") or "") >= (suyo.get("modificado") or "")
    res = dict(suyo)
    for k in set(base) | set(nuestro) | set(suyo):
        if k == "fotos":
            continue
        b, n, s = base.get(k), nuestro.get(k), suyo.get(k)
        if n == s or n == b:
            res[k] = s
        elif s == b:
            res[k] = n
        else:
            res[k] = n if gana_nuestro else s
    fb = {f["archivo"]: f for f in base.get("fotos", [])}
    fn = {f["archivo"]: f for f in nuestro.get("fotos", [])}
    fs = {f["archivo"]: f for f in suyo.get("fotos", [])}
    fotos = []
    for nombre in list(fs) + [x for x in fn if x not in fs]:
        if nombre in fb and (nombre not in fn or nombre not in fs):
            continue   # uno de los dos la quitó
        a, b2, c = fn.get(nombre), fb.get(nombre), fs.get(nombre)
        if a and c and a != c:
            elegido = c if a == b2 else a if c == b2 else (a if gana_nuestro else c)
        else:
            elegido = c or a
        fotos.append(elegido)
    res["fotos"] = fotos
    if res.get("portada") not in {f["archivo"] for f in fotos}:
        res["portada"] = fotos[0]["archivo"] if fotos else ""
    return res


class Sincronizador:
    def __init__(self, cfg, avisar=print):
        self.cfg = cfg
        self.avisar = avisar
        self.repo = Path(cfg.get("carpeta_repo") or (Path(cfg.sitio).parent / "repo"))
        self.ultimo_sha = ""

    # ------------------------------------------------------------------ util
    def _rama_remota(self) -> bool:
        r = _git(["ls-remote", "--heads", "origin", "main"], self.repo, comprobar=False)
        return r.returncode == 0 and "refs/heads/main" in r.stdout

    def _hay_cambios(self) -> bool:
        return bool(_git(["status", "--porcelain"], self.repo).stdout.strip())

    def _identidad(self):
        if not _git(["config", "user.name"], self.repo, comprobar=False).stdout.strip():
            _git(["config", "user.name", "PUEBLOS"], self.repo)
        if not _git(["config", "user.email"], self.repo, comprobar=False).stdout.strip():
            _git(["config", "user.email", "pueblos@localhost"], self.repo)

    # ------------------------------------------------------------------ pasos
    def preparar(self):
        """Clona el repositorio si aún no está, y lleva los datos dentro (solo la primera vez)."""
        if not git_disponible():
            raise ErrorPublicar("No encuentro git. Instala «Git for Windows» (git-scm.com) y vuelve a probar.")
        url = self.cfg.get("repo_url")
        if not url:
            raise ErrorPublicar("Falta la dirección del repositorio de GitHub (Ajustes).")
        if not (self.repo / ".git").exists():
            self.avisar("Descargando tu repositorio de GitHub…")
            if self.repo.exists() and any(self.repo.iterdir()):
                raise ErrorPublicar(f"La carpeta {self.repo} ya existe y no es un repositorio. Muévela y vuelve a probar.")
            self.repo.parent.mkdir(parents=True, exist_ok=True)
            r = _git(["clone", url, str(self.repo)], self.repo.parent, comprobar=False)
            if r.returncode != 0:
                raise ErrorPublicar("No se pudo descargar el repositorio:\n" + (r.stderr or r.stdout).strip())
            if _git(["rev-parse", "--verify", "HEAD"], self.repo, comprobar=False).returncode != 0:
                _git(["checkout", "-B", "main"], self.repo)       # repositorio vacío
        else:
            _git(["remote", "set-url", "origin", url], self.repo)
        self._identidad()
        self._migrar()

    def _migrar(self):
        """La primera vez, copia los pueblos de la carpeta antigua al repositorio."""
        destino = self.repo / "datos"
        actual = Path(self.cfg.datos)
        if actual.resolve() == destino.resolve():
            return
        destino.mkdir(parents=True, exist_ok=True)
        if actual.exists():
            self.avisar("Pasando tus pueblos al repositorio (tu carpeta antigua se conserva como copia)…")
            for c in actual.iterdir():
                if c.is_dir() and not c.name.startswith("_") and (c / "pueblo.json").exists():
                    if not (destino / c.name).exists():
                        shutil.copytree(c, destino / c.name)
            cache = actual / "_cache_geo.json"
            if cache.exists() and not (destino / "_cache_geo.json").exists():
                shutil.copy2(cache, destino / "_cache_geo.json")
        # El repositorio es público: no guardar rutas de tu ordenador
        alm = Almacen(destino)
        for p in alm.listar():
            cambiado = False
            for f in p["fotos"]:
                o = f.get("original") or ""
                if o and not o.startswith("http") and ("\\" in o or "/" in o):
                    f["original"] = clave_original(o)
                    cambiado = True
            if cambiado:
                alm.guardar(p)
        self.cfg["carpeta_datos"] = str(destino)
        self.cfg["carpeta_repo"] = str(self.repo)
        self.cfg.guardar()
        # La carpeta antigua se conserva como copia, con un nombre que deje claro que ya no se usa
        if actual.exists() and actual.name == "datos" and actual.parent == self.repo.parent:
            copia = actual.with_name("copia_datos_antiguos")
            if not copia.exists():
                try:
                    actual.rename(copia)
                except OSError:
                    pass

    def _confirmar_locales(self, mensaje):
        _git(["add", "-A"], self.repo)
        if _git(["diff", "--cached", "--quiet"], self.repo, comprobar=False).returncode != 0:
            _git(["commit", "-m", mensaje], self.repo)
            return True
        return False

    def traer(self) -> bool:
        """Guarda los cambios locales y trae los del panel web. Devuelve True si llegó algo nuevo."""
        self.preparar()
        self._confirmar_locales(f"Cambios desde el programa · {time.strftime('%Y-%m-%d %H:%M')}")
        if not self._rama_remota():
            return False
        antes = _git(["rev-parse", "HEAD"], self.repo, comprobar=False).stdout.strip()
        self.avisar("Trayendo cambios de GitHub…")
        _git(["fetch", "origin", "main"], self.repo)
        # Pueblos tocados a la vez aquí y en el panel: se unirán campo a campo (no línea a línea)
        base = _git(["merge-base", "HEAD", "origin/main"], self.repo, comprobar=False).stdout.strip()
        ambos = {}
        if base and antes:
            def tocados(a, b):
                return {x for x in _git(["diff", "--name-only", a, b, "--", "datos"], self.repo).stdout.split()
                        if x.endswith("/pueblo.json")}
            for ruta in tocados(base, "HEAD") & tocados(base, "origin/main"):
                ambos[ruta] = [self._json_en(ref, ruta) for ref in (base, "HEAD", "origin/main")]
        r = _git(["merge", "--no-edit", "-X", "theirs", "--allow-unrelated-histories", "origin/main"],
                 self.repo, comprobar=False)
        if r.returncode != 0:
            _git(["merge", "--abort"], self.repo, comprobar=False)
            raise ErrorPublicar("No se pudieron unir los cambios de GitHub con los tuyos:\n" + (r.stderr or r.stdout).strip())
        for ruta, (b, nuestro, suyo) in ambos.items():
            if nuestro is not None and suyo is not None:
                unido = unir_pueblo(b or {}, nuestro, suyo)
                (self.repo / ruta).write_text(json.dumps(unido, ensure_ascii=False, indent=2), encoding="utf-8")
        if ambos:
            self._confirmar_locales("Unir cambios del panel y del programa")
        despues = _git(["rev-parse", "HEAD"], self.repo).stdout.strip()
        # Si dos sitios tocaron el mismo pueblo, que no se pierdan fotos ni quede un JSON roto
        arreglados = reparar(Almacen(self.repo / "datos"), self._json_remoto)
        if arreglados:
            self._confirmar_locales("Reparar pueblos tras unir cambios")
        return antes != despues

    def _json_en(self, ref, ruta_rel):
        r = _git(["show", f"{ref}:{ruta_rel}"], self.repo, comprobar=False)
        try:
            return json.loads(r.stdout) if r.returncode == 0 else None
        except ValueError:
            return None

    def _json_remoto(self, ruta_rel: str):
        r = _git(["show", f"origin/main:{ruta_rel}"], self.repo, comprobar=False)
        return r.stdout if r.returncode == 0 else None

    def _instalar_generador(self):
        from . import actualizar
        from .config import VERSION
        if actualizar.disponible(self.repo, VERSION):
            # En GitHub hay una versión más nueva del programa: no se pisa su generador con uno viejo
            self.avisar("Hay una versión nueva del programa: actualízala para publicar los cambios de diseño.")
            self._escribir_ajustes()
            return
        g = self.repo / "generador" / "nucleo"
        if g.exists():
            shutil.rmtree(g)
        g.mkdir(parents=True)
        for f in ARCHIVOS_GENERADOR:
            shutil.copy2(RAIZ_NUCLEO / f, g / f)
        for c in CARPETAS_GENERADOR:
            shutil.copytree(RAIZ_NUCLEO / c, g / c, ignore=shutil.ignore_patterns("__pycache__"))
        wf = self.repo / ".github" / "workflows"
        wf.mkdir(parents=True, exist_ok=True)
        (wf / "web.yml").write_text(WORKFLOW, encoding="utf-8")
        (self.repo / ".gitignore").write_text(GITIGNORE, encoding="utf-8")
        if not (self.repo / "README.md").exists() or "Mis pueblos" not in (self.repo / "README.md").read_text(
                encoding="utf-8", errors="ignore"):
            (self.repo / "README.md").write_text(README, encoding="utf-8")
        self._escribir_ajustes()
        for resto in RESTOS_ANTIGUOS:
            ruta = self.repo / resto
            if ruta.is_dir():
                shutil.rmtree(ruta)
            elif ruta.exists():
                ruta.unlink()

    def _escribir_ajustes(self):
        ajustes = {k: self.cfg.get(k) for k in ("titulo_web", "subtitulo_web", "autor", "mostrar_pendientes")}
        ajustes["diseno"] = self.cfg.get("diseno") or {}
        (self.repo / "ajustes_web.json").write_text(json.dumps(ajustes, ensure_ascii=False, indent=2), encoding="utf-8")
        logo_repo = self.repo / "diseno" / "logo.png"
        logo = self.cfg.get("logo_ruta")
        if logo and Path(logo).exists():
            if Path(logo).resolve() != logo_repo.resolve():
                logo_repo.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(logo, logo_repo)
        elif logo_repo.exists():
            logo_repo.unlink()

    def subir(self) -> str:
        """Trae lo del panel, añade lo tuyo y lo sube. GitHub rehace la web después."""
        self.traer()
        self._instalar_generador()
        self._confirmar_locales(f"Actualización · {time.strftime('%Y-%m-%d %H:%M')}")
        self.avisar("Subiendo a GitHub… (la primera vez se abrirá el navegador para iniciar sesión)")
        r = _git(["push", "-u", "origin", "main"], self.repo, comprobar=False)
        if r.returncode != 0 and ("rejected" in r.stderr or "fetch first" in r.stderr):
            self.traer()          # alguien subió algo justo ahora desde el panel
            r = _git(["push", "-u", "origin", "main"], self.repo, comprobar=False)
        if r.returncode != 0:
            raise ErrorPublicar("No se pudo subir a GitHub:\n" + (r.stderr or r.stdout).strip())
        self.ultimo_sha = _git(["rev-parse", "HEAD"], self.repo).stdout.strip()
        if "Everything up-to-date" in (r.stderr + r.stdout):
            return "Todo estaba ya al día en GitHub."
        return "¡Subido! GitHub tarda 1 o 2 minutos en actualizar la web."
