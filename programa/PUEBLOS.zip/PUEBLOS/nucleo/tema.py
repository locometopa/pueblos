"""Colores y estilo del programa (CustomTkinter), a juego con la web."""
import sys

import customtkinter as ctk

# (modo claro, modo oscuro)
PAPEL = ("#f5efe3", "#1c1a17")
TARJETA = ("#fffaf0", "#262320")
TARJETA_2 = ("#ece3d2", "#2f2b26")
LINEA = ("#d8ccb6", "#3d3832")
TINTA = ("#2a2621", "#efe7d8")
TINTA_2 = ("#6b6257", "#b3a893")
ACENTO = ("#a8472a", "#d0663f")
ACENTO_HOVER = ("#8a3a22", "#b3532f")
PENDIENTE = ("#2f6f6a", "#7fc4bb")
PELIGRO = ("#9c2f2f", "#c45050")
LATERAL = ("#2a2621", "#141210")
LATERAL_HOVER = ("#3d3730", "#26221e")
LATERAL_TEXTO = ("#efe7d8", "#efe7d8")
LATERAL_TEXTO_2 = ("#a99f8f", "#8e8576")
ENTRADA = ("#fffdf8", "#2a2622")

# Para el mapa del programa
MAPA_FONDO = TARJETA
MAPA_TAPADA = ("#d9d0bf", "#3a3631")
MAPA_TAPADA_RAYA = ("#cbc1ad", "#433e38")
MAPA_BORDE = ("#fffaf0", "#262320")
MAPA_SOLO_COLOR = ACENTO

FUENTE = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
FUENTE_TITULO = "Georgia" if sys.platform == "win32" else "DejaVu Serif"


def aplicar(modo: str = "System"):
    ctk.set_default_color_theme("blue")
    t = ctk.ThemeManager.theme
    t["CTk"]["fg_color"] = list(PAPEL)
    t["CTkToplevel"]["fg_color"] = list(PAPEL)
    t["CTkFrame"].update(fg_color=list(TARJETA), top_fg_color=list(TARJETA_2), border_color=list(LINEA), corner_radius=10)
    t["CTkButton"].update(fg_color=list(ACENTO), hover_color=list(ACENTO_HOVER), text_color=["#ffffff", "#ffffff"],
                          border_color=list(LINEA), corner_radius=8)
    t["CTkLabel"]["text_color"] = list(TINTA)
    t["CTkEntry"].update(fg_color=list(ENTRADA), border_color=list(LINEA), text_color=list(TINTA),
                         placeholder_text_color=list(TINTA_2), border_width=1, corner_radius=8)
    t["CTkTextbox"].update(fg_color=list(ENTRADA), border_color=list(LINEA), text_color=list(TINTA),
                           border_width=1, corner_radius=8)
    t["CTkComboBox"].update(fg_color=list(ENTRADA), border_color=list(LINEA), button_color=list(LINEA),
                            button_hover_color=list(TINTA_2), text_color=list(TINTA), border_width=1, corner_radius=8)
    t["CTkCheckBox"].update(fg_color=list(ACENTO), hover_color=list(ACENTO_HOVER), border_color=list(TINTA_2),
                            text_color=list(TINTA), border_width=2)
    t["CTkSwitch"].update(progress_color=list(ACENTO), fg_color=list(LINEA), text_color=list(TINTA))
    # Estilo "píldora": la opción elegida en blanco sobre fondo beige (buen contraste con texto oscuro)
    t["CTkSegmentedButton"].update(fg_color=list(TARJETA_2), selected_color=["#ffffff", "#4a443c"],
                                   selected_hover_color=["#ffffff", "#4a443c"], unselected_color=list(TARJETA_2),
                                   unselected_hover_color=list(LINEA), text_color=list(TINTA), border_width=3)
    t["CTkProgressBar"].update(fg_color=list(TARJETA_2), progress_color=list(ACENTO))
    t["CTkOptionMenu"].update(fg_color=list(LATERAL_HOVER), button_color=list(LATERAL_HOVER),
                              button_hover_color=list(ACENTO), text_color=list(LATERAL_TEXTO))
    t["CTkScrollableFrame"]["label_fg_color"] = list(TARJETA_2)
    t["CTkScrollbar"].update(button_color=list(LINEA), button_hover_color=list(TINTA_2))
    t["DropdownMenu"].update(fg_color=list(TARJETA), hover_color=list(TARJETA_2), text_color=list(TINTA))
    t["CTkFont"].update(family=FUENTE, size=13)
    ctk.set_appearance_mode(modo)


def color(par) -> str:
    """Color concreto según el modo actual."""
    return par[1] if ctk.get_appearance_mode() == "Dark" else par[0]


def fuente(tam=13, peso="normal"):
    return ctk.CTkFont(family=FUENTE, size=tam, weight=peso)


def fuente_titulo(tam=26):
    return ctk.CTkFont(family=FUENTE_TITULO, size=tam, weight="bold")


# ---------------------------------------------------------------- botones
def boton(padre, texto, comando=None, tipo="primario", **kw):
    estilos = {
        "primario": dict(fg_color=ACENTO, hover_color=ACENTO_HOVER, text_color=("#ffffff", "#ffffff")),
        "secundario": dict(fg_color="transparent", hover_color=TARJETA_2, text_color=TINTA,
                           border_width=1, border_color=LINEA),
        "fantasma": dict(fg_color="transparent", hover_color=TARJETA_2, text_color=TINTA),
        "peligro": dict(fg_color="transparent", hover_color=TARJETA_2, text_color=PELIGRO,
                        border_width=1, border_color=LINEA),
        "pendiente": dict(fg_color=PENDIENTE, hover_color=TINTA_2, text_color=("#ffffff", "#1c1a17")),
    }
    opciones = dict(height=34, font=fuente(13, "bold" if tipo == "primario" else "normal"))
    opciones.update(estilos[tipo])
    opciones.update(kw)
    return ctk.CTkButton(padre, text=texto, command=comando, **opciones)
