"""Fotos de uso libre de Wikimedia Commons (con autor y licencia para citarlas)."""
import re
import html

import requests

from .datos import normalizar

API = "https://commons.wikimedia.org/w/api.php"
MIMES = {"image/jpeg", "image/png", "image/webp"}
# Palabras que suelen indicar que no es una foto del pueblo (mapas, escudos, planos...)
DESCARTAR = re.compile(r"(mapa|map|location|localizaci|escudo|coat of arms|bandera|flag|logo|plano|"
                       r"\.svg|diagram|esquema|firma|signature)", re.I)
# Para ordenar: lo que suele mostrar bien el conjunto, y lo que no (detalles, interiores…)
BUENAS = re.compile(r"(panor|vista|general|skyline|a[eé]rea|aerial|casco|plaza|iglesia|ermita|puente|"
                    r"r[ií]o|calle|pueblo|village|town|monaster|castillo|palacio|conjunto|atardecer|"
                    r"amanecer|paisaj|desde)", re.I)
MALAS = re.compile(r"(interior|detalle|detail|inscripci|placa|l[aá]pida|tumba|cementerio|sepul|museo|"
                   r"documento|retrato|close.?up|primer plano|r[oó]tulo|se[nñ]al)", re.I)


def _limpiar(texto: str) -> str:
    texto = re.sub(r"<[^>]+>", "", texto or "")
    return re.sub(r"\s+", " ", html.unescape(texto)).strip()


def _puntos(it: dict, n: str) -> float:
    """Puntúa una foto para que las que mejor muestran el lugar salgan primero."""
    campos = f"{it.get('titulo', '')} {it.get('descripcion', '')}"
    t = normalizar(campos)
    s = 0.0
    a, al = it.get("ancho") or 0, it.get("alto") or 0
    if a and al:
        s += min(a * al, 8_000_000) / 2_000_000      # resolución (hasta ~4 puntos)
        if a > al * 1.1:
            s += 1.3                                   # apaisada: suele ser una vista del pueblo
    if n and n in t:
        s += 2.0                                       # el nombre del pueblo en el título/descr.
    if BUENAS.search(campos):
        s += 1.6
    if MALAS.search(campos):
        s -= 2.6
    if it.get("origen") == "Wikimedia Commons":
        s += 0.3
    return s


class Commons:
    def __init__(self, user_agent: str):
        self.sesion = requests.Session()
        self.sesion.headers.update({"User-Agent": user_agent})

    def _consulta(self, **params) -> list:
        params.update({"action": "query", "format": "json", "prop": "imageinfo",
                       "iiprop": "url|extmetadata|mime|size", "iiurlwidth": 320,
                       "iiextmetadatafilter": "Artist|LicenseShortName|LicenseUrl|ImageDescription|ObjectName"})
        r = self.sesion.get(API, params=params, timeout=25)
        r.raise_for_status()
        paginas = r.json().get("query", {}).get("pages", {})
        res = []
        for pg in sorted(paginas.values(), key=lambda x: x.get("index", 0)):
            info = (pg.get("imageinfo") or [{}])[0]
            if info.get("mime") not in MIMES or not info.get("thumburl"):
                continue
            if (info.get("width") or 0) < 800:
                continue
            titulo = pg.get("title", "")
            if DESCARTAR.search(titulo):
                continue
            meta = info.get("extmetadata", {})
            val = lambda k: _limpiar(meta.get(k, {}).get("value", ""))  # noqa: E731
            res.append({
                "titulo": titulo,
                "ancho": info.get("width") or 0,
                "alto": info.get("height") or 0,
                "miniatura": info["thumburl"],
                "descarga": ("https://commons.wikimedia.org/wiki/Special:FilePath/"
                             + requests.utils.quote(titulo.split(":", 1)[-1].replace(" ", "_")) + "?width=1600"),
                "pagina": info.get("descriptionurl", ""),
                "autor": val("Artist")[:120] or "Autor desconocido",
                "licencia": val("LicenseShortName") or "Licencia libre",
                "url_licencia": meta.get("LicenseUrl", {}).get("value", ""),
                "descripcion": (val("ObjectName") or val("ImageDescription"))[:200],
                "origen": "Wikimedia Commons",
            })
        return res

    def _fotos_articulo(self, titulo_wiki: str) -> list:
        """Las imágenes que usa el artículo del pueblo en la Wikipedia en español (suelen ser las mejores:
        la del encabezado, panorámicas…). Se piden luego a Commons para tener autor y licencia."""
        try:
            r = self.sesion.get("https://es.wikipedia.org/w/api.php",
                                params={"action": "query", "prop": "images", "titles": titulo_wiki,
                                        "imlimit": 80, "format": "json"}, timeout=20)
            r.raise_for_status()
            ficheros = []
            for pg in r.json().get("query", {}).get("pages", {}).values():
                for im in pg.get("images", []):
                    tl = (im.get("title", "") or "").replace("Archivo:", "File:")
                    if tl.startswith("File:") and not DESCARTAR.search(tl):
                        ficheros.append(tl)
        except (requests.RequestException, ValueError):
            return []
        res = []
        for i in range(0, len(ficheros), 40):
            try:
                res += self._consulta(titles="|".join(ficheros[i:i + 40]))
            except requests.RequestException:
                pass
        for it in res:
            it["_boost"] = 3.0       # las del artículo, arriba del todo
        return res

    def buscar(self, nombre: str, provincia: str = "", lat=None, lon=None, limite: int = 60,
               categoria: str = "", titulo_wiki: str = "", mas_fuentes: bool = True) -> list:
        """Fotos del artículo de Wikipedia, de la categoría del pueblo en Commons (y sus subcategorías),
        cerca de la coordenada y por nombre; después, fotos CC de Flickr y otros sitios (Openverse).
        Sin repetir y ordenadas para que las que mejor muestran el lugar salgan primero."""
        vistos, res, errores = set(), [], []

        def sumar(items, clave="titulo"):
            for item in items:
                if item.get(clave) and item[clave] not in vistos:
                    vistos.add(item[clave])
                    res.append(item)

        if titulo_wiki:
            try:
                sumar(self._fotos_articulo(titulo_wiki))
            except requests.RequestException as e:
                errores.append(e)
        consultas = []
        if categoria:
            consultas.append(dict(generator="categorymembers", gcmtitle=f"Category:{categoria}", gcmtype="file",
                                  gcmlimit=limite))
            consultas.append(dict(generator="search", gsrsearch=f'deepcat:"{categoria}"',   # con subcategorías
                                  gsrnamespace=6, gsrlimit=limite))
        if lat is not None and lon is not None:
            consultas.append(dict(generator="geosearch", ggscoord=f"{lat}|{lon}", ggsradius=4000,
                                  ggsnamespace=6, ggslimit=limite))
        consultas.append(dict(generator="search", gsrsearch=f'"{nombre}" {provincia} filetype:bitmap'.strip(),
                              gsrnamespace=6, gsrlimit=limite))
        for c in consultas:
            try:
                sumar(self._consulta(**c))
            except requests.RequestException as e:
                errores.append(e)
        if mas_fuentes:
            from .fuentes import openverse
            try:
                sumar(openverse(self.sesion, nombre, provincia, limite=40), clave="pagina")
            except (requests.RequestException, ValueError) as e:
                errores.append(e)
        if not res and errores:
            raise errores[0]
        n = normalizar(nombre)
        res.sort(key=lambda it: -(it.get("_boost", 0) + _puntos(it, n)))
        return res

    def miniatura(self, url: str) -> bytes:
        r = self.sesion.get(url, timeout=25)
        r.raise_for_status()
        return r.content

    def descargar(self, item: dict, destino) -> None:
        r = self.sesion.get(item["descarga"], timeout=60)
        r.raise_for_status()
        with open(destino, "wb") as f:
            f.write(r.content)
