"""Fotos de uso libre de Wikimedia Commons (con autor y licencia para citarlas)."""
import re
import html

import requests

API = "https://commons.wikimedia.org/w/api.php"
MIMES = {"image/jpeg", "image/png", "image/webp"}
# Palabras que suelen indicar que no es una foto del pueblo (mapas, escudos, planos...)
DESCARTAR = re.compile(r"(mapa|map|location|localizaci|escudo|coat of arms|bandera|flag|logo|plano|"
                       r"\.svg|diagram|esquema|firma|signature)", re.I)


def _limpiar(texto: str) -> str:
    texto = re.sub(r"<[^>]+>", "", texto or "")
    return re.sub(r"\s+", " ", html.unescape(texto)).strip()


class Commons:
    def __init__(self, user_agent: str):
        self.sesion = requests.Session()
        self.sesion.headers.update({"User-Agent": user_agent})

    def _consulta(self, **params) -> list:
        params.update({"action": "query", "format": "json", "prop": "imageinfo",
                       "iiprop": "url|extmetadata|mime|size", "iiurlwidth": 320,
                       "iiextmetadatafilter": "Artist|LicenseShortName|LicenseUrl|ImageDescription|ObjectName"})
        r = self.sesion.get(API, params=params, timeout=25)
        r.raise_for_status()
        paginas = r.json().get("query", {}).get("pages", {})
        res = []
        for pg in sorted(paginas.values(), key=lambda x: x.get("index", 0)):
            info = (pg.get("imageinfo") or [{}])[0]
            if info.get("mime") not in MIMES or not info.get("thumburl"):
                continue
            if (info.get("width") or 0) < 800:
                continue
            titulo = pg.get("title", "")
            if DESCARTAR.search(titulo):
                continue
            meta = info.get("extmetadata", {})
            val = lambda k: _limpiar(meta.get(k, {}).get("value", ""))  # noqa: E731
            res.append({
                "titulo": titulo,
                "miniatura": info["thumburl"],
                "descarga": ("https://commons.wikimedia.org/wiki/Special:FilePath/"
                             + requests.utils.quote(titulo.split(":", 1)[-1].replace(" ", "_")) + "?width=1600"),
                "pagina": info.get("descriptionurl", ""),
                "autor": val("Artist")[:120] or "Autor desconocido",
                "licencia": val("LicenseShortName") or "Licencia libre",
                "url_licencia": meta.get("LicenseUrl", {}).get("value", ""),
                "descripcion": (val("ObjectName") or val("ImageDescription"))[:200],
            })
        return res

    def buscar(self, nombre: str, provincia: str = "", lat=None, lon=None, limite: int = 40) -> list:
        """Fotos cerca de la coordenada y por nombre, sin repetir."""
        vistos, res = set(), []
        consultas = []
        if lat is not None and lon is not None:
            consultas.append(dict(generator="geosearch", ggscoord=f"{lat}|{lon}", ggsradius=2000,
                                  ggsnamespace=6, ggslimit=limite))
        consultas.append(dict(generator="search", gsrsearch=f'"{nombre}" {provincia} filetype:bitmap'.strip(),
                              gsrnamespace=6, gsrlimit=limite))
        errores = []
        for c in consultas:
            try:
                for item in self._consulta(**c):
                    if item["titulo"] not in vistos:
                        vistos.add(item["titulo"])
                        res.append(item)
            except requests.RequestException as e:
                errores.append(e)
        if not res and errores:
            raise errores[0]
        return res

    def miniatura(self, url: str) -> bytes:
        r = self.sesion.get(url, timeout=25)
        r.raise_for_status()
        return r.content

    def descargar(self, item: dict, destino) -> None:
        r = self.sesion.get(item["descarga"], timeout=60)
        r.raise_for_status()
        with open(destino, "wb") as f:
            f.write(r.content)
