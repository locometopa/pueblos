"""Texto del pueblo escrito con IA. Varios proveedores: Claude, ChatGPT, Gemini u otra compatible.

Cada uno necesita su clave (se guarda solo en config.json, en este ordenador).
"""
import requests


class ErrorIA(Exception):
    pass


# clave: (nombre, modelo por defecto, dónde conseguir la clave, ayuda)
PROVEEDORES = {
    "claude": ("Claude (Anthropic)", "claude-haiku-5-5", "https://console.anthropic.com/settings/keys",
               "De pago por uso; muy buena en castellano."),
    "chatgpt": ("ChatGPT (OpenAI)", "gpt-5.4-mini", "https://platform.openai.com/api-keys",
                "De pago por uso (la suscripción de ChatGPT Plus no incluye la API)."),
    "gemini": ("Gemini (Google)", "gemini-3.6-flash", "https://aistudio.google.com/apikey",
               "Tiene uso gratuito con límites: buena opción para empezar."),
    "compatible": ("Otra (compatible con OpenAI)", "", "",
                   "DeepSeek, Mistral, Groq, OpenRouter, Ollama en tu PC… Pon su dirección y su modelo."),
}

# nombres de los campos en config.json (la clave de Claude conserva el nombre antiguo)
CAMPO_CLAVE = {"claude": "api_key", "chatgpt": "clave_chatgpt", "gemini": "clave_gemini", "compatible": "clave_compatible"}
CAMPO_MODELO = {"claude": "modelo_ia", "chatgpt": "modelo_chatgpt", "gemini": "modelo_gemini",
                "compatible": "modelo_compatible"}


def proveedor(cfg) -> str:
    p = cfg.get("ia_proveedor") or "claude"
    return p if p in PROVEEDORES else "claude"


def ajustes(cfg, prov=None):
    prov = prov or proveedor(cfg)
    clave = (cfg.get(CAMPO_CLAVE[prov]) or "").strip()
    modelo = (cfg.get(CAMPO_MODELO[prov]) or "").strip() or PROVEEDORES[prov][1]
    url = (cfg.get("url_compatible") or "").strip().rstrip("/")
    return prov, clave, modelo, url


def configurada(cfg) -> bool:
    prov, clave, modelo, url = ajustes(cfg)
    if prov == "compatible":
        return bool(url and modelo)       # Ollama en local no necesita clave
    return bool(clave)


def nombre(cfg) -> str:
    return PROVEEDORES[proveedor(cfg)][0].split(" (")[0]


# ---------------------------------------------------------------------------- petición
def _error(r, quien):
    if r.status_code in (401, 403):
        return ErrorIA(f"{quien}: la clave no es válida o no tiene permiso.")
    if r.status_code == 429:
        return ErrorIA(f"{quien}: has llegado al límite de uso o no tienes saldo. Prueba más tarde u otra IA.")
    try:
        j = r.json()
        err = j.get("error")
        msg = (err.get("message") if isinstance(err, dict) else err) or r.text
    except ValueError:
        msg = r.text
    return ErrorIA(f"{quien} ({r.status_code}): {str(msg)[:300]}")


def preguntar(cfg, prompt: str, max_tokens: int = 1200, prov=None) -> str:
    prov, clave, modelo, url = ajustes(cfg, prov)
    quien = PROVEEDORES[prov][0]
    if prov != "compatible" and not clave:
        raise ErrorIA(f"Falta la clave de {quien}. Ponla en Ajustes.")
    try:
        if prov == "claude":
            r = requests.post("https://api.anthropic.com/v1/messages", timeout=90, headers={
                "x-api-key": clave, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={"model": modelo, "max_tokens": max_tokens, "messages": [{"role": "user", "content": prompt}]})
            if r.status_code >= 400:
                raise _error(r, quien)
            return "\n".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text").strip()

        if prov == "gemini":
            r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent",
                              timeout=90, headers={"x-goog-api-key": clave, "content-type": "application/json"},
                              json={"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                                    "generationConfig": {"maxOutputTokens": max_tokens * 3}})
            if r.status_code >= 400:
                raise _error(r, quien)
            cand = (r.json().get("candidates") or [{}])[0]
            texto = "".join(p.get("text", "") for p in (cand.get("content") or {}).get("parts", []) if not p.get("thought"))
            if not texto.strip():
                raise ErrorIA(f"{quien} no ha devuelto texto ({cand.get('finishReason', 'sin motivo')}).")
            return texto.strip()

        # ChatGPT y compatibles (misma forma de pedir)
        base = "https://api.openai.com/v1" if prov == "chatgpt" else url
        if not base:
            raise ErrorIA("Falta la dirección de la IA compatible (por ejemplo https://api.deepseek.com/v1).")
        cab = {"content-type": "application/json"}
        if clave:
            cab["authorization"] = f"Bearer {clave}"
        cuerpo = {"model": modelo, "messages": [{"role": "user", "content": prompt}]}
        cuerpo["max_completion_tokens" if prov == "chatgpt" else "max_tokens"] = max_tokens * (4 if prov == "chatgpt" else 1)
        r = requests.post(f"{base}/chat/completions", timeout=120, headers=cab, json=cuerpo)
        if r.status_code >= 400:
            raise _error(r, quien)
        texto = ((r.json().get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        if not texto.strip():
            raise ErrorIA(f"{quien} no ha devuelto texto.")
        return texto.strip()
    except requests.RequestException as e:
        raise ErrorIA(f"No se pudo conectar con {quien}: {e}") from e


def probar(cfg, prov=None) -> str:
    texto = preguntar(cfg, "Responde solo con la palabra: funciona", max_tokens=20, prov=prov)
    return f"{PROVEEDORES[ajustes(cfg, prov)[0]][0]} responde: «{texto[:60]}». Todo correcto."


def modelos(cfg, prov=None) -> list:
    """Modelos disponibles con esa clave (para elegir sin tener que saberse los nombres)."""
    prov, clave, _, url = ajustes(cfg, prov)
    try:
        if prov == "claude":
            r = requests.get("https://api.anthropic.com/v1/models?limit=100", timeout=30,
                             headers={"x-api-key": clave, "anthropic-version": "2023-06-01"})
            ids = [m["id"] for m in r.json().get("data", [])] if r.ok else []
        elif prov == "gemini":
            r = requests.get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", timeout=30,
                             headers={"x-goog-api-key": clave})
            ids = [m["name"].split("/", 1)[1] for m in r.json().get("models", [])
                   if "generateContent" in m.get("supportedGenerationMethods", [])] if r.ok else []
        else:
            base = "https://api.openai.com/v1" if prov == "chatgpt" else url
            r = requests.get(f"{base}/models", timeout=30, headers={"authorization": f"Bearer {clave}"} if clave else {})
            ids = [m["id"] for m in r.json().get("data", [])] if r.ok else []
            if prov == "chatgpt":
                ids = [i for i in ids if i.startswith(("gpt", "o")) and not any(
                    x in i for x in ("audio", "realtime", "tts", "transcribe", "image", "embedding", "search"))]
    except (requests.RequestException, ValueError, KeyError) as e:
        raise ErrorIA(f"No he podido pedir la lista de modelos: {e}") from e
    if not r.ok:
        raise _error(r, PROVEEDORES[prov][0])
    return sorted(set(ids), reverse=True)


# ---------------------------------------------------------------------------- textos
def _contexto(p: dict) -> str:
    wiki = p.get("wiki") or {}
    datos = []
    for clave, etiqueta in (("poblacion", "Población"), ("altitud", "Altitud (m)"),
                            ("superficie", "Superficie (km²)"), ("gentilicio", "Gentilicio"), ("patron", "Patrón")):
        if wiki.get(clave):
            datos.append(f"{etiqueta}: {wiki[clave]}")
    secciones = "\n\n".join(f"{s.get('titulo')}: {s.get('texto', '')[:1500]}" for s in (wiki.get("secciones") or [])[:4])
    que_ver = ", ".join(l.get("nombre", "") for l in (wiki.get("que_ver") or [])[:12])
    return f"""Pueblo: {p.get('nombre')}
Provincia: {p.get('provincia')} · Comunidad: {p.get('comunidad')}
{chr(10).join(datos)}
Fechas de visita: {", ".join(p.get("fechas_visita") or []) or "sin fecha"}

Información de Wikipedia (úsala como base de hechos):
{wiki.get("extracto") or "(no hay texto de Wikipedia)"}
{secciones}
{("Lugares de interés: " + que_ver) if que_ver else ""}

Notas personales del viajero (si las hay, puedes inspirarte en el tono, pero no las copies):
{p.get('notas') or '(sin notas)'}"""


def generar_texto(cfg, p: dict) -> str:
    prompt = f"""Escribe en castellano un texto breve para la web personal de un viajero que recopila los pueblos que ha visitado.

{_contexto(p)}

Instrucciones:
- 2 o 3 párrafos, unas 180-250 palabras en total.
- Tono cercano y evocador, de cuaderno de viaje, sin exagerar.
- No inventes datos: si algo no está en la información de arriba, no lo afirmes.
- Sin título, sin listas, sin markdown. Separa los párrafos con una línea en blanco."""
    return preguntar(cfg, prompt)
