"""Texto del pueblo escrito con IA (API de Anthropic). Opcional: hace falta una clave."""
import requests

API = "https://api.anthropic.com/v1/messages"


class ErrorIA(Exception):
    pass


def generar_texto(api_key: str, modelo: str, p: dict) -> str:
    if not api_key:
        raise ErrorIA("Falta la clave de la API. Ponla en Configuración.")
    wiki = p.get("wiki") or {}
    fuente = wiki.get("extracto") or "(no hay texto de Wikipedia)"
    datos = []
    for clave, etiqueta in (("poblacion", "Población"), ("altitud", "Altitud (m)"),
                            ("superficie", "Superficie (km²)")):
        if wiki.get(clave):
            datos.append(f"{etiqueta}: {wiki[clave]}")
    visitas = ", ".join(p.get("fechas_visita") or []) or "sin fecha"

    prompt = f"""Escribe en castellano un texto breve para la web personal de un viajero que recopila los pueblos que ha visitado.

Pueblo: {p.get('nombre')}
Provincia: {p.get('provincia')} · Comunidad: {p.get('comunidad')}
{chr(10).join(datos)}
Fechas de visita: {visitas}

Información de Wikipedia (úsala como base de hechos):
{fuente}

Notas personales del viajero (si las hay, puedes inspirarte en el tono, pero no las copies):
{p.get('notas') or '(sin notas)'}

Instrucciones:
- 2 o 3 párrafos, unas 180-250 palabras en total.
- Tono cercano y evocador, de cuaderno de viaje, sin exagerar.
- No inventes datos: si algo no está en la información de arriba, no lo afirmes.
- Sin título, sin listas, sin markdown. Separa los párrafos con una línea en blanco."""

    try:
        r = requests.post(API, timeout=90, headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }, json={
            "model": modelo,
            "max_tokens": 1200,
            "messages": [{"role": "user", "content": prompt}],
        })
    except requests.RequestException as e:
        raise ErrorIA(f"No se pudo conectar con la API: {e}") from e
    if r.status_code == 401:
        raise ErrorIA("La clave de la API no es válida.")
    if r.status_code >= 400:
        try:
            msg = r.json().get("error", {}).get("message", r.text)
        except ValueError:
            msg = r.text
        raise ErrorIA(f"Error de la API ({r.status_code}): {msg}")
    partes = [b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text"]
    return "\n".join(partes).strip()
