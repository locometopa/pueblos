"""Más fuentes de información y de fotos, además de Wikipedia y Wikimedia Commons.

  · Web oficial del ayuntamiento (la de Wikidata o, si no hay, se prueba la dirección habitual): título y descripción.
  · Wikivoyage: guía de viaje (qué ver, qué hacer, dónde comer, dónde dormir…). CC BY-SA.
  · Wikidata: distinciones (Conjunto Histórico, «Los Pueblos más Bonitos de España»…) y categoría de Commons.
  · OpenStreetMap: lugares de interés cercanos cuando Wikidata se queda corto. ODbL.
  · Openverse: fotos con licencia Creative Commons de Flickr y otros sitios, con su autor y licencia.
"""
import html
import re
from urllib.parse import quote, urljoin

import requests

from .datos import normalizar, slugify

WIKIVOYAGE = "https://es.wikivoyage.org/w/api.php"
OVERPASS = "https://overpass-api.de/api/interpreter"
OPENVERSE = "https://api.openverse.org/v1/images/"
WIKIDATA_API = "https://www.wikidata.org/w/api.php"


def _texto(t: str) -> str:
    t = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", t or "", flags=re.S | re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    return re.sub(r"\s+", " ", html.unescape(t)).strip()


# ---------------------------------------------------------------------------- web oficial
def _meta(pagina: str, *nombres) -> str:
    for n in nombres:
        for patron in (rf'<meta[^>]+(?:name|property)=["\']{n}["\'][^>]*content=["\']([^"\']*)',
                       rf'<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:name|property)=["\']{n}["\']'):
            m = re.search(patron, pagina, re.I)
            if m and m.group(1).strip():
                return _texto(m.group(1))
    return ""


def _leer_web(sesion, url: str, timeout=12):
    r = sesion.get(url, timeout=timeout, allow_redirects=True)
    if r.status_code >= 400 or "html" not in r.headers.get("content-type", "html"):
        return None, None
    if not r.encoding or r.encoding.lower() == "iso-8859-1":
        r.encoding = r.apparent_encoding or "utf-8"
    return r.url, r.text[:400000]


def _resumen_web(url_final: str, pagina: str) -> dict:
    titulo = _meta(pagina, "og:site_name", "og:title")
    if not titulo:
        m = re.search(r"<title[^>]*>(.*?)</title>", pagina, re.I | re.S)
        titulo = _texto(m.group(1)) if m else ""
    desc = _meta(pagina, "description", "og:description", "twitter:description")
    if len(desc) < 60:   # sin descripción: el primer párrafo con sustancia
        for p in re.findall(r"<p[^>]*>(.*?)</p>", pagina, re.I | re.S):
            t = _texto(p)
            if len(t) >= 120 and not re.search(r"cookie|javascript|navegador|aviso legal|©", t, re.I):
                desc = t
                break
    if len(desc) > 420:
        desc = desc[:desc.rfind(" ", 0, 410)] + "…"
    return {"url": url_final, "titulo": titulo[:120], "descripcion": desc}


PALABRAS_OFICIAL = ("ayuntamiento", "ayto", "concello", "ajuntament", "udala", "municipio", "concejo", "villa",
                    "turismo", "oficial", "sede electronica", "consistorio")


def web_oficial(sesion, nombre: str, url: str = "") -> dict:
    """Título y descripción de la web oficial. Si Wikidata no la da, prueba las direcciones habituales."""
    if url:
        try:
            final, pagina = _leer_web(sesion, url)
            if pagina:
                return _resumen_web(final, pagina)
        except requests.RequestException:
            pass
        return {"url": url, "titulo": "", "descripcion": ""}
    s = slugify(nombre).replace("-", "")
    candidatos = [f"https://www.{s}.es", f"https://{s}.es", f"https://www.ayto{s}.es", f"https://www.aytode{s}.es",
                  f"https://www.ayuntamientode{s}.es", f"https://www.concellode{s}.gal", f"https://www.{s}.org",
                  f"https://www.ajuntament{s}.cat", f"https://www.{s}.cat"]
    nombre_n = normalizar(nombre)
    for c in candidatos:
        try:
            final, pagina = _leer_web(sesion, c, timeout=6)
        except requests.RequestException:
            continue
        if not pagina:
            continue
        cab = normalizar(_meta(pagina, "og:site_name", "og:title") + " " + (
            re.search(r"<title[^>]*>(.*?)</title>", pagina, re.I | re.S) or [None, ""])[1])
        if nombre_n in cab and any(p in cab for p in PALABRAS_OFICIAL):
            d = _resumen_web(final, pagina)
            d["adivinada"] = True
            return d
    return {}


# ---------------------------------------------------------------------------- Wikivoyage
APARTADOS_GUIA = [
    ("entender", ("entender", "comprender", "historia")), ("llegar", ("llegar", "como llegar")),
    ("ver", ("ver", "que ver", "lugares de interes")), ("hacer", ("hacer", "que hacer", "actividades")),
    ("comprar", ("comprar",)), ("comer", ("comer", "gastronomia", "donde comer")), ("beber", ("beber", "salir")),
    ("dormir", ("dormir", "alojamiento", "donde dormir")), ("alrededores", ("alrededores", "excursiones", "cerca")),
]


def _partir_guia(texto: str) -> list:
    res, actual = {}, None
    for linea in (texto or "").splitlines():
        m = re.match(r"^(={2,6})\s*(.*?)\s*\1\s*$", linea.strip())
        if m:
            if len(m.group(1)) == 2:
                t = normalizar(m.group(2))
                actual = next((k for k, ps in APARTADOS_GUIA if any(t == p or t.startswith(p) for p in ps)), None)
                if actual and actual not in res:
                    res[actual] = {"clave": actual, "titulo": m.group(2), "texto": []}
            elif actual:
                res[actual]["texto"].append(f"\n▸ {m.group(2)}")
            continue
        if actual:
            res[actual]["texto"].append(linea)
    salida = []
    for k, _ in APARTADOS_GUIA:
        if k in res:
            t = re.sub(r"\n{3,}", "\n\n", "\n".join(res[k]["texto"])).strip()
            if len(t) > 1400:
                corte = t.rfind("\n", 0, 1400)
                t = t[:corte if corte > 600 else 1400].rstrip() + " …"
            if len(t) > 60:
                salida.append({"clave": k, "titulo": res[k]["titulo"], "texto": t})
    return salida


def wikivoyage(sesion, nombre: str, provincia: str = "", lat=None, lon=None) -> dict:
    """Guía de viaje del pueblo en Wikivoyage (si existe)."""
    titulos = [nombre]
    if provincia:
        titulos.append(f"{nombre} ({provincia})")
    if lat is not None and lon is not None:
        try:
            js = sesion.get(WIKIVOYAGE, params={"action": "query", "list": "geosearch", "gscoord": f"{lat}|{lon}",
                                                "gsradius": 3000, "gslimit": 5, "format": "json"}, timeout=15).json()
            titulos += [g["title"] for g in js.get("query", {}).get("geosearch", [])
                        if normalizar(nombre) in normalizar(g["title"])]
        except (requests.RequestException, ValueError):
            pass
    vistos = set()
    for t in titulos:
        if t in vistos:
            continue
        vistos.add(t)
        js = sesion.get(WIKIVOYAGE, params={"action": "query", "prop": "extracts", "titles": t, "explaintext": 1,
                                            "exsectionformat": "wiki", "redirects": 1, "format": "json"}, timeout=20).json()
        pagina = next(iter(js.get("query", {}).get("pages", {}).values()), {})
        texto = pagina.get("extract") or ""
        if not texto or "missing" in pagina:
            continue
        if provincia and normalizar(provincia) not in normalizar(texto[:4000]) and t == nombre and lat is None:
            continue           # puede ser otro sitio con el mismo nombre
        secciones = _partir_guia(texto)
        if secciones:
            titulo = pagina.get("title", t)
            return {"titulo": titulo, "url": f"https://es.wikivoyage.org/wiki/{quote(titulo.replace(' ', '_'))}",
                    "secciones": secciones}
    return {}


# ---------------------------------------------------------------------------- Wikidata: distinciones
def distinciones(sesion, qid: str) -> dict:
    """Patrimonio (P1435), pertenencias (P463: p. ej. Los Pueblos más Bonitos de España) y categoría de Commons."""
    js = sesion.get(WIKIDATA_API, params={"action": "wbgetentities", "ids": qid, "props": "claims", "format": "json"},
                    timeout=25).json()
    claims = js.get("entities", {}).get(qid, {}).get("claims", {})
    val = lambda c: (c.get("mainsnak", {}).get("datavalue") or {}).get("value")  # noqa: E731
    ids = [val(c)["id"] for p in ("P1435", "P463") for c in claims.get(p, []) if isinstance(val(c), dict) and val(c).get("id")]
    res = {}
    cat = next((val(c) for c in claims.get("P373", []) if isinstance(val(c), str)), "")
    if cat:
        res["commons_cat"] = cat
    if ids:
        et = sesion.get(WIKIDATA_API, params={"action": "wbgetentities", "ids": "|".join(ids[:12]), "props": "labels",
                                              "languages": "es|en", "format": "json"}, timeout=25).json()
        nombres = []
        for i in ids[:12]:
            lab = et.get("entities", {}).get(i, {}).get("labels", {})
            n = (lab.get("es") or lab.get("en") or {}).get("value", "")
            if n and not re.search(r"(mancomunidad|comarca administrativa|federaci[oó]n española de municipios|"
                                    r"partido judicial)", n, re.I):
                nombres.append(n[:1].upper() + n[1:])
        if nombres:
            res["distinciones"] = list(dict.fromkeys(nombres))
    return res


# ---------------------------------------------------------------------------- OpenStreetMap
def osm_lugares(sesion, lat, lon, radio=2500, maximo=15) -> list:
    consulta = f"""[out:json][timeout:25];
(
  nwr(around:{radio},{lat},{lon})["tourism"~"^(attraction|museum|viewpoint|artwork|gallery)$"]["name"];
  nwr(around:{radio},{lat},{lon})["historic"~"^(castle|monument|church|ruins|archaeological_site|fort|tower|city_gate|bridge|monastery|palace|manor)$"]["name"];
);
out center tags 60;"""
    r = sesion.post(OVERPASS, data={"data": consulta}, timeout=40)
    r.raise_for_status()
    res, vistos = [], set()
    for el in r.json().get("elements", []):
        t = el.get("tags", {})
        nombre = t.get("name:es") or t.get("name")
        if not nombre or normalizar(nombre) in vistos:
            continue
        vistos.add(normalizar(nombre))
        la = el.get("lat") or (el.get("center") or {}).get("lat")
        lo = el.get("lon") or (el.get("center") or {}).get("lon")
        url = f"https://www.openstreetmap.org/{el['type']}/{el['id']}"
        if t.get("wikipedia", "").startswith("es:"):
            url = "https://es.wikipedia.org/wiki/" + quote(t["wikipedia"][3:].replace(" ", "_"))
        elif t.get("wikidata"):
            url = f"https://www.wikidata.org/wiki/{t['wikidata']}"
        lugar = {"nombre": nombre, "url": url, "fuente": "OpenStreetMap"}
        if la is not None:
            lugar["lat"], lugar["lon"] = round(la, 6), round(lo, 6)
        peso = 0 if "wikipedia" in url else 1 if "wikidata" in url else 2
        res.append((peso, lugar))
    res.sort(key=lambda x: x[0])
    return [l for _, l in res[:maximo]]


def juntar_lugares(propios: list, nuevos: list, maximo=16) -> list:
    nombres = {normalizar(l.get("nombre")) for l in propios}
    salida = list(propios)
    for l in nuevos:
        if len(salida) >= maximo:
            break
        if normalizar(l["nombre"]) not in nombres:
            salida.append(l)
            nombres.add(normalizar(l["nombre"]))
    return salida


# ---------------------------------------------------------------------------- Openverse (fotos CC de Flickr y otros)
def openverse(sesion, nombre: str, provincia: str = "", limite=30) -> list:
    r = sesion.get(OPENVERSE, params={"q": f"{nombre} {provincia}".strip(), "page_size": limite,
                                      "license": "by,by-sa,cc0,pdm,by-nc,by-nc-sa", "category": "photograph",
                                      "mature": "false"}, timeout=25)
    r.raise_for_status()
    res = []
    n = normalizar(nombre)
    for it in r.json().get("results", []):
        if (it.get("width") or 0) and it["width"] < 800:
            continue
        texto = normalizar(" ".join([it.get("title") or ""] + [t.get("name", "") for t in it.get("tags") or []]))
        if n not in texto:
            continue
        lic = (it.get("license") or "").upper()
        lic = "Dominio público" if lic in ("PDM", "CC0") else f"CC {lic} {it.get('license_version') or ''}".strip()
        origen = (it.get("source") or it.get("provider") or "Openverse").replace("_", " ").title()
        res.append({
            "titulo": f"openverse:{it['id']}", "miniatura": it.get("thumbnail") or it.get("url"),
            "descarga": it.get("url"), "pagina": it.get("foreign_landing_url") or it.get("url"),
            "autor": (it.get("creator") or "Autor desconocido")[:120], "licencia": lic,
            "url_licencia": it.get("license_url") or "", "descripcion": (it.get("title") or "")[:200],
            "origen": origen,
        })
    return res
