@echo off
chcp 65001 >nul
echo === Creando PUEBLOS.exe (tarda un par de minutos) ===
py -m pip install pyinstaller
py -m PyInstaller --noconfirm --onefile --windowed --name PUEBLOS --collect-all customtkinter --collect-all pillow_heif --add-data "%~dp0nucleo;nucleo" "%~dp0pueblos.py"
if exist "%~dp0dist\PUEBLOS.exe" copy /y "%~dp0dist\PUEBLOS.exe" "%~dp0PUEBLOS.exe" >nul
echo.
echo Listo: PUEBLOS.exe esta en esta carpeta (junto a config.json y repo).
pause
