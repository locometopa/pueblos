# PUEBLOS 0.6 — la web de tus pueblos visitados

Programa de Windows para guardar los pueblos que has visitado (y los que quieres visitar)
y publicarlos como una web gratuita en GitHub Pages: `https://locometopa.github.io/pueblos/`

## Novedades de la 0.6

- **🎨 Diseño** (nuevo apartado del menú): cabecera (dibujo, foto grande, collage o sencilla), paleta de colores,
  modo claro/oscuro/automático, tipografía, fondo de azulejos y bandas, mostrar u ocultar mapa y secciones,
  orden mapa/pueblos y **tu logo** (también como icono de la pestaña).
- **Vista previa en vivo**: pulsa «Vista previa en vivo» y deja el navegador abierto; cada cambio de diseño se ve solo en un segundo.
- **Token de GitHub en Ajustes** (opcional): publicar sin iniciar sesión y ver abajo si la web se ha publicado bien (🟡 / ✅ / ❌).
  Créalo en GitHub → *Settings → Developer settings → Fine-grained tokens*, solo para el repositorio `pueblos`,
  permiso **Contents: Read and write**. Se guarda solo en tu ordenador.
- **Actualizaciones automáticas**: al sincronizar, si hay una versión nueva en GitHub el programa te lo pregunta,
  se actualiza solo y se reinicia. Tus pueblos, fotos y configuración no se tocan.

## Novedades de la 0.5

- **Cabecera ilustrada** en la página principal: un pueblo dibujado al atardecer
  (y de noche, con luna, estrellas y ventanas encendidas, en modo oscuro).
- **Más información de cada pueblo**, recopilada de internet al traer Wikipedia:
  historia, patrimonio, fiestas, gastronomía, leyendas y curiosidades, naturaleza, personajes;
  **«Qué ver»** con monumentos y lugares de interés (con foto libre y su autor); gentilicio y patrón.
  Para los pueblos que ya tenías: **Ajustes → Completar la información de todos los pueblos**.

## Novedades de la 0.4

- **Panel de gestión en la web**, para el móvil: `https://locometopa.github.io/pueblos/gestion/`.
  Sube fotos desde la galería (lee el GPS, detecta el pueblo y les quita la ubicación antes de subirlas),
  crea pueblos, trae Wikipedia, pon fotos de internet, edita, marca visitado / por visitar.
- **Tus datos viven en GitHub**: el programa y el panel trabajan sobre lo mismo. Al abrir el
  programa se traen los cambios del móvil; «Publicar» sube los tuyos. Si tocas el mismo pueblo
  en los dos sitios, se unen campo a campo (y no se pierden fotos).
- **Visitado sin fotos propias**: al crear un pueblo te pregunta si ya lo visitaste y cuándo
  (fecha completa, mes, solo el año o nada) y te ofrece fotos libres de internet.

### Activar el panel (una sola vez)

1. Pulsa **Publicar** en el programa.
2. En GitHub: tu repositorio → **Settings → Pages → Source: GitHub Actions**.
3. Abre `…/pueblos/gestion/` en el móvil y sigue los pasos para crear el *token*
   (Contents: Read and write, solo para el repositorio `pueblos`). Se guarda solo en ese navegador.
   Consejo: en el móvil, «Añadir a pantalla de inicio» para tenerlo como una app.

Tus pueblos se guardan ahora en la carpeta `repo\datos` (la antigua `datos\` queda como copia).

## Novedades de la 0.3

- **Mapa de España «de rascar»**, en la web y en el programa: cada provincia empieza tapada
  y se destapa con la foto de tu último pueblo visitado allí. Chinchetas para visitados
  y para pendientes, y contador «X de 52 provincias destapadas».
- **Por visitar**: tu lista de próximos destinos. Cuando importes fotos de un pueblo
  pendiente, pasa solo a visitado (y te lo celebra).
- **Programa renovado**: menú lateral, fichas con foto, modo claro/oscuro, mapa interactivo
  (pasa el ratón por una provincia o haz clic en ella o en una chincheta).

## 1. Instalar (una sola vez)

1. Instala **Python** desde https://www.python.org/downloads/ (marca *Add python.exe to PATH*).
2. Instala **Git for Windows** desde https://git-scm.com/download/win (opciones por defecto).
3. Doble clic en **INSTALAR.bat**.
4. Abre el programa con **PUEBLOS.bat** (si falta algo, lo instala solo).
   También puedes crear un .exe con `crear_exe.bat`.

## 2. Crear el sitio en GitHub (una sola vez)

1. En github.com → **New repository** → nombre `pueblos`, **Public** → *Create*.
2. En el repositorio: **Settings → Pages → Branch: `main` / `(root)` → Save**.
3. En PUEBLOS → **Ajustes** → *Repositorio de GitHub*: `https://github.com/locometopa/pueblos.git`

La primera vez que pulses **Publicar** se abrirá el navegador para iniciar sesión en GitHub.

## 3. Uso

- **Mapa** → tu progreso por provincias. Clic en una provincia para ver sus pueblos o
  añadir uno «por visitar»; clic en una chincheta para abrir el pueblo.
- **Visitados** / **Por visitar** → tus fichas. Clic en una para editarla.
- **Importar fotos** → eliges la carpeta de un viaje. Lee el GPS de cada foto, detecta los
  pueblos y crea las fichas con fotos, fechas y datos de Wikipedia. Las fotos sin GPS se
  colocan por la hora; las que queden, eliges tú a qué pueblo van.
- **Nuevo pueblo** → escribes el nombre, lo busca en el mapa, trae Wikipedia y te ofrece
  fotos libres de internet si no tiene.
- En la ficha: **Visitado / Por visitar**, fotos (★ portada, pies de foto),
  **🌐 Fotos de internet** (Wikimedia Commons, con autor y licencia), Wikipedia,
  texto con IA y tus notas.
- **Vista previa** → abre la web en tu navegador sin publicarla.
- **Publicar** → genera la web y la sube. Tarda 1–2 minutos en verse en internet.
- Abajo a la izquierda eliges el aspecto: Sistema, Claro u Oscuro.

## Detalles

- Las fotos publicadas son **copias reducidas y sin datos GPS**. Tus originales no se tocan.
- No publiques fotos bajadas de webs cualquiera: suelen tener derechos de autor.
  Usa las tuyas o las de **🌐 Fotos de internet** (libres y citadas).
- En Ajustes puedes ocultar de la web tus pueblos «por visitar».
- **Texto con IA** (opcional): necesita una clave de la API de Anthropic
  (console.anthropic.com); solo se guarda en `config.json` en tu ordenador.
- Al eliminar un pueblo se mueve a `datos\_papelera`, no se borra.
- Carpetas: `datos\` (tus pueblos), `sitio\` (la web). Haz copia de `datos\`.
- Créditos: textos de Wikipedia (CC BY-SA), mapa de provincias es-atlas (MIT), D3 (ISC).
