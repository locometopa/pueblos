# PUEBLOS 1.9.2 — la web de tus pueblos visitados

Programa para Windows que crea y publica tu web de pueblos: https://locometopa.github.io/pueblos/
También tienes un panel para el móvil: https://locometopa.github.io/pueblos/gestion/

## Qué hay en esta carpeta

| | |
|---|---|
| **PUEBLOS.bat** | Abre el programa (doble clic). La primera vez instala lo que haga falta. |
| PUEBLOS.exe | Opcional: lo mismo, como programa. Se crea con `crear_exe.bat`. |
| crear_exe.bat | Crea o vuelve a crear PUEBLOS.exe. |
| requirements.txt | Lista de librerías que necesita el programa. |
| LEEME.md | Este archivo. |
| pueblos.py, nucleo | El programa. No hace falta tocarlos. |
| config.json | Tus ajustes (y tus claves: no lo compartas). |
| repo | Tus pueblos y fotos, sincronizados con GitHub. **No lo borres.** |
| sitio | Vista previa de la web en tu PC. Se crea sola al pulsar «Vista previa»; se puede borrar. |

## Instalar (una sola vez)

1. Instala **Python** desde https://www.python.org/downloads/ (marca *Add python.exe to PATH*).
2. Instala **Git for Windows** desde https://git-scm.com/download/win (opciones por defecto).
3. Doble clic en **PUEBLOS.bat**. La primera vez tarda un poco porque instala lo necesario, y crea el acceso
   directo «PUEBLOS» (con su icono) en el escritorio y en el menú Inicio. Desde entonces, ábrelo con él.

## Uso

- **Mapa / Visitados / Por visitar**: tus pueblos. Clic en uno para editarlo. En las listas puedes **buscar** y
  **filtrar por comunidad** y ordenar (por zona, por nombre o por visita reciente).
- **Revisar**: lo que le falta a cada pueblo (ubicación, fecha, fotos, información…). Clic para arreglarlo.
- **Resumen**: un vistazo a tu viaje — cuántos pueblos, provincias y comunidades, dónde has estado, últimas visitas y próximas fiestas.
- **＋ Añadir**: fotos de un viaje (lee el GPS y crea los pueblos solos), un pueblo visitado o uno por visitar,
  o **💡 Ideas de pueblos**, o el **🏅 Catálogo de «Los Pueblos más Bonitos de España» por provincia** para marcar de golpe los que ya has visitado.
- **Editor de un pueblo**: fotos (tuyas o de internet con licencia libre), Wikipedia, texto con IA
  (puedes **Generar**, **Pulir** o **Acortar** con la IA), fiestas y tus notas («- » hace una lista, «★ » destaca una frase, **palabras** en negrita).
- **🎨 Diseño**: estilo de página (Clásica, Revista, Álbum de viaje, Moderna), cabecera (Mapa de España, Dibujo, Foto…), colores,
  modo claro/oscuro, tipografía, logo y qué secciones se muestran. «Vista previa» (abajo a la izquierda) lo enseña al momento.
- **Publicar**: sube los cambios (el botón dice cuántos tienes sin publicar); la web se actualiza en 1–2 minutos
  (abajo se ve 🟡 / ✅ / ❌). Al cerrar el programa te avisa si queda algo sin publicar.
- **🌐 Mi web ▾** (abajo): abrir tu web y copiar su enlace, abrir el panel del móvil y traer ya lo hecho
  en él (también llega solo al abrir el programa y al publicar), y ver tus archivos en GitHub.
  A su lado, **⚙** (Ajustes) y **?** (esta ayuda).
- **Ajustes** (⚙), en pestañas: **GitHub** (repositorio y token), **Inteligencia artificial** (la IA que uses: Claude,
  ChatGPT, Gemini, **DeepSeek** u otra compatible), **Copias** (un .zip semanal en tu NAS, un disco USB…) y **Programa** (aspecto claro/oscuro,
  tamaño de las fotos, acceso directo, la **Papelera** para recuperar pueblos borrados, y la versión con «Buscar actualizaciones» y las novedades).
- **Completar la información** de los pueblos (Wikipedia, Wikidata, web oficial, Wikivoyage, OpenStreetMap, fiestas…)
  está en **Revisar**, con el botón «📚 Completar la información de todos». Las fuentes gratuitas van siempre primero;
  si tienes una IA configurada, al completar puedes marcar, opcionalmente, que escriba también el texto que falte.

**En el móvil** (panel de gestión): «📌 Capturar» busca con el GPS los pueblos donde estás y te deja elegir
antes de guardarlo (sin cobertura guarda la posición y busca el pueblo al volver a tenerla). Luego, en «Revisar» (en el móvil o en el programa), decides si
lo visitaste, lo dejas «Por visitar» o lo descartas. «📍 Estoy aquí» marca como visitado hoy el pueblo donde estás (y te deja hacer una
foto), y la pestaña «✔ Revisar» enseña lo que le falta a cada pueblo. En la ficha de un pueblo puedes **escribir su texto con IA** (Ajustes → Inteligencia artificial para poner la clave); en el móvil, Gemini es la opción segura.

## Actualizaciones

Al abrir el programa, si hay una versión nueva en GitHub te lo pregunta, se actualiza solo y se reinicia
(también si lo abres con PUEBLOS.exe). Tus pueblos, fotos y ajustes no se tocan. También puedes pulsar
**la versión** (arriba a la izquierda, bajo «PUEBLOS») → «Acerca de» → **Buscar actualizaciones**.

## Historial

- **1.9.2** Nuevo distintivo **«Pueblo Mágico de España»** (otra red distinta de los «Bonitos»): sello propio en la web, programa y panel, con su interruptor en el editor para marcarlos a mano. Un pueblo puede llevar los dos sellos. (Los logos oficiales de ambas redes son marca registrada y no se reproducen; se usan sellos propios.)
- **1.9.1** «Fotos de internet» busca mejor y trae más: ahora también usa las **fotos del artículo de Wikipedia** (la de portada suele ser la mejor) y las **subcategorías de Wikimedia Commons**, con más radio en el mapa y más de Flickr/Openverse. Y las **ordena por calidad** (panorámicas y vistas del conjunto primero; detalles e interiores al final). Las fotos de Google no se pueden usar (tienen copyright y la web es pública).
- **1.9.0** «Revisar» solo te avisa de lo que *puedes* completar (no es un error). Si un pueblo ya lo das por bueno, ahora tienes el interruptor **«✓ Dado por revisado»** en el editor (programa y móvil) que lo saca de «Revisar».
- **1.8.9** Los pueblos que son **«Pueblo más Bonito de España» lucen un sello 🏅** en la web (en la ficha y en su página), en el programa y en el panel del móvil. El catálogo pone el sello solo al añadirlos (y a los que ya tenías), y también puedes marcarlo o quitarlo a mano en el editor (programa y móvil).
- **1.8.8** Nuevo **catálogo de «Los Pueblos más Bonitos de España» por provincia** (en ＋ Añadir): marca los que ya has visitado y se añaden a «Visitados» con su provincia y ubicación, para rellenarlos con fotos e IA cuando quieras. Lleva la cuenta de cuántos tienes y marca los que ya estaban.
- **1.8.7** El **panel del móvil** estrena el mismo estilo de la web (cuaderno cálido, tipografía Fraunces) y ahora **se adapta a si lo abres en móvil o en PC**: en el ordenador, donde la ubicación por GPS no sirve, oculta «Capturar» y «Estoy aquí» y coloca las acciones en línea con tarjetas algo más grandes.
- **1.8.6** El dibujo de la cabecera es ahora un **pueblo del norte**: prados verdes, montañas al fondo (estilo Picos), árboles frondosos y casonas blancas con tejado rojo e iglesia. Cambia igual con la hora (amanecer, día, atardecer, noche).
- **1.8.5** Cabecera más compacta (menos cielo, el título se asienta sobre la escena) para que el **mapa de España asome antes** al entrar. La **luna** se recoloca despejada (en escritorio sobre la torre, en móvil asomando tras ella), el **humo** sale de otra casa para no cruzarla, y las **nubes** se mueven algo más.
- **1.8.4** La **luna de noche** ya flota entera sobre las colinas (antes se cortaba) con un resplandor suave, y el cielo tiene **vida**: las estrellas titilan y las nubes derivan despacio (todo se queda quieto si pides menos animación).
- **1.8.3** Detalles con vida en la portada: una **chimenea del pueblo echa humito** que sube y se desvanece (se queda quieto si tu sistema pide menos animación), y la **barra de provincias destapadas** se ve bien también de noche (antes el carril se perdía con el fondo oscuro).
- **1.8.2** Portada con más vida: los pueblos de cada comunidad se ven ahora como **postales** (foto a toda tarjeta con el nombre encima y la comunidad en una cinta), juntos en una misma rejilla que llena la página en lugar de miniaturas sueltas.
- **1.8.1** Vuelve el **dibujo de la cabecera que cambia con la hora** (amanecer, día, atardecer, noche) como portada por defecto, con el **mapa de España que se destapa justo debajo, de protagonista**. La cabecera «Mapa de España» (solo mapa) sigue disponible en 🎨 Diseño.
- **1.8.0** La web estrena el **mapa de España que se destapa de protagonista** en la portada (nueva cabecera «Mapa de España»). El mapa de cada pueblo (web, panel y programa) ahora es **Google Maps** (con satélite y Street View al abrirlo).
- **1.7.5** Papelera para recuperar pueblos borrados (Ajustes → Programa), y botones «Pulir» y «Acortar» para que la IA retoque el texto que ya tengas (programa y móvil).
- **1.7.4** Si la IA está saturada (error 503) o falla un momento, el programa y el panel reintentan solos 2–3 veces antes de avisar.
- **1.7.3** En el panel del móvil ya se puede escribir el texto de un pueblo con IA (Gemini, Claude, DeepSeek…), para hacerlo sin el portátil. En el móvil, Gemini es la opción segura; DeepSeek/OpenAI puede bloquearlos el navegador.
- **1.7.2** Nuevo «Resumen de viaje» (pueblos, provincias y comunidades, dónde has estado, últimas visitas y próximas fiestas) y filtro por comunidad y orden en las listas.
- **1.7.1** DeepSeek como IA propia (solo pegas la clave). Al «Completar la información» puedes marcar que la IA escriba también el texto que falte; las fuentes gratuitas van siempre primero.
- **1.7.0** Menús y Ajustes reorganizados: Ajustes en pestañas por tema (GitHub · IA · Copias · Programa), la versión y novedades dentro de «Programa», y sin opciones repetidas.
- **1.6.8** El PUEBLOS.exe (opcional) ya se crea con todo dentro (se arreglaba «No module named requests»). Añadido requirements.txt.
- **1.6.7** Arreglado «Algo ha fallado» al sincronizar en un PC nuevo cuando ya existía una carpeta «repo» vacía.
- **1.6.6** En el móvil, el crédito de la foto de portada de cada pueblo va al pie, sin tapar el nombre ni la fecha.
- **1.6.5** Mapa de la web con más espacio arriba y a los lados; el globo con el nombre ya no se corta en los bordes.
- **1.6.4** Ubicación más precisa al añadir un pueblo (pueblos de España antes que calles o lugares de fuera, el punto del
  núcleo y no el centro del término; si hay varios, lista con mapa y distancia a tus pueblos). Mapa pequeño en la ficha
  (programa y móvil) que se actualiza al momento; si cambias el nombre o la provincia se vuelve a ubicar solo.
- **1.6.3** Panel del móvil con nuevo diseño «Cuaderno» (de noche por defecto; en Ajustes del panel: Noche, Día o Automático) e iconos planos de color.
- **1.6.2** «Capturar» enseña la lista de pueblos posibles (y los tuyos cercanos) antes de confirmar.
- **1.6.1** Botón «📌 Capturar» en el móvil: guarda el pueblo por el que pasas para revisarlo luego.
- **1.6** El dibujo de la cabecera cambia con la hora de quien visita (amanecer, día, atardecer y noche) y
  botón ☀/☾ en la web para pasar de claro a oscuro (se recuerda). Los dos se pueden quitar en Diseño.
- **1.5.4** Icono propio (la casita con campanario) en la ventana, la barra de tareas y el .exe; accesos directos
  en el escritorio y el menú Inicio (se crean solos; también en Ajustes → General).
- **1.5.3** Menús con el estilo del programa y sin repetir: «Mi web ▾» agrupa todo lo de la web y el móvil;
  «Acerca de» solo versión, actualizaciones y novedades; Mi web, Ajustes y Ayuda en una fila.
- **1.5.2** Botón «❓ Ayuda» en la barra lateral, con estas instrucciones dentro del programa.
- **1.5.1** Ajustes en pestañas (General, Inteligencia artificial, Copia de seguridad).
- **1.5** «Acerca de» al pulsar la versión, con «Buscar actualizaciones», enlaces y novedades.
- **1.4** «Escapadas posibles» con tus pendientes cercanos; «Estoy aquí» y «Revisar» en el móvil; ideas de
  pueblos; copia de seguridad automática.
- **1.3** «Última visita» en la portada; programa más ordenado (botón «＋ Añadir», menú «Mi web», sin botones
  repetidos), apartado «Revisar» y aviso de cambios sin publicar.
- **1.2** Limpieza: menos archivos (PUEBLOS.bat instala lo necesario; crear_exe.bat no deja restos);
  el .exe también se actualiza solo.
- **1.1** Estilos de página entera; artículo de otra Wikipedia (traducido con IA) si la española es corta; más datos de Wikidata.
- **1.0** Web oficial del ayuntamiento, guía de Wikivoyage, distinciones, lugares de OpenStreetMap; fotos de Flickr y otras (Openverse).
- **0.9** Fiestas de cada pueblo sin IA y «Próximas fiestas»; notas como cuaderno; tiempo compacto y fichas de «Qué ver».
- **0.8** Varias IAs; el tiempo, mapa y pueblos cercanos en cada ficha.
- **0.7** Vista previa al compartir por WhatsApp; web y panel instalables en el móvil; línea del tiempo.
- **0.6** Apartado Diseño, vista previa en vivo, token de GitHub, actualizaciones automáticas.
- **0.5 y anteriores** Mapa que se destapa, panel del móvil, cabecera ilustrada, información ampliada.
