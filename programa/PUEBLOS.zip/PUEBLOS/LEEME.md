# PUEBLOS 1.2 — la web de tus pueblos visitados

Programa para Windows que crea y publica tu web de pueblos: https://locometopa.github.io/pueblos/
También tienes un panel para el móvil: https://locometopa.github.io/pueblos/gestion/

## Qué hay en esta carpeta

| | |
|---|---|
| **PUEBLOS.bat** | Abre el programa (doble clic). La primera vez instala lo que haga falta. |
| PUEBLOS.exe | Opcional: lo mismo, como programa. Se crea con `crear_exe.bat`. |
| crear_exe.bat | Crea o vuelve a crear PUEBLOS.exe. |
| LEEME.md | Este archivo. |
| pueblos.py, nucleo | El programa. No hace falta tocarlos. |
| config.json | Tus ajustes (y tus claves: no lo compartas). |
| repo | Tus pueblos y fotos, sincronizados con GitHub. **No lo borres.** |
| sitio | Vista previa de la web en tu PC. Se crea sola al pulsar «Vista previa»; se puede borrar. |

## Instalar (una sola vez)

1. Instala **Python** desde https://www.python.org/downloads/ (marca *Add python.exe to PATH*).
2. Instala **Git for Windows** desde https://git-scm.com/download/win (opciones por defecto).
3. Doble clic en **PUEBLOS.bat**. La primera vez tarda un poco porque instala lo necesario.

## Uso

- **Mapa / Visitados / Por visitar**: tus pueblos. Clic en uno para editarlo.
- **Importar fotos**: eliges la carpeta de un viaje; lee el GPS de cada foto y crea las fichas.
- **Editor de un pueblo**: fotos (tuyas o de internet con licencia libre), Wikipedia, texto con IA,
  fiestas y tus notas («- » hace una lista, «★ » destaca una frase, **palabras** en negrita).
- **🎨 Diseño**: estilo de página (Clásica, Revista, Álbum de viaje, Moderna), cabecera, colores,
  modo claro/oscuro, tipografía, logo y qué secciones se muestran. «Vista previa en vivo» lo enseña al momento.
- **Publicar**: sube los cambios; la web se actualiza en 1–2 minutos (abajo se ve 🟡 / ✅ / ❌).
- **Sincronizar**: trae lo que hayas hecho desde el panel del móvil.
- **Ajustes**: repositorio y token de GitHub, la IA que quieras usar (Claude, ChatGPT, Gemini u otra)
  y «Completar la información de todos los pueblos» (Wikipedia, Wikidata, web oficial, Wikivoyage,
  OpenStreetMap, fiestas…).

## Actualizaciones

Al sincronizar, si hay una versión nueva en GitHub el programa te lo pregunta, se actualiza solo y se
reinicia (también si lo abres con PUEBLOS.exe). Tus pueblos, fotos y ajustes no se tocan.

## Historial

- **1.2** Limpieza: menos archivos (PUEBLOS.bat instala lo necesario; crear_exe.bat no deja restos);
  el .exe también se actualiza solo.
- **1.1** Estilos de página entera; artículo de otra Wikipedia (traducido con IA) si la española es corta; más datos de Wikidata.
- **1.0** Web oficial del ayuntamiento, guía de Wikivoyage, distinciones, lugares de OpenStreetMap; fotos de Flickr y otras (Openverse).
- **0.9** Fiestas de cada pueblo sin IA y «Próximas fiestas»; notas como cuaderno; tiempo compacto y fichas de «Qué ver».
- **0.8** Varias IAs; el tiempo, mapa y pueblos cercanos en cada ficha.
- **0.7** Vista previa al compartir por WhatsApp; web y panel instalables en el móvil; línea del tiempo.
- **0.6** Apartado Diseño, vista previa en vivo, token de GitHub, actualizaciones automáticas.
- **0.5 y anteriores** Mapa que se destapa, panel del móvil, cabecera ilustrada, información ampliada.
