# PUEBLOS 1.0 — la web de tus pueblos visitados

Programa de Windows para guardar los pueblos que has visitado (y los que quieres visitar)
y publicarlos como una web gratuita en GitHub Pages: `https://locometopa.github.io/pueblos/`

## Novedades de la 1.0

- **Más fuentes de información** además de Wikipedia (al traer los datos de un pueblo o con
  Ajustes → «Completar la información de todos los pueblos»):
  - **Web oficial del ayuntamiento**: la de Wikidata o, si no la hay, se prueban las direcciones habituales
    (www.pueblo.es, aytodepueblo.es, concellode….gal…). En la ficha sale su descripción y el enlace.
  - **Guía de viaje de Wikivoyage**: entender, cómo llegar, qué ver, qué hacer, dónde comer y dónde dormir.
  - **Distinciones** de Wikidata: Conjunto Histórico, Los Pueblos más Bonitos de España…
  - **OpenStreetMap**: más lugares en «Qué ver» cuando Wikidata da pocos (con «Cómo llegar»).
- **Más fuentes de fotos** (programa y panel del móvil): la categoría del pueblo en Wikimedia Commons y fotos con
  licencia Creative Commons de **Flickr** y otros sitios (Openverse). En la web se cita autor, licencia y origen.
- Vuelve el texto de Wikipedia sobre el pueblo, sin el título «Según Wikipedia».

## Novedades de la 0.9.2

- Ficha del pueblo: fuera el apartado «Según Wikipedia» (Wikipedia ya figura en los créditos).
- **El tiempo**, ahora pequeño en la cabecera, junto al nombre: al pulsarlo se despliega la previsión de 5 días.
- **Qué ver**: al pulsar un lugar se abre una ficha con foto, descripción y «Cómo llegar», sin salir de tu web.
- Arreglada una barra clara que aparecía sobre la provincia, en la cabecera.

## Novedades de la 0.9.1

- Panel del móvil: arreglado el error «Update is not a fast forward» al guardar justo cuando había otro cambio
  en GitHub (el móvil reutilizaba una respuesta vieja). Ahora reintenta bien y, si no puede, lo explica claro.

## Novedades de la 0.9

- **Fiestas de cada pueblo, sin IA**: se sacan del apartado de fiestas de Wikipedia (y de frases con fecha), del día
  del santo patrón y de las fiestas registradas en Wikidata. Entiende fechas fijas («14 de septiembre», «del 14 al 17
  de agosto»), «último domingo de agosto», «segundo fin de semana de noviembre», «a finales de julio» y fiestas
  móviles (Semana Santa, Corpus, Carnaval, Pentecostés…).
  - En la web: «Fiestas de …» en cada pueblo, con la próxima fecha y cuánto falta, y **«Próximas fiestas»** en la portada.
  - En el programa: pestaña **Fiestas** del editor para buscarlas, corregirlas o escribir las tuyas.
  - Para tus pueblos de antes: Ajustes → «Completar la información de todos los pueblos».
- **«Mis notas» rediseñadas como «Mi cuaderno»**: hoja de libreta con renglones, cinta, una de tus fotos en polaroid,
  letra manuscrita (se puede quitar en Diseño) y firma. Trucos al escribir: «- » hace una lista, «★ » destaca una frase,
  **palabras** en negrita.

## Novedades de la 0.8

- **Varias IAs** para escribir el texto de cada pueblo (Ajustes → Inteligencia artificial):
  Claude, ChatGPT, Gemini (tiene uso gratuito) u «Otra» compatible con OpenAI (DeepSeek, Mistral, Groq,
  OpenRouter, Ollama…). Botones para conseguir la clave, ver los modelos disponibles y probarla.
  (Copilot no se puede usar: Microsoft no ofrece una API para particulares.)
- **Ficha de cada pueblo más completa** (cada cosa se activa o desactiva en 🎨 Diseño):
  - **El tiempo**: ahora, los próximos 5 días, probabilidad de lluvia, amanecer y atardecer (Open-Meteo, sin clave).
  - **Dónde está**: mapa pequeño y botón «🚗 Cómo llegar».
  - **Cerca de aquí**: tus otros pueblos (visitados o por visitar) a menos de 80 km.
- La IA ahora tiene en cuenta también la historia, las fiestas y los lugares de interés de Wikipedia.

## Novedades de la 0.7.1

- El **panel de gestión** también se instala en el móvil, como app propia («Gestión», con su icono con un lápiz).
  Al entrar aparece «📲 Instalar»; también está en ⚙ Ajustes del panel. En el iPhone: Safari → Compartir → «Añadir a pantalla de inicio».

## Novedades de la 0.7

Tres extras nuevos; cada uno se activa o desactiva en **🎨 Diseño → Fondo, secciones y extras**:

- **Compartir por WhatsApp** (y Telegram, Facebook…): al pegar el enlace de tu web o de un pueblo sale una tarjeta
  con su foto, el nombre y una descripción. La portada lleva tus últimas fotos y las cifras.
- **Instalar en el móvil**: la web se puede añadir a la pantalla de inicio como una app (con su icono, a pantalla completa)
  y lo que ya has visto se abre aunque no haya cobertura. Abajo de la web aparece el botón «📲 Instalar en el móvil»;
  en el iPhone se hace desde Safari → Compartir → «Añadir a pantalla de inicio».
- **Línea del tiempo**: «Mis viajes, año a año» en la portada, con cada visita ordenada por fecha.

## Novedades de la 0.6.1

- Mapa: las chinchetas ya no «se escapan» al pasar el ratón; en el móvil son más grandes y fáciles de tocar
  (primer toque muestra el nombre, el segundo abre el pueblo) y la provincia elegida se resalta.

## Novedades de la 0.6

- **🎨 Diseño** (nuevo apartado del menú): cabecera (dibujo, foto grande, collage o sencilla), paleta de colores,
  modo claro/oscuro/automático, tipografía, fondo de azulejos y bandas, mostrar u ocultar mapa y secciones,
  orden mapa/pueblos y **tu logo** (también como icono de la pestaña).
- **Vista previa en vivo**: pulsa «Vista previa en vivo» y deja el navegador abierto; cada cambio de diseño se ve solo en un segundo.
- **Token de GitHub en Ajustes** (opcional): publicar sin iniciar sesión y ver abajo si la web se ha publicado bien (🟡 / ✅ / ❌).
  Créalo en GitHub → *Settings → Developer settings → Fine-grained tokens*, solo para el repositorio `pueblos`,
  permiso **Contents: Read and write**. Se guarda solo en tu ordenador.
- **Actualizaciones automáticas**: al sincronizar, si hay una versión nueva en GitHub el programa te lo pregunta,
  se actualiza solo y se reinicia. Tus pueblos, fotos y configuración no se tocan.

## Novedades de la 0.5

- **Cabecera ilustrada** en la página principal: un pueblo dibujado al atardecer
  (y de noche, con luna, estrellas y ventanas encendidas, en modo oscuro).
- **Más información de cada pueblo**, recopilada de internet al traer Wikipedia:
  historia, patrimonio, fiestas, gastronomía, leyendas y curiosidades, naturaleza, personajes;
  **«Qué ver»** con monumentos y lugares de interés (con foto libre y su autor); gentilicio y patrón.
  Para los pueblos que ya tenías: **Ajustes → Completar la información de todos los pueblos**.

## Novedades de la 0.4

- **Panel de gestión en la web**, para el móvil: `https://locometopa.github.io/pueblos/gestion/`.
  Sube fotos desde la galería (lee el GPS, detecta el pueblo y les quita la ubicación antes de subirlas),
  crea pueblos, trae Wikipedia, pon fotos de internet, edita, marca visitado / por visitar.
- **Tus datos viven en GitHub**: el programa y el panel trabajan sobre lo mismo. Al abrir el
  programa se traen los cambios del móvil; «Publicar» sube los tuyos. Si tocas el mismo pueblo
  en los dos sitios, se unen campo a campo (y no se pierden fotos).
- **Visitado sin fotos propias**: al crear un pueblo te pregunta si ya lo visitaste y cuándo
  (fecha completa, mes, solo el año o nada) y te ofrece fotos libres de internet.

### Activar el panel (una sola vez)

1. Pulsa **Publicar** en el programa.
2. En GitHub: tu repositorio → **Settings → Pages → Source: GitHub Actions**.
3. Abre `…/pueblos/gestion/` en el móvil y sigue los pasos para crear el *token*
   (Contents: Read and write, solo para el repositorio `pueblos`). Se guarda solo en ese navegador.
   Consejo: en el móvil, «Añadir a pantalla de inicio» para tenerlo como una app.

Tus pueblos se guardan ahora en la carpeta `repo\datos` (la antigua `datos\` queda como copia).

## Novedades de la 0.3

- **Mapa de España «de rascar»**, en la web y en el programa: cada provincia empieza tapada
  y se destapa con la foto de tu último pueblo visitado allí. Chinchetas para visitados
  y para pendientes, y contador «X de 52 provincias destapadas».
- **Por visitar**: tu lista de próximos destinos. Cuando importes fotos de un pueblo
  pendiente, pasa solo a visitado (y te lo celebra).
- **Programa renovado**: menú lateral, fichas con foto, modo claro/oscuro, mapa interactivo
  (pasa el ratón por una provincia o haz clic en ella o en una chincheta).

## 1. Instalar (una sola vez)

1. Instala **Python** desde https://www.python.org/downloads/ (marca *Add python.exe to PATH*).
2. Instala **Git for Windows** desde https://git-scm.com/download/win (opciones por defecto).
3. Doble clic en **INSTALAR.bat**.
4. Abre el programa con **PUEBLOS.bat** (si falta algo, lo instala solo).
   También puedes crear un .exe con `crear_exe.bat`.

## 2. Crear el sitio en GitHub (una sola vez)

1. En github.com → **New repository** → nombre `pueblos`, **Public** → *Create*.
2. En el repositorio: **Settings → Pages → Branch: `main` / `(root)` → Save**.
3. En PUEBLOS → **Ajustes** → *Repositorio de GitHub*: `https://github.com/locometopa/pueblos.git`

La primera vez que pulses **Publicar** se abrirá el navegador para iniciar sesión en GitHub.

## 3. Uso

- **Mapa** → tu progreso por provincias. Clic en una provincia para ver sus pueblos o
  añadir uno «por visitar»; clic en una chincheta para abrir el pueblo.
- **Visitados** / **Por visitar** → tus fichas. Clic en una para editarla.
- **Importar fotos** → eliges la carpeta de un viaje. Lee el GPS de cada foto, detecta los
  pueblos y crea las fichas con fotos, fechas y datos de Wikipedia. Las fotos sin GPS se
  colocan por la hora; las que queden, eliges tú a qué pueblo van.
- **Nuevo pueblo** → escribes el nombre, lo busca en el mapa, trae Wikipedia y te ofrece
  fotos libres de internet si no tiene.
- En la ficha: **Visitado / Por visitar**, fotos (★ portada, pies de foto),
  **🌐 Fotos de internet** (Wikimedia Commons, con autor y licencia), Wikipedia,
  texto con IA y tus notas.
- **Vista previa** → abre la web en tu navegador sin publicarla.
- **Publicar** → genera la web y la sube. Tarda 1–2 minutos en verse en internet.
- Abajo a la izquierda eliges el aspecto: Sistema, Claro u Oscuro.

## Detalles

- Las fotos publicadas son **copias reducidas y sin datos GPS**. Tus originales no se tocan.
- No publiques fotos bajadas de webs cualquiera: suelen tener derechos de autor.
  Usa las tuyas o las de **🌐 Fotos de internet** (libres y citadas).
- En Ajustes puedes ocultar de la web tus pueblos «por visitar».
- **Texto con IA** (opcional): necesita una clave de la API de Anthropic
  (console.anthropic.com); solo se guarda en `config.json` en tu ordenador.
- Al eliminar un pueblo se mueve a `datos\_papelera`, no se borra.
- Carpetas: `datos\` (tus pueblos), `sitio\` (la web). Haz copia de `datos\`.
- Créditos: textos de Wikipedia (CC BY-SA), mapa de provincias es-atlas (MIT), D3 (ISC).
