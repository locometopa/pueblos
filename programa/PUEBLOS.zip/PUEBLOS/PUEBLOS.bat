@echo off
rem Si falta algo (por ejemplo tras actualizar), se instala solo la primera vez
py -c "import customtkinter, PIL, requests" 2>nul || (
  echo Instalando lo que falta, un momento...
  py -m pip install "customtkinter==5.2.2" Pillow requests
  py -m pip install pillow-heif
)
start "" pyw "%~dp0pueblos.py"
