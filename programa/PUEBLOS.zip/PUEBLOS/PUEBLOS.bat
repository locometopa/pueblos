@echo off
chcp 65001 >nul
rem PUEBLOS: abre el programa. La primera vez instala lo que haga falta.
where py >nul 2>nul
if errorlevel 1 (
  echo No encuentro Python. Instalalo desde https://www.python.org/downloads/
  echo y marca la casilla "Add python.exe to PATH". Luego vuelve a abrir PUEBLOS.bat
  pause
  exit /b 1
)
py -c "import customtkinter, PIL, requests" 2>nul
if errorlevel 1 (
  echo Instalando lo necesario, solo la primera vez...
  py -m pip install --upgrade pip >nul
  py -m pip install "customtkinter==5.2.2" Pillow requests
  py -m pip install pillow-heif
  where git >nul 2>nul
  if errorlevel 1 echo AVISO: para publicar la web instala Git for Windows: https://git-scm.com/download/win
)
start "" pyw "%~dp0pueblos.py"
