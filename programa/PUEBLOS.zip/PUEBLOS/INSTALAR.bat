@echo off
chcp 65001 >nul
echo === PUEBLOS: instalando lo necesario ===
where py >nul 2>nul
if errorlevel 1 (
  echo.
  echo No encuentro Python. Instalalo desde https://www.python.org/downloads/
  echo y marca la casilla "Add python.exe to PATH". Luego vuelve a ejecutar este archivo.
  pause
  exit /b 1
)
py -m pip install --upgrade pip
py -m pip install "customtkinter==5.2.2" Pillow requests
rem Opcional: fotos HEIC del iPhone (si falla no pasa nada)
py -m pip install pillow-heif
where git >nul 2>nul
if errorlevel 1 (
  echo.
  echo AVISO: no encuentro git. Para publicar la web instala "Git for Windows": https://git-scm.com/download/win
)
echo.
echo Listo. Abre el programa con PUEBLOS.bat
pause
